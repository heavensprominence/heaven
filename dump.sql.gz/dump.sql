--
-- PostgreSQL database dump
--

\restrict NDfj7QjbKw5k3OkV8ePw8DqDNvIZQjcezXdO8Vk5fVotuqEbuHKHdrNrY8v242t

-- Dumped from database version 15.16 (Debian 15.16-0+deb12u1)
-- Dumped by pg_dump version 15.16 (Debian 15.16-0+deb12u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: add_other_subcategory(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.add_other_subcategory() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Only add 'Other' for main categories (level 1) or when explicitly requested
    IF NEW.level = 1 THEN
        INSERT INTO shop_categories (category, display_name, parent_category, icon, full_path, level, is_active)
        VALUES (
            NEW.category || '_other',
            'Other',
            NEW.category,
            '📦',
            NEW.full_path || '/other',
            2,
            true
        ) ON CONFLICT (category) DO NOTHING;
    END IF;
    RETURN NEW;
END;
$$;


--
-- Name: cleanup_expired_listings(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cleanup_expired_listings() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Permanently delete listings that are deleted or expired for more than 30 days
    DELETE FROM listings 
    WHERE (status = 'deleted' AND deleted_at < NOW() - INTERVAL '30 days')
       OR (status = 'expired' AND expires_at < NOW() - INTERVAL '30 days');
    
    -- Clean up old sales history (older than 3 years)
    DELETE FROM sales_history WHERE retained_until < NOW();
END;
$$;


--
-- Name: rebuild_category_paths(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.rebuild_category_paths() RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    cat RECORD;
BEGIN
    -- Update level 1 categories
    UPDATE shop_categories SET level = 1, full_path = category WHERE parent_category IS NULL;
    
    -- Recursively update children
    FOR cat IN SELECT * FROM shop_categories WHERE parent_category IS NOT NULL ORDER BY parent_category LOOP
        UPDATE shop_categories sc
        SET level = p.level + 1,
            full_path = p.full_path || '/' || sc.category
        FROM shop_categories p
        WHERE p.category = sc.parent_category AND sc.id = cat.id;
    END LOOP;
END;
$$;


--
-- Name: update_translation_search_vector(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_translation_search_vector() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.search_vector := 
        setweight(to_tsvector('english', COALESCE(NEW.title, '')), 'A') ||
        setweight(to_tsvector('english', COALESCE(NEW.description, '')), 'B');
    RETURN NEW;
END;
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: affiliate_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.affiliate_settings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    setting_key character varying(50) NOT NULL,
    setting_value jsonb NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: analytics_daily; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.analytics_daily (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    date date NOT NULL,
    total_sales integer DEFAULT 0,
    total_revenue_cents bigint DEFAULT 0,
    platform_fee_cents bigint DEFAULT 0,
    new_listings integer DEFAULT 0,
    new_users integer DEFAULT 0,
    active_users integer DEFAULT 0,
    page_views integer DEFAULT 0,
    unique_visitors integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: appointments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.appointments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    appointment_time timestamp without time zone NOT NULL,
    duration_minutes integer DEFAULT 15,
    status character varying(20) DEFAULT 'scheduled'::character varying,
    cancellation_token uuid DEFAULT public.uuid_generate_v4(),
    whatsapp_contact_added boolean DEFAULT false,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: auction_bids; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auction_bids (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    listing_id uuid NOT NULL,
    bidder_id uuid NOT NULL,
    amount_cents bigint NOT NULL,
    is_winning boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    quantity integer DEFAULT 1,
    winning_quantity integer DEFAULT 0,
    clearing_price_cents bigint
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    admin_id uuid NOT NULL,
    action character varying(255) NOT NULL,
    target_type character varying(50),
    target_id uuid,
    details jsonb,
    ip_address character varying(45),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: bids; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bids (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    type character varying(20) NOT NULL,
    from_currency character varying(50) NOT NULL,
    to_currency character varying(50) NOT NULL,
    amount_cents bigint NOT NULL,
    exchange_rate numeric(20,8) NOT NULL,
    status character varying(20) DEFAULT 'open'::character varying,
    matched_bid_id uuid,
    expires_at timestamp without time zone,
    is_mock boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: carts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.carts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    listing_id uuid NOT NULL,
    quantity integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_activity timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    reminder_sent boolean DEFAULT false,
    reminder_sent_at timestamp without time zone,
    reminder_count integer DEFAULT 0
);


--
-- Name: category_analytics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.category_analytics (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    date date NOT NULL,
    category character varying(100) NOT NULL,
    listings_count integer DEFAULT 0,
    sales_count integer DEFAULT 0,
    revenue_cents bigint DEFAULT 0,
    avg_price_cents bigint DEFAULT 0,
    views integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: category_suggestions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.category_suggestions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    parent_category character varying(100),
    suggested_name character varying(255) NOT NULL,
    description text,
    status character varying(20) DEFAULT 'pending'::character varying,
    admin_notes text,
    reviewed_by uuid,
    reviewed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: category_translations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.category_translations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    category character varying(100) NOT NULL,
    language_code character varying(5) NOT NULL,
    name text NOT NULL,
    translated_by character varying(20) DEFAULT 'auto'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: competitor_insights; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.competitor_insights (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    seller_id uuid NOT NULL,
    category character varying(100) NOT NULL,
    avg_competitor_price_cents bigint,
    price_position character varying(20),
    market_share_percent numeric(5,2),
    competitive_advantage text,
    recommended_action text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    listing_id uuid,
    buyer_id uuid NOT NULL,
    seller_id uuid NOT NULL,
    subject character varying(255) DEFAULT 'General Inquiry'::character varying,
    last_message_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: dispute_evidence; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dispute_evidence (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    dispute_id uuid NOT NULL,
    uploaded_by uuid NOT NULL,
    file_url text NOT NULL,
    file_type character varying(50),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: dispute_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dispute_messages (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    dispute_id uuid NOT NULL,
    sender_id uuid NOT NULL,
    message text NOT NULL,
    is_admin_message boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: disputes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.disputes (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    transaction_id uuid,
    order_id uuid,
    title character varying(255) NOT NULL,
    description text NOT NULL,
    status character varying(20) DEFAULT 'open'::character varying,
    resolution_notes text,
    resolved_by uuid,
    resolved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: escrow_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.escrow_transactions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    order_id uuid NOT NULL,
    buyer_id uuid NOT NULL,
    seller_id uuid NOT NULL,
    listing_id uuid NOT NULL,
    amount_cents bigint NOT NULL,
    platform_fee_cents bigint DEFAULT 0,
    seller_payout_cents bigint NOT NULL,
    paypal_order_id character varying(255),
    paypal_capture_id character varying(255),
    status character varying(50) DEFAULT 'pending'::character varying,
    held_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    released_at timestamp without time zone,
    released_by uuid,
    tracking_number character varying(100),
    tracking_carrier character varying(50),
    delivery_confirmed_at timestamp without time zone,
    buyer_acceptance boolean DEFAULT false,
    auto_release_date timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: exchange_rates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.exchange_rates (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    from_currency character varying(50) NOT NULL,
    to_currency character varying(50) NOT NULL,
    rate numeric(20,8) NOT NULL,
    updated_by uuid,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: fee_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fee_transactions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    order_id uuid,
    amount_cents bigint NOT NULL,
    fee_percent numeric(5,2) NOT NULL,
    collected_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: gift_card_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gift_card_transactions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    gift_card_id uuid NOT NULL,
    purchase_id uuid,
    amount_cents bigint NOT NULL,
    transaction_type character varying(20) NOT NULL,
    balance_after_cents bigint NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: gift_cards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gift_cards (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    code character varying(20) NOT NULL,
    initial_amount_cents bigint NOT NULL,
    current_balance_cents bigint NOT NULL,
    purchaser_id uuid,
    purchaser_email character varying(255),
    recipient_name character varying(255),
    recipient_email character varying(255),
    message text,
    is_redeemed boolean DEFAULT false,
    redeemed_by uuid,
    redeemed_at timestamp without time zone,
    expires_at timestamp without time zone DEFAULT (CURRENT_TIMESTAMP + '1 year'::interval),
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT gift_cards_initial_amount_cents_check CHECK (((initial_amount_cents >= 100) AND (initial_amount_cents <= 100000)))
);


--
-- Name: help_articles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.help_articles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    content text NOT NULL,
    category character varying(50),
    views integer DEFAULT 0,
    is_published boolean DEFAULT true,
    created_by uuid,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: listing_translations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.listing_translations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    listing_id uuid NOT NULL,
    language_code character varying(5) NOT NULL,
    title text,
    description text,
    translated_by character varying(20) DEFAULT 'auto'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    search_vector tsvector
);


--
-- Name: listing_views; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.listing_views (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    listing_id uuid NOT NULL,
    viewer_id uuid,
    ip_address character varying(45),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: listings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.listings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    seller_id uuid NOT NULL,
    store_id uuid,
    type character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    category character varying(100),
    price_cents bigint,
    starting_price_cents bigint,
    reserve_price_cents bigint,
    buy_it_now_price_cents bigint,
    current_bid_cents bigint,
    bid_increment_cents bigint DEFAULT 100,
    reverse_target_specs jsonb,
    quantity_available integer DEFAULT 1,
    quantity_sold integer DEFAULT 0,
    images text[],
    video_url text,
    location_city character varying(100),
    location_state character varying(100),
    location_country character varying(100),
    latitude numeric(10,8),
    longitude numeric(11,8),
    is_local_pickup boolean DEFAULT false,
    shipping_options jsonb DEFAULT '[]'::jsonb,
    inventory_tracking jsonb,
    status character varying(50) DEFAULT 'pending_approval'::character varying,
    approved_by uuid,
    approved_at timestamp without time zone,
    auction_end_time timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    duration character varying(20) DEFAULT '2weeks'::character varying,
    expires_at timestamp without time zone,
    min_bid_cents bigint,
    max_bid_cents bigint,
    bid_increment_percent integer DEFAULT 10,
    current_bidder_id uuid,
    bid_count integer DEFAULT 0,
    shipping_provider character varying(50),
    shipping_tracking character varying(100),
    weight_oz integer,
    dimensions jsonb,
    deleted_at timestamp without time zone,
    deletion_reason character varying(50),
    is_dutch_auction boolean DEFAULT false,
    dutch_clearing_price_cents bigint,
    allow_local_pickup boolean DEFAULT false,
    pickup_address text,
    pickup_city character varying(100),
    pickup_state character varying(100),
    pickup_zip character varying(20),
    pickup_instructions text,
    pickup_country character varying(2) DEFAULT 'CA'::character varying,
    poster_role character varying(20) DEFAULT 'seller'::character varying,
    item_condition character varying(20) DEFAULT 'new'::character varying,
    is_featured boolean DEFAULT false
);


--
-- Name: login_verification_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.login_verification_codes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    code character varying(6) NOT NULL,
    session_id uuid NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    verified boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: market_trends; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.market_trends (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    category character varying(100) NOT NULL,
    date date NOT NULL,
    avg_price_cents bigint,
    median_price_cents bigint,
    sales_volume integer,
    demand_score integer DEFAULT 50,
    supply_score integer DEFAULT 50,
    trending_keywords text[],
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    sender_id uuid NOT NULL,
    receiver_id uuid NOT NULL,
    listing_id uuid,
    message text NOT NULL,
    is_read boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: minting_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.minting_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    admin_id uuid,
    action character varying(20) NOT NULL,
    amount_cents bigint NOT NULL,
    reason text,
    is_automatic boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: offers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.offers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    listing_id uuid NOT NULL,
    buyer_id uuid NOT NULL,
    offer_cents bigint NOT NULL,
    message text,
    status character varying(20) DEFAULT 'pending'::character varying,
    seller_response text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    type character varying(50) NOT NULL,
    amount_usd numeric(10,2) NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying,
    paypal_order_id character varying(255),
    shipping_address text,
    shipping_tracking_number character varying(255),
    shipping_carrier character varying(100),
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    listing_id uuid,
    listing_type character varying(50),
    seller_id uuid,
    escrow_status character varying(50) DEFAULT 'pending'::character varying,
    escrow_release_date timestamp without time zone,
    escrow_id uuid
);


--
-- Name: platform_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.platform_settings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    setting_key character varying(100) NOT NULL,
    setting_value jsonb NOT NULL,
    updated_by uuid,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: price_predictions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.price_predictions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    category character varying(100) NOT NULL,
    predicted_price_cents bigint,
    confidence_score integer,
    best_time_to_sell character varying(20),
    expected_demand character varying(20),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: procurement_matches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.procurement_matches (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    procurement_id uuid NOT NULL,
    matching_listing_id uuid NOT NULL,
    match_score integer DEFAULT 100,
    match_reason text,
    notified_buyer boolean DEFAULT false,
    notified_seller boolean DEFAULT false,
    status character varying(20) DEFAULT 'pending'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: promotion_usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.promotion_usage (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    promotion_id uuid NOT NULL,
    user_id uuid NOT NULL,
    purchase_id uuid,
    discount_cents bigint NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: promotions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.promotions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    seller_id uuid NOT NULL,
    listing_id uuid,
    store_id uuid,
    promotion_type character varying(20) NOT NULL,
    code character varying(50) NOT NULL,
    description text,
    value_percent integer NOT NULL,
    applies_to character varying(20) DEFAULT 'listing'::character varying,
    category character varying(100),
    min_purchase_cents bigint DEFAULT 0,
    max_discount_cents bigint,
    usage_limit integer,
    used_count integer DEFAULT 0,
    starts_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp without time zone,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT promotions_value_percent_check CHECK (((value_percent >= 1) AND (value_percent <= 99)))
);


--
-- Name: purchases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchases (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    buyer_id uuid NOT NULL,
    listing_id uuid NOT NULL,
    seller_id uuid NOT NULL,
    amount_cents bigint NOT NULL,
    shipping_address jsonb,
    paypal_transaction_id character varying(100),
    status character varying(50) DEFAULT 'pending'::character varying,
    tracking_number character varying(100),
    tracking_carrier character varying(50),
    estimated_delivery date,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    shipping_carrier character varying(50),
    shipping_service character varying(100),
    shipping_cost_cents bigint DEFAULT 0,
    estimated_delivery_days integer,
    delivery_method character varying(50) DEFAULT 'shipping'::character varying,
    pickup_deadline timestamp without time zone,
    platform_fee_cents bigint DEFAULT 0,
    seller_payout_cents bigint DEFAULT 0,
    paypal_order_id character varying(255),
    paypal_capture_id character varying(255),
    escrow_status character varying(50) DEFAULT 'pending'::character varying,
    buyer_role character varying(20) DEFAULT 'buyer'::character varying,
    seller_role character varying(20) DEFAULT 'seller'::character varying
);


--
-- Name: ratings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ratings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    order_id uuid NOT NULL,
    transaction_type character varying(50) DEFAULT 'purchase'::character varying,
    reviewer_id uuid NOT NULL,
    reviewee_id uuid NOT NULL,
    listing_id uuid,
    rating integer,
    feedback text,
    response_text text,
    would_recommend boolean DEFAULT true,
    item_as_described integer,
    communication integer,
    shipping_speed integer,
    release_escrow boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ratings_communication_check CHECK (((communication >= 1) AND (communication <= 5))),
    CONSTRAINT ratings_item_as_described_check CHECK (((item_as_described >= 1) AND (item_as_described <= 5))),
    CONSTRAINT ratings_rating_check CHECK (((rating >= 1) AND (rating <= 5))),
    CONSTRAINT ratings_shipping_speed_check CHECK (((shipping_speed >= 1) AND (shipping_speed <= 5)))
);


--
-- Name: sales_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_history (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    listing_id uuid,
    listing_title character varying(255),
    listing_type character varying(50),
    buyer_id uuid,
    seller_id uuid,
    amount_cents bigint,
    platform_fee_cents bigint,
    seller_payout_cents bigint,
    paypal_transaction_id character varying(100),
    shipping_address jsonb,
    tracking_number character varying(100),
    completed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    retained_until timestamp without time zone DEFAULT (CURRENT_TIMESTAMP + '3 years'::interval),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: saved_searches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.saved_searches (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    name character varying(255),
    search_type character varying(20) NOT NULL,
    filters jsonb NOT NULL,
    notification_frequency character varying(20) DEFAULT 'instant'::character varying,
    last_notified_at timestamp without time zone,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: search_matches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.search_matches (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    saved_search_id uuid NOT NULL,
    listing_id uuid NOT NULL,
    match_score integer DEFAULT 100,
    match_reason text,
    notified_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: seasonal_trends; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seasonal_trends (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    category character varying(100) NOT NULL,
    month integer NOT NULL,
    demand_multiplier numeric(3,2) DEFAULT 1.0,
    price_multiplier numeric(3,2) DEFAULT 1.0,
    keywords text[]
);


--
-- Name: seller_analytics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seller_analytics (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    seller_id uuid NOT NULL,
    date date NOT NULL,
    listings_active integer DEFAULT 0,
    sales_count integer DEFAULT 0,
    revenue_cents bigint DEFAULT 0,
    views integer DEFAULT 0,
    inquiries integer DEFAULT 0,
    conversion_rate numeric(5,2) DEFAULT 0,
    avg_response_time_minutes integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: seller_ratings_summary; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seller_ratings_summary (
    seller_id uuid NOT NULL,
    average_rating numeric(3,2) DEFAULT 0,
    total_ratings integer DEFAULT 0,
    five_star integer DEFAULT 0,
    four_star integer DEFAULT 0,
    three_star integer DEFAULT 0,
    two_star integer DEFAULT 0,
    one_star integer DEFAULT 0,
    item_as_described_avg numeric(3,2) DEFAULT 0,
    communication_avg numeric(3,2) DEFAULT 0,
    shipping_speed_avg numeric(3,2) DEFAULT 0,
    would_recommend_percent integer DEFAULT 0,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: shop_admins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop_admins (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    role character varying(50) DEFAULT 'moderator'::character varying,
    permissions jsonb DEFAULT '{"adjust_fees": false, "suspend_users": false, "view_analytics": true, "manage_disputes": true, "approve_listings": true}'::jsonb,
    created_by uuid,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: shop_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop_categories (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    category character varying(100) NOT NULL,
    display_name character varying(255) NOT NULL,
    parent_category character varying(100),
    icon character varying(10) DEFAULT '📦'::character varying,
    display_order integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    full_path character varying(500),
    level integer DEFAULT 1,
    sort_order integer DEFAULT 0
);


--
-- Name: shop_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop_messages (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    conversation_id uuid NOT NULL,
    sender_id uuid NOT NULL,
    message text NOT NULL,
    is_read boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: store_stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.store_stats (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    store_id uuid NOT NULL,
    views integer DEFAULT 0,
    orders integer DEFAULT 0,
    revenue_cents bigint DEFAULT 0,
    rating numeric(3,2) DEFAULT 0,
    review_count integer DEFAULT 0,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: stores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stores (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    seller_id uuid NOT NULL,
    store_name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    logo_url text,
    banner_url text,
    custom_domain character varying(255),
    is_custom_domain_verified boolean DEFAULT false,
    is_active boolean DEFAULT true,
    store_settings jsonb DEFAULT '{"allow_offers": true, "return_policy": "", "shipping_zones": [], "processing_time_days": 2}'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    paypal_email character varying(255),
    return_policy text,
    shipping_policy text,
    processing_time_days integer DEFAULT 2,
    settings jsonb DEFAULT '{"accept_offers": true, "vacation_mode": false, "shipping_zones": [], "vacation_message": "", "auto_approve_offers": false, "minimum_offer_percent": 50}'::jsonb,
    theme_color character varying(7) DEFAULT '#0b1f3f'::character varying,
    secondary_color character varying(7) DEFAULT '#ffd700'::character varying,
    text_color character varying(7) DEFAULT '#f5f5f5'::character varying,
    font_family character varying(50) DEFAULT 'Arial, sans-serif'::character varying,
    layout_style character varying(20) DEFAULT 'grid'::character varying,
    show_seller_info boolean DEFAULT true
);


--
-- Name: subscription_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_plans (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(50) NOT NULL,
    slug character varying(50) NOT NULL,
    description text,
    price_monthly_cents bigint,
    price_yearly_cents bigint,
    platform_fee_percent numeric(5,2) DEFAULT 5.0,
    features jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_tickets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    message text NOT NULL,
    category character varying(50) DEFAULT 'general'::character varying,
    status character varying(20) DEFAULT 'open'::character varying,
    admin_response text,
    responded_by uuid,
    responded_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: suspension_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suspension_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    admin_id uuid NOT NULL,
    action character varying(20) NOT NULL,
    duration_days integer,
    reason text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: testing_disclaimer; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.testing_disclaimer AS
 SELECT 'THIS IS A TESTING SYSTEM ONLY. No real currency or financial instruments are being offered. All clone currency transactions are mock/simulated. Regulatory approval is being sought.'::text AS disclaimer;


--
-- Name: transaction_ratings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transaction_ratings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    purchase_id uuid NOT NULL,
    listing_id uuid NOT NULL,
    rater_id uuid NOT NULL,
    ratee_id uuid NOT NULL,
    rating_type character varying(20) NOT NULL,
    overall_rating integer,
    communication_rating integer,
    payment_speed_rating integer,
    shipping_speed_rating integer,
    item_accuracy_rating integer,
    feedback text,
    is_public boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT transaction_ratings_communication_rating_check CHECK (((communication_rating >= 1) AND (communication_rating <= 5))),
    CONSTRAINT transaction_ratings_item_accuracy_rating_check CHECK (((item_accuracy_rating >= 1) AND (item_accuracy_rating <= 5))),
    CONSTRAINT transaction_ratings_overall_rating_check CHECK (((overall_rating >= 1) AND (overall_rating <= 5))),
    CONSTRAINT transaction_ratings_payment_speed_rating_check CHECK (((payment_speed_rating >= 1) AND (payment_speed_rating <= 5))),
    CONSTRAINT transaction_ratings_shipping_speed_rating_check CHECK (((shipping_speed_rating >= 1) AND (shipping_speed_rating <= 5)))
);


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    transaction_hash uuid DEFAULT public.uuid_generate_v4(),
    user_id uuid NOT NULL,
    type character varying(50) NOT NULL,
    amount_cents bigint NOT NULL,
    balance_after_cents bigint NOT NULL,
    currency_clone character varying(50) DEFAULT 'Credon-USD'::character varying,
    reference_id uuid,
    description text,
    is_mock boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: trusted_devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trusted_devices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    device_fingerprint text NOT NULL,
    user_agent text,
    ip_address inet,
    last_verified_at timestamp without time zone DEFAULT now(),
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: user_rating_summaries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_rating_summaries (
    user_id uuid NOT NULL,
    seller_avg_rating numeric(3,2) DEFAULT 0,
    seller_total_ratings integer DEFAULT 0,
    seller_communication_avg numeric(3,2) DEFAULT 0,
    seller_shipping_avg numeric(3,2) DEFAULT 0,
    seller_item_accuracy_avg numeric(3,2) DEFAULT 0,
    buyer_avg_rating numeric(3,2) DEFAULT 0,
    buyer_total_ratings integer DEFAULT 0,
    buyer_communication_avg numeric(3,2) DEFAULT 0,
    buyer_payment_speed_avg numeric(3,2) DEFAULT 0,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: user_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_subscriptions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    plan_id uuid NOT NULL,
    billing_cycle character varying(10) DEFAULT 'monthly'::character varying,
    status character varying(20) DEFAULT 'active'::character varying,
    started_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp without time zone,
    auto_renew boolean DEFAULT true,
    paypal_subscription_id character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    full_name character varying(255),
    whatsapp_number character varying(50),
    is_super_admin boolean DEFAULT false,
    is_suspended boolean DEFAULT false,
    suspension_end_date timestamp without time zone,
    suspension_reason text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_login timestamp without time zone,
    email_verified boolean DEFAULT false,
    email_verification_token character varying(255),
    password_reset_token character varying(255),
    password_reset_expires timestamp without time zone,
    last_mandatory_2fa timestamp without time zone,
    is_active boolean DEFAULT true,
    paypal_email character varying(255),
    referral_code character varying(20),
    referred_by uuid,
    affiliate_balance_cents bigint DEFAULT 0,
    total_referrals integer DEFAULT 0,
    total_affiliate_earned_cents bigint DEFAULT 0,
    max_listings integer DEFAULT 10,
    max_images_per_listing integer DEFAULT 3,
    can_use_bulk_import boolean DEFAULT false,
    can_create_promotions boolean DEFAULT false,
    can_customize_store boolean DEFAULT false,
    can_view_analytics boolean DEFAULT false,
    featured_listings_count integer DEFAULT 0,
    priority_support boolean DEFAULT false,
    current_plan_id uuid
);


--
-- Name: wallets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wallets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    balance_cents bigint DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: wishlists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wishlists (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    listing_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Data for Name: affiliate_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.affiliate_settings (id, setting_key, setting_value, updated_at) FROM stdin;
a0f55477-e899-4cf4-95b0-a46b80593c28	reward_tiers	{"gold": {"bonus_rate": 2.0, "min_referrals": 50}, "bronze": {"bonus_rate": 0.5, "min_referrals": 5}, "silver": {"bonus_rate": 1.0, "min_referrals": 20}, "platinum": {"bonus_rate": 3.0, "min_referrals": 100}, "standard": {"bonus_rate": 0, "min_referrals": 0}}	2026-04-22 08:50:36.492794
17f73b58-e3c6-4f82-bcf9-1293992af1d6	commission_structure	{"cookie_days": 730, "signup_bonus": 0, "seller_sale_rate": 1, "first_purchase_rate": 5, "minimum_payout_cents": 2500, "ongoing_purchase_rate": 2}	2026-04-22 12:41:37.727722
\.


--
-- Data for Name: analytics_daily; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.analytics_daily (id, date, total_sales, total_revenue_cents, platform_fee_cents, new_listings, new_users, active_users, page_views, unique_visitors, created_at) FROM stdin;
\.


--
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.appointments (id, user_id, appointment_time, duration_minutes, status, cancellation_token, whatsapp_contact_added, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: auction_bids; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auction_bids (id, listing_id, bidder_id, amount_cents, is_winning, created_at, quantity, winning_quantity, clearing_price_cents) FROM stdin;
fa7eac9b-1b0c-4746-8945-de8f20696983	cda0ab23-2668-4902-9618-676b8fdb96c1	dfb80e70-2782-4e00-a328-384d8806897f	100	t	2026-04-15 06:31:41.86484	1	0	\N
760a913f-2f1e-40a4-8e28-7e4470028b99	d18ffb55-7c93-4007-a60d-a449edd396c3	dfb80e70-2782-4e00-a328-384d8806897f	100	t	2026-04-15 07:19:53.803642	1	0	\N
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, admin_id, action, target_type, target_id, details, ip_address, created_at) FROM stdin;
c8f6604a-e184-493d-be07-a0f5af1ad003	dfb80e70-2782-4e00-a328-384d8806897f	approve_listing	listing	10b75adb-1bc1-4547-bc43-19a27763e6bc	{}	\N	2026-04-14 06:51:48.74676
b6d65f92-e943-4e30-be3d-ed09aa1cfbd7	dfb80e70-2782-4e00-a328-384d8806897f	approve_listing	listing	8b60c7b1-aed8-4f35-865d-1d96c71fbb4d	{}	\N	2026-04-14 09:44:51.456194
e571f05c-8341-4707-97de-bdcf3448cd0c	dfb80e70-2782-4e00-a328-384d8806897f	approve_listing	listing	83e1ef97-d9db-4101-b092-bf01c6a0fa99	{}	\N	2026-04-14 10:53:06.734295
80c2b539-63b2-42fa-980e-6c6b823fd062	dfb80e70-2782-4e00-a328-384d8806897f	approve_listing	listing	64193ab0-3546-4c83-9a2d-06651461ba80	{}	\N	2026-04-14 21:06:37.948999
5b48cec9-dc91-4909-a083-348cdaa3227b	dfb80e70-2782-4e00-a328-384d8806897f	approve_listing	listing	c1d049d3-cb99-4478-a99c-bdf1c8882100	{}	\N	2026-04-15 02:57:04.587416
7275d9de-9df6-4f3a-a0c2-6d4c3428768d	dfb80e70-2782-4e00-a328-384d8806897f	approve_listing	listing	10fbf492-a8a5-40c9-8143-f6e944161c0c	{}	\N	2026-04-15 03:12:48.771465
4b15068c-25ca-4a48-b207-918f07aa5a93	dfb80e70-2782-4e00-a328-384d8806897f	approve_listing	listing	cda0ab23-2668-4902-9618-676b8fdb96c1	{}	\N	2026-04-15 05:58:04.873994
a6c7a7e1-e762-4187-ba4f-3b371db59823	dfb80e70-2782-4e00-a328-384d8806897f	approve_listing	listing	d18ffb55-7c93-4007-a60d-a449edd396c3	{}	\N	2026-04-15 07:16:51.509056
ad2a37ce-6c43-42e1-8f5a-48170fe81545	dfb80e70-2782-4e00-a328-384d8806897f	update_platform_fee	platform_settings	\N	{"fee_percent": 5}	\N	2026-04-15 08:51:53.630331
b5e34a5d-d395-4874-bfc7-ec8ae8515486	dfb80e70-2782-4e00-a328-384d8806897f	approve_listing	listing	ea68dd51-f813-4c38-a893-6de757dfcd94	{}	\N	2026-04-15 09:15:13.393003
662b670e-7ebd-4246-9dea-89c72d4ca0e8	dfb80e70-2782-4e00-a328-384d8806897f	approve_listing	listing	8d2dd8d9-2136-42e1-9900-876d7de38c35	{}	\N	2026-04-15 09:48:29.559492
19228796-f5a0-4edd-b8b2-6c9e9f3d4d05	dfb80e70-2782-4e00-a328-384d8806897f	approve_listing	listing	d67ea8cc-fe4b-477a-a748-42f930305818	{}	\N	2026-04-15 10:29:34.053179
82b47d6d-c815-4f4e-a84c-236be67691a0	dfb80e70-2782-4e00-a328-384d8806897f	approve_listing	listing	702df270-98b1-48d9-9994-9a5abe05ff8f	{}	\N	2026-04-15 14:29:41.789525
78d81b3b-82cd-4236-9315-a39e66439cec	dfb80e70-2782-4e00-a328-384d8806897f	approve_listing	listing	44dfff4e-8151-4541-b235-2ce931af2b3f	{}	\N	2026-04-15 17:19:20.042012
a553b59f-9b57-4bb3-baa3-2cf5678345a2	dfb80e70-2782-4e00-a328-384d8806897f	approve_listing	listing	c93b6c4e-3f44-476b-b649-523b1262b392	{}	\N	2026-04-15 17:19:21.708573
8f86e6ba-da32-4467-8627-4640c0ebe322	dfb80e70-2782-4e00-a328-384d8806897f	approve_listing	listing	18dc44ca-8169-4e32-b607-2e4854fe1b40	{}	\N	2026-04-15 17:19:26.534065
92fc7912-91fa-48aa-a379-33369145ccdd	dfb80e70-2782-4e00-a328-384d8806897f	approve_listing	listing	d19b67d5-943e-4c96-80f8-895d2a23c58a	{}	\N	2026-04-15 17:19:27.541436
3a7e5594-1a66-4f88-b7de-7a9095d1b350	dfb80e70-2782-4e00-a328-384d8806897f	approve_listing	listing	cbee725d-f42a-4581-962e-63bc22787f1a	{}	\N	2026-04-19 02:52:00.499632
3d722b10-3336-4a5c-a9c7-ceb778da09c1	dfb80e70-2782-4e00-a328-384d8806897f	update_platform_fee	platform_settings	\N	{"fee_percent": 12}	\N	2026-04-22 12:42:32.404042
882261fd-9109-4ba5-97ea-a3c91d835517	dfb80e70-2782-4e00-a328-384d8806897f	update_platform_fee	platform_settings	\N	{"fee_percent": 17}	\N	2026-04-22 12:54:56.727581
\.


--
-- Data for Name: bids; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bids (id, user_id, type, from_currency, to_currency, amount_cents, exchange_rate, status, matched_bid_id, expires_at, is_mock, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: carts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.carts (id, user_id, listing_id, quantity, created_at, updated_at, last_activity, reminder_sent, reminder_sent_at, reminder_count) FROM stdin;
\.


--
-- Data for Name: category_analytics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.category_analytics (id, date, category, listings_count, sales_count, revenue_cents, avg_price_cents, views, created_at) FROM stdin;
\.


--
-- Data for Name: category_suggestions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.category_suggestions (id, user_id, parent_category, suggested_name, description, status, admin_notes, reviewed_by, reviewed_at, created_at) FROM stdin;
97c285ab-bb83-4c7e-9eff-baa47d204126	dfb80e70-2782-4e00-a328-384d8806897f	\N	Real Estate	Real estate listing ads.	approved	\N	dfb80e70-2782-4e00-a328-384d8806897f	2026-04-13 20:32:15.760615	2026-04-13 19:19:32.257326
5b87a706-44d7-44b1-9cfb-bab705040e49	dfb80e70-2782-4e00-a328-384d8806897f	\N	Personals	Personals listing ads.	approved	\N	dfb80e70-2782-4e00-a328-384d8806897f	2026-04-13 20:38:48.575418	2026-04-13 20:36:31.449682
edfb272d-1a85-4d01-9a8b-4a9098e84801	dfb80e70-2782-4e00-a328-384d8806897f	real_estate	Apartments	Listings for apartments.	approved	\N	dfb80e70-2782-4e00-a328-384d8806897f	2026-04-13 21:01:48.084087	2026-04-13 21:00:52.724486
d8c352c0-2ef1-4219-b899-90e0ba56e976	dfb80e70-2782-4e00-a328-384d8806897f	real_estate	Other	Other types of real estate.	approved	\N	dfb80e70-2782-4e00-a328-384d8806897f	2026-04-13 21:11:23.221125	2026-04-13 21:06:42.785036
4f3ed385-c588-4906-b688-6e5f81e13c1d	dfb80e70-2782-4e00-a328-384d8806897f	real_estate	Houses	Houses for sale and wanted listings.	approved	\N	dfb80e70-2782-4e00-a328-384d8806897f	2026-04-13 21:11:40.230781	2026-04-13 21:08:00.743584
9a0e29c4-8846-44ba-ba14-27c3d556fe2c	dfb80e70-2782-4e00-a328-384d8806897f	real_estate	Mansions	Mansions for sale and wanted listing ads.	approved	\N	dfb80e70-2782-4e00-a328-384d8806897f	2026-04-13 21:11:55.182247	2026-04-13 21:08:59.197149
f230638b-48de-49a3-bed0-3a0cf0297a8e	dfb80e70-2782-4e00-a328-384d8806897f	personals	Men Seeking Women	Men seeking women listing ads.	approved	\N	dfb80e70-2782-4e00-a328-384d8806897f	2026-04-14 01:51:53.96485	2026-04-14 01:47:24.530603
f5253d4b-343c-468f-8d73-1a733557b791	dfb80e70-2782-4e00-a328-384d8806897f	personals	Men Seeking Men	Men seeking men listing ads.	approved	\N	dfb80e70-2782-4e00-a328-384d8806897f	2026-04-14 01:52:09.051804	2026-04-14 01:48:28.707806
8c0cc2d3-856b-4a98-b2cb-5ca5bb89f2e1	dfb80e70-2782-4e00-a328-384d8806897f	personals	Women Seeking Men	Women seeking men listing ads.	approved	\N	dfb80e70-2782-4e00-a328-384d8806897f	2026-04-14 01:52:25.250202	2026-04-14 01:49:26.124836
b58132ac-1c51-4990-95e4-3ce9d5c02ca0	dfb80e70-2782-4e00-a328-384d8806897f	personals	Women Seeking Women	Women seeking women listing ads.	approved	\N	dfb80e70-2782-4e00-a328-384d8806897f	2026-04-14 01:52:48.052421	2026-04-14 01:50:24.406394
cbf3dd19-fb67-466d-bd4e-ab36fe79a3e8	dfb80e70-2782-4e00-a328-384d8806897f	50___60_year_olds	Virtual Relationship	Viirtual relationship listing ads.	approved	\N	dfb80e70-2782-4e00-a328-384d8806897f	2026-04-14 06:17:24.672559	2026-04-14 05:50:03.661141
\.


--
-- Data for Name: category_translations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.category_translations (id, category, language_code, name, translated_by, created_at, updated_at) FROM stdin;
40d7b9d4-57bd-4e18-b18c-31433ab10918	18___20_year_olds	es	Silencio 18 - 20 años	auto	2026-04-24 05:28:21.76823+00	2026-04-24 05:28:21.76823+00
2ca0c687-0560-43c3-bbfd-9b60a5b2d01e	18___20_year_olds	fr	18 - 20 ans	auto	2026-04-24 05:28:21.868157+00	2026-04-24 05:28:21.868157+00
668659c3-b306-434d-b1ab-51dc3ed7f1d9	18___20_year_olds	de	| 18 - 20 Jahre	auto	2026-04-24 05:28:21.998965+00	2026-04-24 05:28:21.998965+00
66412a15-175a-44ce-b06b-6efd0f4cfbbf	18___20_year_olds	zh	* 18至20岁	auto	2026-04-24 05:28:22.232352+00	2026-04-24 05:28:22.232352+00
aa1fc911-8342-41de-bd23-ae91e837f12a	18___20_year_olds	ja	| 18歳～20歳	auto	2026-04-24 05:28:22.372425+00	2026-04-24 05:28:22.372425+00
b41549d7-9dcd-42dc-9879-7a2d98b2d045	18___20_year_olds	ko	| 18세～20세	auto	2026-04-24 05:28:22.514509+00	2026-04-24 05:28:22.514509+00
69554c83-19f1-484d-be79-d64641f1f166	18___20_year_olds	vi	18 - 20 tuổi	auto	2026-04-24 05:28:22.627676+00	2026-04-24 05:28:22.627676+00
af3b7a8b-e4bc-4e3f-abe8-19cd4d1418d1	18___20_year_olds	tr	| 18 - 20 Yıl Yaşlılar	auto	2026-04-24 05:28:22.946882+00	2026-04-24 05:28:22.946882+00
132dd356-486a-4b11-aba1-4b8dc47fdb8b	18___20_year_olds	ar	18-20 سنة	auto	2026-04-24 05:28:23.088633+00	2026-04-24 05:28:23.088633+00
6ab28dc9-e533-42b0-ba2f-fea61077440d	18___20_year_olds	fa	18 - 20 ساله	auto	2026-04-24 05:28:23.522146+00	2026-04-24 05:28:23.522146+00
d15478a1-5b7e-41be-947e-f2aaa7261b2f	18___20_year_olds	ur	18 - 20 سال-	auto	2026-04-24 05:28:23.793932+00	2026-04-24 05:28:23.793932+00
134a9b58-050e-445a-877f-c35b44472d1d	18___20_year_olds	hi	18 - 20 वर्ष पुराना	auto	2026-04-24 05:28:24.123565+00	2026-04-24 05:28:24.123565+00
604f9e83-5c5c-4d32-811f-94c5b66733c9	18___20_year_olds	pt	18 - 20 anos	auto	2026-04-24 05:28:24.273488+00	2026-04-24 05:28:24.273488+00
542c3a0a-2523-4389-b6f4-3e8930e1f11e	18___20_year_olds	ru	18 - 20 летние дети	auto	2026-04-24 05:28:24.924292+00	2026-04-24 05:28:24.924292+00
0aaa477c-a0be-4fe1-b474-c3439eb82507	18___20_year_olds	sv	18 - 20 år gammal	auto	2026-04-24 05:28:25.273977+00	2026-04-24 05:28:25.273977+00
24295555-6c4f-4536-8fbb-6bd43feff067	18___20_year_olds	tl	Tagapangulo 18 - 20 Taóng-Luma	auto	2026-04-24 05:28:25.67555+00	2026-04-24 05:28:25.67555+00
21ba61c9-625f-433b-be37-59593e36cb0e	other_8	es	Silencio	auto	2026-04-24 05:28:26.956349+00	2026-04-24 05:28:26.956349+00
fcfc0599-93f0-40af-bf9a-1503bfad6a5f	other_8	fr	Autres	auto	2026-04-24 05:28:27.174885+00	2026-04-24 05:28:27.174885+00
65d299d3-55b1-427e-9956-3447423fb2e3	other_8	de	Sonstige	auto	2026-04-24 05:28:27.228609+00	2026-04-24 05:28:27.228609+00
e74e130d-fb5f-4ee1-ae9a-b48831855247	other_8	zh	其他情况	auto	2026-04-24 05:28:27.303018+00	2026-04-24 05:28:27.303018+00
5ff35ba6-f16b-41f2-9aa5-d3cb11523a96	other_8	ja	| その他	auto	2026-04-24 05:28:27.37614+00	2026-04-24 05:28:27.37614+00
47f309f9-cce7-496c-979c-860f135dfe3d	other_8	ko	| 기타	auto	2026-04-24 05:28:27.452962+00	2026-04-24 05:28:27.452962+00
23816541-1f52-4fcb-9a71-c67adf6ab6df	other_8	vi	Người khác	auto	2026-04-24 05:28:27.560872+00	2026-04-24 05:28:27.560872+00
1dd126a9-62af-4df9-a033-7ac793308f11	other_8	tr	Diğer	auto	2026-04-24 05:28:27.634526+00	2026-04-24 05:28:27.634526+00
5ee32d6a-3aad-472e-bd50-40513c190267	other_8	ar	| آخر	auto	2026-04-24 05:28:27.806549+00	2026-04-24 05:28:27.806549+00
d56c786b-0458-4ce8-b4bf-178ad6b091b5	other_8	fa	دیگر	auto	2026-04-24 05:28:27.877233+00	2026-04-24 05:28:27.877233+00
f996b660-6746-4d13-b528-64923fb1ee48	other_8	ur	کچھ اور	auto	2026-04-24 05:28:27.958715+00	2026-04-24 05:28:27.958715+00
9bcac67b-76b9-4d38-bd8b-662bf96cfb33	other_8	hi	अन्य	auto	2026-04-24 05:28:28.154953+00	2026-04-24 05:28:28.154953+00
f32b7d88-3be0-4066-90b2-ec1be9ed53fb	other_8	pt	Outros	auto	2026-04-24 05:28:28.232973+00	2026-04-24 05:28:28.232973+00
81340eb4-4e03-42f0-bfd7-3a076446ff5b	other_8	ru	Другое	auto	2026-04-24 05:28:28.327121+00	2026-04-24 05:28:28.327121+00
e9dc4bee-bba0-4cdc-848a-a7937c4518ce	other_8	sv	Övriga	auto	2026-04-24 05:28:28.617906+00	2026-04-24 05:28:28.617906+00
c1618c4c-f318-4c73-952e-8ccbc66ff6e9	other_8	tl	Ulis	auto	2026-04-24 05:28:28.781258+00	2026-04-24 05:28:28.781258+00
4f6538a4-76ff-490c-a75f-dc3c22a9977d	casual_dating	es	Citas casuales	auto	2026-04-24 05:28:29.948936+00	2026-04-24 05:28:29.948936+00
5ffc11e6-2836-4830-8dea-730f25cec548	casual_dating	fr	Rencontres occasionnelles	auto	2026-04-24 05:28:30.092588+00	2026-04-24 05:28:30.092588+00
01c31179-a14b-41e1-a9a0-80e2775e7e33	casual_dating	de	| Lässiges Dating	auto	2026-04-24 05:28:30.872277+00	2026-04-24 05:28:30.872277+00
fafc1ac5-6ca4-4202-8726-9fba939072d6	casual_dating	zh	临时约会	auto	2026-04-24 05:28:30.986091+00	2026-04-24 05:28:30.986091+00
3a78c502-84b2-4de8-a29c-9b9ff5ed16b2	casual_dating	ja	| カジュアルデート	auto	2026-04-24 05:28:31.461804+00	2026-04-24 05:28:31.461804+00
30468823-7871-4d66-be06-2fbcce4a570a	casual_dating	ko	| 캐주얼 데이트	auto	2026-04-24 05:28:31.688237+00	2026-04-24 05:28:31.688237+00
2a6062e2-d637-4f77-93e5-b04185a23b7f	casual_dating	vi	Hẹn hò bình thường	auto	2026-04-24 05:28:31.925015+00	2026-04-24 05:28:31.925015+00
cbff7f1d-a4b7-43a2-9edd-49a383c6dd9a	casual_dating	tr	| Gündelik Arkadaşlık	auto	2026-04-24 05:28:32.78619+00	2026-04-24 05:28:32.78619+00
377800a7-873b-428e-bf19-d1d9a8cebcf2	casual_dating	ar	♪ ♪	auto	2026-04-24 05:28:33.014113+00	2026-04-24 05:28:33.014113+00
60336605-0917-4546-ab45-c97db1913e9c	casual_dating	fa	● آشنایی موقت	auto	2026-04-24 05:28:33.250009+00	2026-04-24 05:28:33.250009+00
03b11b71-54aa-4e06-9e9a-49e0174290bc	casual_dating	ur	| کي بورڈنگ	auto	2026-04-24 05:28:52.495893+00	2026-04-24 05:28:52.495893+00
3c78bc2e-f385-43b7-9e45-8497659a7051	casual_dating	hi	डेटिंग	auto	2026-04-24 05:28:53.309919+00	2026-04-24 05:28:53.309919+00
2d2fc8ae-bae7-458d-9317-f980fd0fd185	casual_dating	pt	Namoro Casual	auto	2026-04-24 05:28:53.602116+00	2026-04-24 05:28:53.602116+00
93977895-aed8-4be7-94c9-cadc971afff2	casual_dating	ru	Случайные свидания	auto	2026-04-24 05:28:53.814175+00	2026-04-24 05:28:53.814175+00
144d9090-6cc1-4eda-b9b7-a6269eda821d	casual_dating	sv	Casual dating	auto	2026-04-24 05:28:54.152053+00	2026-04-24 05:28:54.152053+00
b48424ad-83f6-4f8b-a204-92f06127379a	casual_dating	tl	Walang - Saysay na Pakikipag - date	auto	2026-04-24 05:28:54.51717+00	2026-04-24 05:28:54.51717+00
4362a049-5058-46de-bc2e-8564292147c8	long_term_relationship	es	← Relación a largo plazo	auto	2026-04-24 05:28:55.703557+00	2026-04-24 05:28:55.703557+00
2240dfcb-fd40-490b-84b4-31ac2007b9c4	long_term_relationship	fr	Relation à long terme	auto	2026-04-24 05:28:55.796155+00	2026-04-24 05:28:55.796155+00
f99c97b6-fbfc-4bae-9e45-160231bd7960	long_term_relationship	de	| Langfristige Beziehungen	auto	2026-04-24 05:28:55.914547+00	2026-04-24 05:28:55.914547+00
d8b7f3ef-e864-47cf-8c9e-4dbe38c230a4	long_term_relationship	zh	* 长期关系	auto	2026-04-24 05:28:56.017879+00	2026-04-24 05:28:56.017879+00
2315bf50-5ce7-4503-b7c3-75012c7ad972	long_term_relationship	ja	| 長期関係	auto	2026-04-24 05:28:56.718344+00	2026-04-24 05:28:56.718344+00
ba80782f-57fe-4a5b-a7af-6be33c10bd79	long_term_relationship	ko	| 장기 관계	auto	2026-04-24 05:28:57.057096+00	2026-04-24 05:28:57.057096+00
023fd09b-f660-494e-bc23-99d9738ee3e4	long_term_relationship	vi	Mối quan hệ lâu dài	auto	2026-04-24 05:28:57.326311+00	2026-04-24 05:28:57.326311+00
f7aed76d-8186-420f-8441-aed951f18f47	long_term_relationship	tr	| Uzun Süreli İlişki	auto	2026-04-24 05:28:57.449542+00	2026-04-24 05:28:57.449542+00
9fdf3ea3-b94c-4165-bb25-2b515b03ee88	long_term_relationship	ar	Long-Term Relationship	auto	2026-04-24 05:28:57.605588+00	2026-04-24 05:28:57.605588+00
58d340db-8cc3-43d8-943b-8375e771441e	long_term_relationship	fa	رابطه طولانی مدت	auto	2026-04-24 05:28:57.710992+00	2026-04-24 05:28:57.710992+00
cdb514ca-f503-4e51-87a8-f5bfe900e8f0	long_term_relationship	ur	Long طویل تعلقات	auto	2026-04-24 05:28:57.898581+00	2026-04-24 05:28:57.898581+00
9ce880e6-5707-4264-b8e1-49064b9f62d3	long_term_relationship	hi	दीर्घकालिक संबंध	auto	2026-04-24 05:28:57.984306+00	2026-04-24 05:28:57.984306+00
307abd51-7fdf-4d5d-b403-d72829823e8c	long_term_relationship	pt	Relacionamento a Longo Prazo	auto	2026-04-24 05:28:58.152345+00	2026-04-24 05:28:58.152345+00
bd77abf5-4f21-4f6f-9d46-b978b9c9c8ef	collectibles	fr	Collections	auto	2026-04-24 05:21:44.939187+00	2026-04-24 05:29:16.462928+00
2b13ae6f-b0db-47ac-aeed-92f7b5696070	collectibles	de	| Sammlerstücke	auto	2026-04-24 05:21:45.006975+00	2026-04-24 05:29:16.566589+00
ff4c55c9-d498-4f9f-b94f-44613c733331	collectibles	zh	收集器	auto	2026-04-24 05:21:45.084691+00	2026-04-24 05:29:16.889656+00
2bda1a52-43f7-4fa9-bfa9-e62271ef4d2e	collectibles	ja	| グッズ	auto	2026-04-24 05:21:45.159329+00	2026-04-24 05:29:17.23601+00
42694ce8-5567-4c1f-8e04-31f499067ff9	collectibles	ko	| 수집	auto	2026-04-24 05:22:11.215887+00	2026-04-24 05:29:17.539507+00
07267df4-b1ae-4500-b255-50b51242d51f	collectibles	vi	teppi82	auto	2026-04-24 05:22:12.016356+00	2026-04-24 05:29:17.805399+00
251b5882-c554-4fc4-bc9c-fc78e43420d8	collectibles	tr	| Toplanabilirler	auto	2026-04-24 05:22:12.838461+00	2026-04-24 05:29:17.897845+00
f1084f3a-98fd-41a8-b1fc-fe948ee9b684	collectibles	ar	مجموع	auto	2026-04-24 05:22:12.922349+00	2026-04-24 05:29:17.992913+00
1891003e-a2e2-4241-bcb1-8d5555cd6fef	collectibles	fa	جمع آوری امکان	auto	2026-04-24 05:22:13.256931+00	2026-04-24 05:29:18.34349+00
026c38f9-f758-41fb-a7c4-c6faac0a8320	collectibles	ur	جمع	auto	2026-04-24 05:22:13.320158+00	2026-04-24 05:29:18.436519+00
b3ef2921-458a-42d3-a7ee-770e0420bdfc	collectibles	hi	| संग्रहणीय	auto	2026-04-24 05:22:13.376358+00	2026-04-24 05:29:32.994574+00
4526e9cd-f302-4aaa-82ad-f6cc136b5032	collectibles	pt	□ Colecionáveis	auto	2026-04-24 05:22:13.468167+00	2026-04-24 05:29:33.307275+00
0e5ce516-8262-4f2b-8af4-405cc422c68c	collectibles	ru	Коллекционные	auto	2026-04-24 05:22:14.205435+00	2026-04-24 05:29:33.877704+00
bfc0133d-fc82-4e75-a69b-2ec3439dcc89	collectibles	sv	| Samlare	auto	2026-04-24 05:22:14.298434+00	2026-04-24 05:29:34.021052+00
1cf52853-5ca4-499a-bc0e-1892e3bedd39	collectibles	tl	Mga Koleksiyon ng Eksperimento	auto	2026-04-24 05:22:14.404276+00	2026-04-24 05:29:34.252733+00
07b7d602-b6e9-460a-b33a-e43ea98d8f88	long_term_relationship	ru	Долгосрочные отношения	auto	2026-04-24 05:28:58.348149+00	2026-04-24 05:28:58.348149+00
82d77384-3cdc-48e2-a67f-c64861bc3367	long_term_relationship	sv	Långsiktigt förhållande	auto	2026-04-24 05:28:58.462147+00	2026-04-24 05:28:58.462147+00
1aa6fade-46f6-438a-a800-45184aec302e	long_term_relationship	tl	Mabuting Ugnayan	auto	2026-04-24 05:28:58.673864+00	2026-04-24 05:28:58.673864+00
4f2b939b-426d-49fd-ab8f-2b3a2c25414e	electronics	es	tención electrónica	auto	2026-04-24 05:28:59.794334+00	2026-04-24 05:28:59.794334+00
9c935044-d11a-4986-a92d-b130347f6cc4	electronics	fr	Électronique	auto	2026-04-24 05:28:59.89376+00	2026-04-24 05:28:59.89376+00
a2145be5-8e15-4886-a342-89750410cfa2	electronics	de	| Elektronik	auto	2026-04-24 05:29:00.137713+00	2026-04-24 05:29:00.137713+00
dd2e7bd4-81f9-433e-97ef-2c93546ee5e0	electronics	zh	电子	auto	2026-04-24 05:29:00.385845+00	2026-04-24 05:29:00.385845+00
a7d74e07-0eda-448d-9f0d-2c6cc237d2d9	electronics	ja	| エレクトロニクス	auto	2026-04-24 05:29:00.455489+00	2026-04-24 05:29:00.455489+00
b1a72a8b-576e-43db-8711-174e748ecfc4	electronics	ko	| 전자	auto	2026-04-24 05:29:00.525847+00	2026-04-24 05:29:00.525847+00
c2756066-2cd7-4bcb-ac67-ced974416aa6	electronics	vi	Name	auto	2026-04-24 05:29:00.615695+00	2026-04-24 05:29:00.615695+00
450b36b5-183f-414f-a504-113ebb0aae06	electronics	tr	| Elektronik	auto	2026-04-24 05:29:00.773998+00	2026-04-24 05:29:00.773998+00
c64a80fe-bae3-4d62-948a-c3b3222495cc	electronics	ar	| إلكترونيات	auto	2026-04-24 05:29:01.053532+00	2026-04-24 05:29:01.053532+00
e011b99d-2601-4d87-a6b5-3a9f9d5514db	electronics	fa	الکترونیک	auto	2026-04-24 05:29:01.409112+00	2026-04-24 05:29:01.409112+00
bdd3916d-8757-4b79-b132-ead88fb15eff	electronics	ur	| الیکٹرانکس	auto	2026-04-24 05:29:01.677398+00	2026-04-24 05:29:01.677398+00
824e1612-d6b1-42c8-b383-259228d1a2b6	electronics	hi	इलेक्ट्रॉनिक्स	auto	2026-04-24 05:29:01.795375+00	2026-04-24 05:29:01.795375+00
3f806d70-3984-46fa-974a-1b81dd584196	electronics	pt	• Electrónica	auto	2026-04-24 05:29:01.931417+00	2026-04-24 05:29:01.931417+00
11b6df7d-989e-4366-a9b6-fced079511e6	electronics	ru	Электроника	auto	2026-04-24 05:29:02.478166+00	2026-04-24 05:29:02.478166+00
3766f624-9bc9-4a6b-89ea-92d787807f33	electronics	sv	Elektronik	auto	2026-04-24 05:29:02.798699+00	2026-04-24 05:29:02.798699+00
42bd3125-d0f6-41db-bde4-9682a77a8d32	electronics	tl	Mga Elektroniko ng Eksperimento	auto	2026-04-24 05:29:03.278352+00	2026-04-24 05:29:03.278352+00
a7ffef2e-0e97-4306-8322-6f3d39eec4aa	fashion	es	Moda permanente	auto	2026-04-24 05:29:04.702249+00	2026-04-24 05:29:04.702249+00
dca8153f-0388-49c6-bda5-aa0646759847	fashion	fr	Mode	auto	2026-04-24 05:29:07.963407+00	2026-04-24 05:29:07.963407+00
5488d882-8172-4d9d-8d1c-7873ee5850f0	fashion	de	| Mode	auto	2026-04-24 05:29:08.232281+00	2026-04-24 05:29:08.232281+00
c3946caa-86f8-40b8-8218-157188ffb860	fashion	zh	时尚	auto	2026-04-24 05:29:08.329036+00	2026-04-24 05:29:08.329036+00
2e83a9cd-0a7d-4626-92a2-71d74a35bda1	fashion	ja	| ファッション	auto	2026-04-24 05:29:08.408456+00	2026-04-24 05:29:08.408456+00
1d2aaf7b-4572-4bfa-86a7-156dd99cb7e3	fashion	ko	| 패션	auto	2026-04-24 05:29:08.713433+00	2026-04-24 05:29:08.713433+00
a6073e0d-05fe-47af-b6e1-0767dc91da0c	fashion	vi	Thời trang	auto	2026-04-24 05:29:08.828843+00	2026-04-24 05:29:08.828843+00
f40bbe17-b518-4d23-9b83-d6990b843e84	fashion	ar	| موضة	auto	2026-04-24 05:29:09.794524+00	2026-04-24 05:29:09.794524+00
cf2db217-b023-459b-811d-0993ead535cc	fashion	fa	مد	auto	2026-04-24 05:29:09.915764+00	2026-04-24 05:29:09.915764+00
cff1cf71-f76a-439d-ab48-6ab69338de6a	fashion	ur	وائیرڈ فیشن	auto	2026-04-24 05:29:10.12923+00	2026-04-24 05:29:10.12923+00
4934ae09-2029-46bd-a4b4-d044ef6d0905	fashion	hi	फैशन	auto	2026-04-24 05:29:10.446254+00	2026-04-24 05:29:10.446254+00
745ddab2-d148-4f16-923a-7d4cced6db8d	fashion	pt	Moda	auto	2026-04-24 05:29:10.523245+00	2026-04-24 05:29:10.523245+00
24270e13-8275-4cfc-8227-3638c04b5a25	fashion	ru	Мода	auto	2026-04-24 05:29:10.651756+00	2026-04-24 05:29:10.651756+00
d3edf0e1-97a4-4767-9fee-49dc16bad150	fashion	sv	Mode	auto	2026-04-24 05:29:10.732419+00	2026-04-24 05:29:10.732419+00
cc5cc0e8-d28e-49a8-a9ab-9144f704e502	fashion	tl	Uso	auto	2026-04-24 05:29:10.832386+00	2026-04-24 05:29:10.832386+00
dbddbdb8-78b5-43d0-a917-ba05dcf84d2a	home_garden	es	Home & Garden	auto	2026-04-24 05:29:12.065709+00	2026-04-24 05:29:12.065709+00
b3859427-eda2-4fcc-a0e2-e7198ee3e1f2	home_garden	fr	Maison et jardin	auto	2026-04-24 05:29:12.283764+00	2026-04-24 05:29:12.283764+00
6260dfae-b1a2-44e2-8d84-4cd394473db1	home_garden	de	| Home & Garten	auto	2026-04-24 05:29:12.392708+00	2026-04-24 05:29:12.392708+00
578d8381-d9d2-4d78-89ca-6d57311153ab	home_garden	zh	家花园	auto	2026-04-24 05:29:12.547919+00	2026-04-24 05:29:12.547919+00
60df546d-53fa-4356-87fb-96dcfa1844dd	home_garden	ja	| ホーム&ガーデン	auto	2026-04-24 05:29:12.659664+00	2026-04-24 05:29:12.659664+00
e85721d8-3cf8-46d9-b7a2-c41bfd439890	home_garden	ko	| 홈 & 가든	auto	2026-04-24 05:29:12.783972+00	2026-04-24 05:29:12.783972+00
4fca8604-cbc7-4e64-a323-6e979eea5e5f	home_garden	vi	Vườn và Nhà	auto	2026-04-24 05:29:12.907241+00	2026-04-24 05:29:12.907241+00
69f0990c-d663-48e7-9379-42f135a5fe5a	home_garden	tr	| Ev ve Bahçe	auto	2026-04-24 05:29:13.297361+00	2026-04-24 05:29:13.297361+00
5eccc284-9074-44cc-84b2-b7edc357a84f	home_garden	ar	| Home ' Garden	auto	2026-04-24 05:29:13.428927+00	2026-04-24 05:29:13.428927+00
f1c2b367-07c8-456d-bfbc-3370a8bb2679	home_garden	fa	خانه و باغ	auto	2026-04-24 05:29:13.789479+00	2026-04-24 05:29:13.789479+00
1c6d7b4f-b208-4496-829a-9d4dfb03ab19	home_garden	ur	| گھر اور باغ	auto	2026-04-24 05:29:13.946521+00	2026-04-24 05:29:13.946521+00
f2cbd3dc-6db1-4685-bfdf-3d856f43fa6f	home_garden	hi	होम गार्डन	auto	2026-04-24 05:29:14.064398+00	2026-04-24 05:29:14.064398+00
71d0ddfe-b0b0-46c7-94d4-d23a3bdc98b9	home_garden	pt	Casa e Jardim	auto	2026-04-24 05:29:14.337645+00	2026-04-24 05:29:14.337645+00
eb4a256b-7ac5-491b-ac83-2515d6000a89	home_garden	ru	Home & Garden	auto	2026-04-24 05:29:14.570186+00	2026-04-24 05:29:14.570186+00
1c8e5295-a273-4e1c-9af9-6be28a97dfa1	home_garden	tl	Uso Tahanan & Hardin	auto	2026-04-24 05:29:15.214866+00	2026-04-24 05:29:15.214866+00
01a6b45a-5917-4c60-b5c1-fdf93470b432	collectibles	es	Silencio Coleccionables	auto	2026-04-24 05:21:44.243443+00	2026-04-24 05:29:16.367348+00
38c0886a-d32f-4efc-bb7d-90719707d8af	vehicles	es	vehículos permanentes	auto	2026-04-24 05:29:36.045938+00	2026-04-24 05:29:36.045938+00
200df722-3b68-4a6b-895a-1448f6ff09fd	vehicles	fr	Véhicules	auto	2026-04-24 05:29:36.107255+00	2026-04-24 05:29:36.107255+00
824d977e-eefa-4354-aa20-3de8b1aa723b	vehicles	de	| Fahrzeuge	auto	2026-04-24 05:29:36.332886+00	2026-04-24 05:29:36.332886+00
3f4183b0-be54-4e3c-be99-3e7257f37f84	vehicles	zh	车辆	auto	2026-04-24 05:29:36.425929+00	2026-04-24 05:29:36.425929+00
c1ab7f7f-4e4f-4b7b-990f-0e9bab6d5eb7	vehicles	ja	| 車輌	auto	2026-04-24 05:29:36.76173+00	2026-04-24 05:29:36.76173+00
3ab35c39-5f4c-4144-92c3-00a25215f514	vehicles	ko	| 차량	auto	2026-04-24 05:29:36.829425+00	2026-04-24 05:29:36.829425+00
3c438173-006e-4545-8de0-4eb83e3f432e	vehicles	vi	Xe hơi	auto	2026-04-24 05:29:37.074802+00	2026-04-24 05:29:37.074802+00
c83c9d5b-4571-4b19-8064-f0ddf2881e62	vehicles	tr	| Araçlar	auto	2026-04-24 05:29:37.438676+00	2026-04-24 05:29:37.438676+00
b0ea1665-1b2c-4a52-9b08-724e0b46e34c	vehicles	ar	مركبات	auto	2026-04-24 05:29:37.675439+00	2026-04-24 05:29:37.675439+00
dacce6b0-6ab7-473c-9833-d63b7aa4f8e2	vehicles	fa	وسایل نقلیه	auto	2026-04-24 05:29:37.777788+00	2026-04-24 05:29:37.777788+00
45ca5b8c-e4e8-4db9-a649-ab5c5abb8292	vehicles	hi	वाहन	auto	2026-04-24 05:29:37.966844+00	2026-04-24 05:29:37.966844+00
2a005e7d-7165-4908-af1d-67128eb50f50	vehicles	pt	□ Veículos	auto	2026-04-24 05:29:38.075951+00	2026-04-24 05:29:38.075951+00
fec8e13a-bf4e-490f-805a-be9fde9cc0da	vehicles	ru	Транспортные средства	auto	2026-04-24 05:29:38.245082+00	2026-04-24 05:29:38.245082+00
0829be4e-ff9f-428d-8033-5a9a9c553f0d	vehicles	sv	Fordon	auto	2026-04-24 05:29:38.34583+00	2026-04-24 05:29:38.34583+00
b26d7274-112a-417f-9a95-c991e1e1603b	vehicles	tl	Tamang mga Sasakyan	auto	2026-04-24 05:29:38.669681+00	2026-04-24 05:29:38.669681+00
04656ce0-98ba-4184-8445-965ec4aa90ce	services	es	Silencio	auto	2026-04-24 05:29:39.782892+00	2026-04-24 05:29:39.782892+00
70dba8ac-857c-4f9f-9c99-57481321b94e	services	de	Dienstleistungen	auto	2026-04-24 05:29:39.932392+00	2026-04-24 05:29:39.932392+00
5ff68cbb-f62d-4db4-b5ce-05477d6c96bf	services	zh	服务	auto	2026-04-24 05:29:40.173735+00	2026-04-24 05:29:40.173735+00
953b414b-bc36-4714-873d-2683e52d8d32	services	ja	| サービス	auto	2026-04-24 05:29:40.249759+00	2026-04-24 05:29:40.249759+00
ff151dd8-9023-4c5d-a790-94fbabb9c663	services	ko	| 서비스	auto	2026-04-24 05:29:40.311063+00	2026-04-24 05:29:40.311063+00
3b1a1653-bd51-4f22-9287-ee7e85256eb1	services	vi	Dịch vụ teppi82	auto	2026-04-24 05:29:40.448639+00	2026-04-24 05:29:40.448639+00
e4098dde-350c-4ed4-a47a-bed53b39b3e3	services	tr	| Hizmetler	auto	2026-04-24 05:29:40.546108+00	2026-04-24 05:29:40.546108+00
00a36ab9-7bfa-4d2d-98b6-da2994b5edba	services	ar	| خدمات	auto	2026-04-24 05:29:40.712996+00	2026-04-24 05:29:40.712996+00
bac20c60-3312-4089-8b44-31c10deff478	services	fa	خدمات	auto	2026-04-24 05:29:40.786934+00	2026-04-24 05:29:40.786934+00
06fe2b92-d560-40d2-809d-e29091091db4	services	ur	ایس 	auto	2026-04-24 05:29:40.86084+00	2026-04-24 05:29:40.86084+00
d3a0bff6-b744-4af5-97c0-2312ae6e333a	services	hi	सेवाएं	auto	2026-04-24 05:29:41.025045+00	2026-04-24 05:29:41.025045+00
751c02c2-9aa1-44d3-8f71-2c9057dde3c5	services	pt	Serviços	auto	2026-04-24 05:29:41.097814+00	2026-04-24 05:29:41.097814+00
61b2e8ff-e6b6-4b8a-823d-3d13b3cc860d	services	ru	Услуги	auto	2026-04-24 05:29:41.223267+00	2026-04-24 05:29:41.223267+00
c7fce2f5-4ca5-4177-bce2-8247c9128eb3	services	sv	| tjänster	auto	2026-04-24 05:29:41.294599+00	2026-04-24 05:29:41.294599+00
8ac2625f-1fdb-4d40-81b2-bc9b428a8bcc	vehicles	ur	رنگ	auto	2026-04-24 05:29:37.874391+00	2026-04-24 05:29:37.874391+00
ac34d932-fde2-49dd-80c4-7caa7b54b42b	home_garden	sv	Hem och Trädgård	manual	2026-04-24 05:29:14.863618+00	2026-04-26 18:27:06.015782+00
340a3ed0-3370-45db-9652-e81785435cf2	services	fr	Services	manual	2026-04-24 05:29:39.866343+00	2026-04-26 18:50:50.438123+00
fa7af746-a6b0-4452-a9ae-85a6485fe773	services	tl	Mga Serbisyo sa Pag - aayos	auto	2026-04-24 05:29:41.484606+00	2026-04-24 05:29:41.484606+00
e4076a8c-11bb-4b3d-9fa5-a16845b52619	real_estate	es	confidencialidad inmobiliaria	auto	2026-04-24 05:29:42.590693+00	2026-04-24 05:29:42.590693+00
601ee763-50ea-486e-b909-522f54c02763	real_estate	fr	Immobilier	auto	2026-04-24 05:29:42.656458+00	2026-04-24 05:29:42.656458+00
ca0fc870-747c-4b51-b24c-72c86333d9f3	real_estate	de	| Immobilien	auto	2026-04-24 05:29:42.881644+00	2026-04-24 05:29:42.881644+00
83808a1e-ea09-41dc-a52a-21cc8f89186c	real_estate	zh	房地产	auto	2026-04-24 05:29:42.972397+00	2026-04-24 05:29:42.972397+00
0b726224-bec8-4c0c-be15-ce97a2aa943f	real_estate	ja	| 不動産	auto	2026-04-24 05:29:43.066268+00	2026-04-24 05:29:43.066268+00
00fb482f-fa4d-4a9b-b83f-28af98be08fc	real_estate	ko	| 부동산	auto	2026-04-24 05:29:43.374716+00	2026-04-24 05:29:43.374716+00
defcf881-c773-46cb-8289-879ae53cb8ea	real_estate	vi	Bất động sản thật	auto	2026-04-24 05:29:43.494854+00	2026-04-24 05:29:43.494854+00
aa1dbc0a-3d92-4a2c-85eb-e146ef493f74	real_estate	tr	| Gayrimenkul	auto	2026-04-24 05:29:43.625289+00	2026-04-24 05:29:43.625289+00
aef73d2a-89ee-47fa-bcdb-2fa53131c8f9	real_estate	ar	Real Estate	auto	2026-04-24 05:29:43.720812+00	2026-04-24 05:29:43.720812+00
fd434a03-2a60-4277-ac6e-ed1bd705cbe8	real_estate	fa	املاک و مستغلات	auto	2026-04-24 05:29:44.060065+00	2026-04-24 05:29:44.060065+00
eb447ed0-f7ba-4974-9667-adf6a482594f	real_estate	ur	Real حقیقی ریاست	auto	2026-04-24 05:29:44.188905+00	2026-04-24 05:29:44.188905+00
3750ac4d-2b85-421e-80ed-67e407bd8715	real_estate	hi	रियल एस्टेट	auto	2026-04-24 05:29:44.305677+00	2026-04-24 05:29:44.305677+00
e812db96-e969-48cb-89bd-83c1f8aeb7d0	real_estate	pt	Imóveis	auto	2026-04-24 05:29:44.39692+00	2026-04-24 05:29:44.39692+00
0d104a78-7462-4f78-bb38-5c62355b648d	real_estate	ru	Недвижимость	auto	2026-04-24 05:29:44.565002+00	2026-04-24 05:29:44.565002+00
e678d82c-a807-40cd-8bf5-f89f1f8ceca1	real_estate	tl	Tamang Kalagayan	auto	2026-04-24 05:29:44.909317+00	2026-04-24 05:29:44.909317+00
15a8407a-f3b1-46dd-b35c-4ec8ea2d0eeb	personals	de	| Kontaktanzeigen	auto	2026-04-24 05:29:46.886759+00	2026-04-24 05:29:46.886759+00
f835da69-dce5-4656-b178-e07827a668e5	virtual_relationship	es	← Relación Virtual	auto	2026-04-24 05:29:53.213351+00	2026-04-24 05:29:53.213351+00
34dbaac8-f4b9-4ba7-af5a-0f9d8e2024f6	virtual_relationship	fr	Relation virtuelle	auto	2026-04-24 05:29:53.293151+00	2026-04-24 05:29:53.293151+00
ae071cbc-097c-4fe8-b75a-4378e6be3997	virtual_relationship	de	| Virtuelle Beziehung	auto	2026-04-24 05:29:53.416096+00	2026-04-24 05:29:53.416096+00
52fce457-180a-45e3-8c5a-40b5bb723617	virtual_relationship	zh	虚拟关系	auto	2026-04-24 05:29:53.690959+00	2026-04-24 05:29:53.690959+00
5cb1d1e7-16b2-4b11-a7ff-81bfe33d940e	virtual_relationship	ja	| 仮想関係	auto	2026-04-24 05:29:53.809533+00	2026-04-24 05:29:53.809533+00
a3050b7e-7634-4573-b818-c992d92f528e	virtual_relationship	ko	| 가상 관계	auto	2026-04-24 05:29:53.89845+00	2026-04-24 05:29:53.89845+00
f9feb57f-cc82-48f4-a77d-4310633c23f4	virtual_relationship	vi	▪ Quan hệ ảo	auto	2026-04-24 05:29:54.507646+00	2026-04-24 05:29:54.507646+00
4f506381-105b-4239-92f9-4fbed152e815	virtual_relationship	tr	| Sanal İlişki	auto	2026-04-24 05:29:55.189134+00	2026-04-24 05:29:55.189134+00
08cbfe37-5ad6-4c0c-857d-e9ce0a75760f	virtual_relationship	ar	العلاقة الافتراضية	auto	2026-04-24 05:29:55.452846+00	2026-04-24 05:29:55.452846+00
ecb35503-e7da-439f-8b2c-7266fb850d07	virtual_relationship	fa	رابطه مجازی	auto	2026-04-24 05:29:55.545282+00	2026-04-24 05:29:55.545282+00
c437817f-0f16-4ed8-8afc-c7015fd1850f	virtual_relationship	ur	جگہ	auto	2026-04-24 05:29:55.755531+00	2026-04-24 05:29:55.755531+00
fb90c048-d8b5-493d-ad6e-2d46859586e1	virtual_relationship	hi	आभासी संबंध	auto	2026-04-24 05:29:56.026494+00	2026-04-24 05:29:56.026494+00
18d35bb3-53eb-4b4f-a983-d64bdbee2cbf	virtual_relationship	pt	Relacionamento Virtual	auto	2026-04-24 05:29:56.247777+00	2026-04-24 05:29:56.247777+00
165605c1-6e6b-4190-a9f1-ade88a51da0b	virtual_relationship	ru	Виртуальные отношения	auto	2026-04-24 05:29:56.820903+00	2026-04-24 05:29:56.820903+00
731e34e5-3c5c-4391-a08b-6a8d57496f37	virtual_relationship	sv	Virtuellt förhållande	auto	2026-04-24 05:29:56.964474+00	2026-04-24 05:29:56.964474+00
47b6f6f4-c2fd-4425-9970-66f0818a0522	virtual_relationship	tl	Eksperimentong Kaugnayan	auto	2026-04-24 05:29:57.101126+00	2026-04-24 05:29:57.101126+00
2e7c686f-122a-4f20-9245-66b02df82028	apartments	es	Silencio Apartamentos	auto	2026-04-24 05:29:58.381966+00	2026-04-24 05:29:58.381966+00
d540b2fe-d94a-4d2a-8e82-edbfa80e45ba	apartments	fr	Appartements	auto	2026-04-24 05:29:58.647808+00	2026-04-24 05:29:58.647808+00
e11a29f3-d168-4768-a537-3dce506de59e	apartments	de	| Ferienwohnungen	auto	2026-04-24 05:29:58.722987+00	2026-04-24 05:29:58.722987+00
69987252-b8a0-4c51-91d8-4cac229e8e8c	apartments	zh	* 公寓	auto	2026-04-24 05:29:58.819283+00	2026-04-24 05:29:58.819283+00
fdad984d-2f83-48b9-b8af-754bd1c304fb	apartments	ja	| アパート	auto	2026-04-24 05:29:58.902223+00	2026-04-24 05:29:58.902223+00
51f69f13-113c-4038-abdd-ce6cfbb0255a	apartments	ko	| 아파트	auto	2026-04-24 05:29:58.963501+00	2026-04-24 05:29:58.963501+00
d7e1ce71-f659-4d4f-b03b-e682aba55326	apartments	vi	Nhà riêng	auto	2026-04-24 05:29:59.132721+00	2026-04-24 05:29:59.132721+00
e28d4725-71f0-4c23-8b10-8da46fc18b89	apartments	tr	| Daireler	auto	2026-04-24 05:29:59.295043+00	2026-04-24 05:29:59.295043+00
1429a9b8-51b0-40d6-a7b6-9ebe0892bdfb	apartments	ar	شقق	auto	2026-04-24 05:29:59.352803+00	2026-04-24 05:29:59.352803+00
ba2ae177-2b0c-458e-af7f-ba60af500e01	apartments	fa	آپارتمان	auto	2026-04-24 05:29:59.427787+00	2026-04-24 05:29:59.427787+00
6cefaab0-8aa9-4b9d-b6c9-3bde6832f693	apartments	ur	جگہ	auto	2026-04-24 05:29:59.522156+00	2026-04-24 05:29:59.522156+00
6091c15a-6af8-4979-84e1-1bb07a7095b6	apartments	hi	अपार्टमेंट	auto	2026-04-24 05:29:59.705331+00	2026-04-24 05:29:59.705331+00
81bf7104-40b0-4258-aa2f-4a0d970a9b39	apartments	pt	Apartamentos	auto	2026-04-24 05:29:59.788972+00	2026-04-24 05:29:59.788972+00
8a2d8578-462c-4712-984f-db7401be81b3	apartments	ru	Апартаменты	auto	2026-04-24 05:29:59.962603+00	2026-04-24 05:29:59.962603+00
2913ef6b-731b-4e3f-882c-ff8ae634dd17	apartments	sv	| Lägenheter	auto	2026-04-24 05:30:00.314556+00	2026-04-24 05:30:00.314556+00
8600b7eb-1157-4f5f-be8b-cc3dd65033a6	apartments	tl	Paghihiwalay	auto	2026-04-24 05:30:00.486141+00	2026-04-24 05:30:00.486141+00
5a679be7-0967-43db-9405-b144c4a4c8ff	houses	es	Silencio	auto	2026-04-24 05:30:01.683684+00	2026-04-24 05:30:01.683684+00
241ea7d6-ceb1-4481-b18d-8e6e002d5717	houses	fr	Maisons	auto	2026-04-24 05:30:01.812588+00	2026-04-24 05:30:01.812588+00
dafda128-ef37-48c1-9e6e-7254adc1270a	houses	de	| Häuser	auto	2026-04-24 05:30:02.039161+00	2026-04-24 05:30:02.039161+00
0c7a962d-ff64-443b-bdf8-71fdd3ab751b	houses	zh	房屋	auto	2026-04-24 05:30:02.284876+00	2026-04-24 05:30:02.284876+00
c591c87d-1f0f-4923-9560-bfc4a59d7e9a	houses	ja	| ハウス	auto	2026-04-24 05:30:02.46211+00	2026-04-24 05:30:02.46211+00
9f9aa27b-31ae-4206-b4a0-91d471c507bc	houses	ko	| 주택	auto	2026-04-24 05:30:02.543676+00	2026-04-24 05:30:02.543676+00
00266902-94d9-4702-bf3d-f038a2fdce2e	houses	vi	Nhà ở	auto	2026-04-24 05:30:02.669534+00	2026-04-24 05:30:02.669534+00
d2fe0f20-3796-4be6-bcd3-dc8c4d0e338b	houses	tr	Evler	auto	2026-04-24 05:30:02.769366+00	2026-04-24 05:30:02.769366+00
15cdab7a-0b07-4a67-b6cd-91e6a2c607de	houses	ar	المنازل	auto	2026-04-24 05:30:02.852285+00	2026-04-24 05:30:02.852285+00
5708ab6e-1f79-4418-bbc2-ac5f993722f5	houses	fa	خانه ها	auto	2026-04-24 05:30:02.989412+00	2026-04-24 05:30:02.989412+00
c5a453f4-1597-47d5-b8c6-dd132c6ea141	houses	ur	| گھر	auto	2026-04-24 05:30:03.085355+00	2026-04-24 05:30:03.085355+00
37a2159c-942d-434f-974f-f65895a52cc3	houses	hi	हाउस	auto	2026-04-24 05:30:03.280171+00	2026-04-24 05:30:03.280171+00
c45fff42-2420-4d74-af24-d2bfb7a5011d	houses	pt	Casas	auto	2026-04-24 05:30:03.366534+00	2026-04-24 05:30:03.366534+00
bf4f7493-e449-4479-928e-cded3dee0170	houses	ru	Дома	auto	2026-04-24 05:30:03.524557+00	2026-04-24 05:30:03.524557+00
dff86673-6edb-46e7-aa3a-e369d6384b8b	houses	sv	| Hus	auto	2026-04-24 05:30:03.620487+00	2026-04-24 05:30:03.620487+00
e66ef994-10d3-452f-a17f-5b883afe13d8	houses	tl	Mga Bahay para sa mga nagsigamit	auto	2026-04-24 05:30:03.804767+00	2026-04-24 05:30:03.804767+00
0ec4967d-dc16-4176-8f1c-d4b92e62f272	personals	fa	همسریابی / تعارف	manual	2026-04-24 05:29:48.561504+00	2026-04-26 20:28:31.764838+00
3936c88a-aa39-4904-ae94-6016d7b0ea04	personals	es	Contactos / Citas	manual	2026-04-24 05:29:46.025877+00	2026-04-26 20:29:33.302476+00
6c5c17f3-76a5-49b5-85c6-4d791577c01f	personals	fr	Rencontres	manual	2026-04-24 05:29:46.100493+00	2026-04-26 20:30:10.512669+00
63c7b14d-ce1d-489d-8bcc-f13c7253d85c	personals	zh	交友 / 征婚	manual	2026-04-24 05:29:46.991509+00	2026-04-26 20:31:57.395448+00
c04ef5a5-14a8-47b4-ab30-d34a22e613b2	personals	ja	出会い	manual	2026-04-24 05:29:47.336536+00	2026-04-26 20:33:20.958063+00
85aedff4-e42e-496c-9c9f-b349f607a077	personals	ko	인맥 / 데이트	manual	2026-04-24 05:29:47.64951+00	2026-04-26 20:34:06.481143+00
c65735c2-d269-46e4-84fa-3ff255782060	personals	vi	Hẹn hò	manual	2026-04-24 05:29:47.772878+00	2026-04-26 20:35:20.59835+00
af794dd2-4ea5-436f-a234-a4ae14236002	personals	tr	Arkadaşlık / Sevgili	manual	2026-04-24 05:29:48.401371+00	2026-04-26 20:36:28.368914+00
af514139-babf-4cfd-8150-2e3ab88c5b35	personals	ar	تعارف	manual	2026-04-24 05:29:48.468486+00	2026-04-26 20:37:33.614148+00
d282eaa2-37cc-489f-9cf1-4d60eacd3750	personals	ur	تعارف / ملاقات	manual	2026-04-24 05:29:48.643129+00	2026-04-26 20:39:01.699513+00
941f02bc-11c6-411a-91fc-307738dda036	personals	pt	Encontros	manual	2026-04-24 05:29:48.953573+00	2026-04-26 20:40:57.155183+00
b9acc162-d6a6-4bc4-a7bf-27a003086447	personals	sv	Personligt / Dejting	manual	2026-04-24 05:29:51.11677+00	2026-04-26 20:43:12.2189+00
8c65d759-e278-4df6-92a5-d3f0274d05fe	personals	ru	Знакомства	manual	2026-04-24 05:29:50.377209+00	2026-04-26 20:41:55.793911+00
90635145-bd85-4ccf-bb53-b99ab7dc69af	personals	tl	Pakikipag-date	manual	2026-04-24 05:29:51.478708+00	2026-04-26 20:44:21.87886+00
def1b4d6-5d85-4922-80eb-5cd3b5fb0a27	mansions	es	| Mansiones	auto	2026-04-24 05:30:09.503976+00	2026-04-24 05:30:09.503976+00
6c612b7c-5750-4a22-88e2-798dcf9f0cdb	mansions	fr	| Demeures	auto	2026-04-24 05:30:11.361276+00	2026-04-24 05:30:11.361276+00
a9a4f78e-4353-453f-bf02-5a79b8a33619	mansions	de	- Villen	auto	2026-04-24 05:30:11.7319+00	2026-04-24 05:30:11.7319+00
0269d5f2-0d24-4282-965f-2e2e63921313	mansions	zh	- 豪宅 - 豪宅 - Mansions	auto	2026-04-24 05:30:12.462804+00	2026-04-24 05:30:12.462804+00
efc8937f-2cee-498d-9d26-ad84d07a9f8e	mansions	ja	- マンション	auto	2026-04-24 05:30:12.978117+00	2026-04-24 05:30:12.978117+00
14a98800-e8b5-44e9-a644-fb0e578c0985	mansions	ko	- 맨션	auto	2026-04-24 05:30:13.285841+00	2026-04-24 05:30:13.285841+00
587c4c49-91d1-4ff4-9a7c-05235facde02	mansions	vi	- Khu nhà	auto	2026-04-24 05:30:13.523436+00	2026-04-24 05:30:13.523436+00
52a025e3-0225-4ede-bbba-003d985b1d6d	mansions	tr	- Mansions	auto	2026-04-24 05:30:13.881657+00	2026-04-24 05:30:13.881657+00
cffd8b3b-a1d7-43a5-8a06-3789153614e6	mansions	ar	- الاضطرابات	auto	2026-04-24 05:30:14.142116+00	2026-04-24 05:30:14.142116+00
e871b4b5-444d-49ef-9b04-ab90a5c7f49b	mansions	fa	Mansions	auto	2026-04-24 05:30:14.450961+00	2026-04-24 05:30:14.450961+00
f72e728c-950d-4aa3-92ee-1bc46dd4d535	mansions	ur	- جی ہاں	auto	2026-04-24 05:30:14.715082+00	2026-04-24 05:30:14.715082+00
031cc347-9825-46a5-88b2-64352ab51a41	mansions	hi	- विचार	auto	2026-04-24 05:30:14.995002+00	2026-04-24 05:30:14.995002+00
973442c0-c02b-4f15-af3f-52421bb64d7c	mansions	pt	- Mansões	auto	2026-04-24 05:30:15.110817+00	2026-04-24 05:30:15.110817+00
58a431e1-e34e-4921-a8b7-29f93209675b	mansions	ru	- Особняки	auto	2026-04-24 05:30:15.27186+00	2026-04-24 05:30:15.27186+00
6ee0a7e6-1f14-4a16-baf7-73f06d67e1f3	mansions	sv	Mansions	auto	2026-04-24 05:30:15.367839+00	2026-04-24 05:30:15.367839+00
4eb54d73-b2fc-4e32-8098-c0d0451ad5ab	mansions	tl	- Pasyon	auto	2026-04-24 05:30:15.709784+00	2026-04-24 05:30:15.709784+00
dc10eef7-28c2-449e-90c5-8cbaebe00099	food_and_beverage	es	alimentos y bebidas	auto	2026-04-24 05:30:16.916102+00	2026-04-24 05:30:16.916102+00
30d5c830-379e-42b0-9830-f38f63e4d028	food_and_beverage	fr	Produits alimentaires et boissons	auto	2026-04-24 05:30:17.011471+00	2026-04-24 05:30:17.011471+00
9667c80a-3222-4632-bcb5-0a6812c03bf9	food_and_beverage	de	| Lebensmittel und Getränke	auto	2026-04-24 05:30:17.304442+00	2026-04-24 05:30:17.304442+00
37aa39bf-7179-4b48-a377-7e8028587580	food_and_beverage	zh	食品和饮料	auto	2026-04-24 05:30:17.445631+00	2026-04-24 05:30:17.445631+00
8fbab882-64ce-42b0-95f1-d6b3859f9138	food_and_beverage	ja	| 食品・飲料	auto	2026-04-24 05:30:17.577447+00	2026-04-24 05:30:17.577447+00
97aa5190-6405-494d-964c-90b87c61239b	food_and_beverage	ko	| 음식과 음료	auto	2026-04-24 05:30:17.671903+00	2026-04-24 05:30:17.671903+00
6dcf3bac-b575-4ca1-a1d6-ba5c24ed620b	food_and_beverage	vi	▪ Thức ăn bổ dưỡng	auto	2026-04-24 05:30:17.822529+00	2026-04-24 05:30:17.822529+00
51767a6e-c138-4227-9b58-55bd3647ac65	food_and_beverage	tr	Yiyecek ve İçecek	auto	2026-04-24 05:30:17.909307+00	2026-04-24 05:30:17.909307+00
ee41b7f8-a931-42cb-9bd3-12da12b5e9ca	food_and_beverage	ar	الغذاء والمشروب	auto	2026-04-24 05:30:18.004043+00	2026-04-24 05:30:18.004043+00
289b6159-d25c-4776-b288-a53a9c8419dd	food_and_beverage	fa	غذا و نوشیدنی	auto	2026-04-24 05:30:18.101187+00	2026-04-24 05:30:18.101187+00
0a2e3af4-e479-487c-b026-f44322020491	food_and_beverage	ur	کھانا اور کھانا	auto	2026-04-24 05:30:18.210907+00	2026-04-24 05:30:18.210907+00
61c759fd-9f92-47d1-9072-6f29d72882c2	food_and_beverage	hi	खाद्य और पेय पदार्थ	auto	2026-04-24 05:30:18.296739+00	2026-04-24 05:30:18.296739+00
831b537d-cba6-49a0-a585-5ed503354b76	food_and_beverage	pt	Alimentos e Bebidas	auto	2026-04-24 05:30:18.399139+00	2026-04-24 05:30:18.399139+00
fc45bbc1-4292-4fa6-bb1e-90c7983774ea	food_and_beverage	ru	Пища и напитки	auto	2026-04-24 05:30:18.563484+00	2026-04-24 05:30:18.563484+00
1eaf91ef-e465-4090-8223-62f2f3e740f0	food_and_beverage	sv	| Mat och dryck	auto	2026-04-24 05:30:18.68012+00	2026-04-24 05:30:18.68012+00
9258ada4-8926-4991-89ce-7b995a67c25e	food_and_beverage	tl	Mga Pagkain at Inumin ng Etrisida	auto	2026-04-24 05:30:18.879537+00	2026-04-24 05:30:18.879537+00
40287fa4-af8b-430d-a9ab-7a03cdd04359	just_friends	es	Sólo amigos	auto	2026-04-24 05:30:19.979524+00	2026-04-24 05:30:19.979524+00
174ede85-c334-4106-b496-a87a198a6a9f	just_friends	fr	Juste des amis	auto	2026-04-24 05:30:20.088798+00	2026-04-24 05:30:20.088798+00
88638b0c-23f5-49fe-83a0-5b96097a3cbf	just_friends	de	| Nur Freunde	auto	2026-04-24 05:30:20.354464+00	2026-04-24 05:30:20.354464+00
8fbc0e53-8d19-4d08-88b1-f0eef8c820c9	just_friends	zh	仅仅朋友	auto	2026-04-24 05:30:20.488771+00	2026-04-24 05:30:20.488771+00
29a328f3-36c8-4a76-8272-24784a645aec	just_friends	ja	| ジャストフレンズ	auto	2026-04-24 05:30:20.602975+00	2026-04-24 05:30:20.602975+00
d303d531-5c21-4935-a5ce-d05b6d029adb	just_friends	ko	| 친구	auto	2026-04-24 05:30:20.919871+00	2026-04-24 05:30:20.919871+00
61017591-ae8c-4b98-ad62-e2eccbdd9e4b	just_friends	vi	▪ Chỉ là bạn	auto	2026-04-24 05:30:21.056983+00	2026-04-24 05:30:21.056983+00
412ddd0e-deb8-4085-abf9-58c777cfd182	just_friends	tr	| Sadece Arkadaşlar	auto	2026-04-24 05:30:21.733376+00	2026-04-24 05:30:21.733376+00
7e40d9d7-5e70-42c6-8340-4ce692f5277c	just_friends	ar	مجرد أصدقاء	auto	2026-04-24 05:30:21.810888+00	2026-04-24 05:30:21.810888+00
eb6cdae2-fc06-45bc-8c77-41e404708426	just_friends	fa	فقط دوستان	auto	2026-04-24 05:30:21.909367+00	2026-04-24 05:30:21.909367+00
0193e26b-3ef7-4c8c-b42c-5c323a8e338a	just_friends	ur	مطالعے کے مضامین	auto	2026-04-24 05:30:22.00572+00	2026-04-24 05:30:22.00572+00
6ac1e010-8980-4249-b50e-f9c24f777064	just_friends	hi	To make a friend	auto	2026-04-24 05:30:22.21495+00	2026-04-24 05:30:22.21495+00
ae7cdccf-6f0a-4ae6-bf29-f6e918211ec5	just_friends	pt	Apenas Amigos	auto	2026-04-24 05:30:22.300784+00	2026-04-24 05:30:22.300784+00
7b15d6ab-c04b-4956-982b-77ca518543a3	just_friends	ru	Просто друзья	auto	2026-04-24 05:30:22.627182+00	2026-04-24 05:30:22.627182+00
e0726a9d-f51d-4714-bc5c-4e10cd8104c6	just_friends	sv	Bara vänner	auto	2026-04-24 05:30:22.930557+00	2026-04-24 05:30:22.930557+00
0e748c91-ce2c-4a7e-a939-69edde3591c3	just_friends	tl	Eksperimento Mga Kaibigan Lamang	auto	2026-04-24 05:30:23.124309+00	2026-04-24 05:30:23.124309+00
6d598fc1-91c5-4051-b4af-51d1c903a866	other	es	Silencio	auto	2026-04-24 05:30:24.296369+00	2026-04-24 05:30:24.296369+00
9f3f60d4-c377-4bed-b1d9-190285eb49bb	other	fr	Autres	auto	2026-04-24 05:30:24.358579+00	2026-04-24 05:30:24.358579+00
d11bca66-b890-4e39-93de-dd74c9838133	other	de	Sonstige	auto	2026-04-24 05:30:24.411023+00	2026-04-24 05:30:24.411023+00
bbcae8f4-816a-4a0a-872e-19ec9a39c91d	other	zh	其他情况	auto	2026-04-24 05:30:24.891347+00	2026-04-24 05:30:24.891347+00
34b8fe23-a6d2-4526-ac9c-76e0d8240a7b	other	ja	| その他	auto	2026-04-24 05:30:25.148929+00	2026-04-24 05:30:25.148929+00
516d4681-037c-4f4d-8694-11757cff2597	other	ko	| 기타	auto	2026-04-24 05:30:25.455912+00	2026-04-24 05:30:25.455912+00
e4de2b3e-2ba1-4c6c-9264-d8fb4344d597	other	vi	Người khác	auto	2026-04-24 05:30:25.888862+00	2026-04-24 05:30:25.888862+00
08395826-7bcc-4e43-a272-f980ded9211c	other	tr	Diğer	auto	2026-04-24 05:30:26.171092+00	2026-04-24 05:30:26.171092+00
c99a2884-b1ac-4621-9b3a-e819205abf2c	other	ar	| آخر	auto	2026-04-24 05:30:26.8604+00	2026-04-24 05:30:26.8604+00
cdab46e8-df44-46b0-985d-f6b0e7fc4688	other	fa	دیگر	auto	2026-04-24 05:30:27.242798+00	2026-04-24 05:30:27.242798+00
3d2a28e4-5cdd-49cd-a96b-ca004f4554df	other	ur	کچھ اور	auto	2026-04-24 05:30:28.502247+00	2026-04-24 05:30:28.502247+00
f0ee0d21-0479-4881-97f3-e090729c1129	other	hi	अन्य	auto	2026-04-24 05:30:28.909189+00	2026-04-24 05:30:28.909189+00
6c1b1bcb-873d-485c-b9fc-22bed7489e6f	other	pt	Outros	auto	2026-04-24 05:30:29.143848+00	2026-04-24 05:30:29.143848+00
c104e190-e75c-438a-a4a9-27943240e68f	other	ru	Другое	auto	2026-04-24 05:30:29.237634+00	2026-04-24 05:30:29.237634+00
9da9a746-9d4e-473e-8b19-a7dd7c29c69e	other	sv	Övriga	auto	2026-04-24 05:30:29.325154+00	2026-04-24 05:30:29.325154+00
05b40508-c56c-452c-9981-1be973c9b21e	other	tl	Ulis	auto	2026-04-24 05:30:29.467306+00	2026-04-24 05:30:29.467306+00
1837b9b3-ed70-4e27-ae23-389d8c255aec	real_estate_other	es	Silencio	auto	2026-04-24 05:30:31.310423+00	2026-04-24 05:30:31.310423+00
13c13400-75c9-4e6d-9c0b-f5a93e0c0c8f	real_estate_other	fr	Autres	auto	2026-04-24 05:30:31.545159+00	2026-04-24 05:30:31.545159+00
197fd70e-3857-4ee8-99bd-11d282eedaa8	real_estate_other	de	Sonstige	auto	2026-04-24 05:30:31.606114+00	2026-04-24 05:30:31.606114+00
18b9adb5-e46e-4955-89fa-869c2a228f44	real_estate_other	zh	其他情况	auto	2026-04-24 05:30:31.693268+00	2026-04-24 05:30:31.693268+00
384f33c0-7900-4d0e-92bc-4d05f03248c5	real_estate_other	ja	| その他	auto	2026-04-24 05:30:32.020115+00	2026-04-24 05:30:32.020115+00
5de0c1fd-71f3-41e7-8635-3971aed9ef4c	real_estate_other	ko	| 기타	auto	2026-04-24 05:30:32.097634+00	2026-04-24 05:30:32.097634+00
ea32ecfc-c21c-43ca-9d11-333d05d48f50	real_estate_other	vi	Người khác	auto	2026-04-24 05:30:32.216073+00	2026-04-24 05:30:32.216073+00
d89d6fa1-d171-4ddd-bd18-acae29bc1c44	real_estate_other	tr	Diğer	auto	2026-04-24 05:30:32.291788+00	2026-04-24 05:30:32.291788+00
a4ecaf82-78d1-42cf-9473-48de810fbb3f	real_estate_other	ar	| آخر	auto	2026-04-24 05:30:32.376976+00	2026-04-24 05:30:32.376976+00
c9369fcf-5850-424a-a4f8-f91990b22593	real_estate_other	fa	دیگر	auto	2026-04-24 05:30:32.380973+00	2026-04-24 05:30:32.380973+00
0f45d7fe-8c4e-4384-b5fa-09a31abdcb27	real_estate_other	ur	کچھ اور	auto	2026-04-24 05:30:32.566408+00	2026-04-24 05:30:32.566408+00
68564d96-7591-4acd-8bce-b785e8fc1338	real_estate_other	hi	अन्य	auto	2026-04-24 05:30:32.751+00	2026-04-24 05:30:32.751+00
c6b5b3c1-4490-4317-a96a-309c128febcf	real_estate_other	pt	Outros	auto	2026-04-24 05:30:32.928797+00	2026-04-24 05:30:32.928797+00
8b180eb0-81a5-40bd-90d6-8175fb41a339	real_estate_other	ru	Другое	auto	2026-04-24 05:30:33.423481+00	2026-04-24 05:30:33.423481+00
2ad51e40-2798-48cf-97b2-879cced7a64e	real_estate_other	sv	Övriga	auto	2026-04-24 05:30:33.510658+00	2026-04-24 05:30:33.510658+00
0078b884-2959-4369-8677-8094ec3c3bbf	real_estate_other	tl	Ulis	auto	2026-04-24 05:30:33.668515+00	2026-04-24 05:30:33.668515+00
510b7b77-d454-4e39-96af-5a11d949a10c	food_and_beverage_other	es	Silencio	auto	2026-04-24 05:30:34.900774+00	2026-04-24 05:30:34.900774+00
b9d18076-26ad-4add-8bdb-35d53a2e6dfd	food_and_beverage_other	fr	Autres	auto	2026-04-24 05:30:35.15791+00	2026-04-24 05:30:35.15791+00
db4286db-7d61-4f11-abbd-5cd615d65560	food_and_beverage_other	de	Sonstige	auto	2026-04-24 05:30:35.372012+00	2026-04-24 05:30:35.372012+00
23aed18b-36d2-46f8-b4eb-92504afbcf86	food_and_beverage_other	zh	其他情况	auto	2026-04-24 05:30:35.621377+00	2026-04-24 05:30:35.621377+00
852bff75-c300-4748-bc7d-b88518d5a177	food_and_beverage_other	ja	| その他	auto	2026-04-24 05:30:35.972485+00	2026-04-24 05:30:35.972485+00
9c41ffac-f983-489d-8b94-a69a4b6e3b3d	food_and_beverage_other	ko	| 기타	auto	2026-04-24 05:30:36.310062+00	2026-04-24 05:30:36.310062+00
3f902f99-2830-4bf7-b935-9783325b1675	food_and_beverage_other	vi	Người khác	auto	2026-04-24 05:30:36.315996+00	2026-04-24 05:30:36.315996+00
f14ce491-8f96-46dc-b80c-e335845fed41	food_and_beverage_other	tr	Diğer	auto	2026-04-24 05:30:36.69639+00	2026-04-24 05:30:36.69639+00
f79933fd-e051-4241-8c7d-8c3a93f09b45	food_and_beverage_other	ar	| آخر	auto	2026-04-24 05:30:36.835526+00	2026-04-24 05:30:36.835526+00
65cec643-eeaf-4306-b4eb-11cab0589529	food_and_beverage_other	fa	| دیگر	auto	2026-04-24 05:30:38.730003+00	2026-04-24 05:30:38.730003+00
2867e236-5f99-45d6-bcc5-65d2d0d95878	food_and_beverage_other	ur	کچھ اور	auto	2026-04-24 05:30:38.758508+00	2026-04-24 05:30:38.758508+00
5b4c40b5-5996-457b-bfeb-4c7e6cca39f1	food_and_beverage_other	hi	अन्य	auto	2026-04-24 05:30:38.762161+00	2026-04-24 05:30:38.762161+00
8966aa55-18f6-41a9-9b56-35dcdfc4ebc0	food_and_beverage_other	pt	Outros	auto	2026-04-24 05:30:38.892226+00	2026-04-24 05:30:38.892226+00
001d5c8b-861b-4e16-97dc-761029207277	food_and_beverage_other	ru	Другое	auto	2026-04-24 05:30:39.875021+00	2026-04-24 05:30:39.875021+00
5f154a9b-85ac-48c9-97e0-bcbc70106334	food_and_beverage_other	sv	Övriga	auto	2026-04-24 05:30:40.165658+00	2026-04-24 05:30:40.165658+00
aea31695-3d22-4e56-b3d9-fc027472625b	food_and_beverage_other	tl	Ulis	auto	2026-04-24 05:30:40.496179+00	2026-04-24 05:30:40.496179+00
75baa27b-e066-4ef7-95f4-c560b767f341	other_1	es	Silencio	auto	2026-04-24 05:30:41.569149+00	2026-04-24 05:30:41.569149+00
854f2287-4f79-4c73-8601-123e45fa65ba	other_1	fr	Autres	auto	2026-04-24 05:30:41.759949+00	2026-04-24 05:30:41.759949+00
0b2cc8de-1aac-46bc-8f0d-ac39b984cf1e	other_1	de	Sonstige	auto	2026-04-24 05:30:41.976423+00	2026-04-24 05:30:41.976423+00
a907dc1c-24f7-4e43-b29a-36e0044a6923	other_1	zh	其他情况	auto	2026-04-24 05:30:41.98048+00	2026-04-24 05:30:41.98048+00
d8e3909b-be96-4093-8660-acb58aedf5a7	other_1	ja	| その他	auto	2026-04-24 05:30:41.984956+00	2026-04-24 05:30:41.984956+00
e486c12c-0f83-4d35-9848-4af227867708	other_1	ko	| 기타	auto	2026-04-24 05:30:42.281098+00	2026-04-24 05:30:42.281098+00
3787cd32-3941-4a8d-ab82-fb62c5e21b99	other_1	vi	Người khác	auto	2026-04-24 05:30:42.5456+00	2026-04-24 05:30:42.5456+00
f0908a6f-0ecc-429e-8b35-7e2e928c9f4d	other_1	tr	Diğer	auto	2026-04-24 05:30:42.549295+00	2026-04-24 05:30:42.549295+00
fa1ce1d4-241c-4ea7-ab40-671b28098f3d	other_1	ar	| آخر	auto	2026-04-24 05:30:42.58748+00	2026-04-24 05:30:42.58748+00
8eed6839-1558-4231-8c2c-e539fa5d306c	other_1	fa	دیگر	auto	2026-04-24 05:30:42.913298+00	2026-04-24 05:30:42.913298+00
bccd91fb-7b52-4f5f-8712-3a95bb8c41f6	other_1	ur	کچھ اور	auto	2026-04-24 05:30:43.132889+00	2026-04-24 05:30:43.132889+00
ea464d86-d05f-401d-a9bf-2b876c37c0e9	other_1	hi	अन्य	auto	2026-04-24 05:30:43.136381+00	2026-04-24 05:30:43.136381+00
451445ed-f3ec-4a38-a64a-6c7c2a03907c	other_1	pt	Outros	auto	2026-04-24 05:30:43.139455+00	2026-04-24 05:30:43.139455+00
b8b8b9d7-7e29-49b8-bb83-b7939024c407	other_1	ru	Другое	auto	2026-04-24 05:30:43.142103+00	2026-04-24 05:30:43.142103+00
1817428b-782d-4dcb-9122-aceafd2876a2	other_1	sv	Övriga	auto	2026-04-24 05:30:43.144781+00	2026-04-24 05:30:43.144781+00
b95f8343-ebc2-4a29-95ef-866f67bfe5d7	other_1	tl	Ulis	auto	2026-04-24 05:30:43.147746+00	2026-04-24 05:30:43.147746+00
1e1108d6-35c3-4b7c-a570-2203311ed2a8	other_1_other	es	Silencio	auto	2026-04-24 05:30:44.174772+00	2026-04-24 05:30:44.174772+00
19d3958b-f474-4a19-8a24-49e29b561fbb	other_1_other	fr	Autres	auto	2026-04-24 05:30:44.178422+00	2026-04-24 05:30:44.178422+00
47dd8731-51e1-40f8-b7f0-818bb60950ea	other_1_other	de	Sonstige	auto	2026-04-24 05:30:44.23329+00	2026-04-24 05:30:44.23329+00
6512eb1c-147b-44d5-93bb-c2ac494d63b0	other_1_other	zh	其他情况	auto	2026-04-24 05:30:44.306016+00	2026-04-24 05:30:44.306016+00
6f76e771-fb07-4638-b844-24484fce5d84	other_1_other	ja	| その他	auto	2026-04-24 05:30:44.309727+00	2026-04-24 05:30:44.309727+00
43eae516-4d26-4ed2-bd8e-141fb19bbd8d	other_1_other	ko	| 기타	auto	2026-04-24 05:30:44.313582+00	2026-04-24 05:30:44.313582+00
51dc1269-d53b-4d91-b3a3-2dd149c4f86b	other_1_other	vi	Người khác	auto	2026-04-24 05:30:44.31688+00	2026-04-24 05:30:44.31688+00
c009c76c-b523-4ae7-b44c-63ce37e72301	other_1_other	tr	Diğer	auto	2026-04-24 05:30:44.320466+00	2026-04-24 05:30:44.320466+00
dcf3906a-a41f-4181-9244-04cdc1ff43cd	other_1_other	ar	| آخر	auto	2026-04-24 05:30:44.598234+00	2026-04-24 05:30:44.598234+00
c1d55d26-f1f4-494b-bb48-ccb481df23ce	other_1_other	fa	دیگر	auto	2026-04-24 05:30:44.602695+00	2026-04-24 05:30:44.602695+00
8341e09e-e8b4-4d46-8050-9f0525156016	other_1_other	ur	کچھ اور	auto	2026-04-24 05:30:44.606578+00	2026-04-24 05:30:44.606578+00
768a8aa5-6dc3-4fb9-a58c-a790d28fd1fb	other_1_other	hi	अन्य	auto	2026-04-24 05:30:44.969917+00	2026-04-24 05:30:44.969917+00
fb3e2365-6072-4730-8711-4febfc7540d4	other_1_other	pt	Outros	auto	2026-04-24 05:30:44.973747+00	2026-04-24 05:30:44.973747+00
c702e320-1434-4f9f-8321-39e80561e59e	other_1_other	ru	Другое	auto	2026-04-24 05:30:45.475585+00	2026-04-24 05:30:45.475585+00
c00f7b8d-e555-42df-9889-69b851229bc2	other_1_other	sv	Övriga	auto	2026-04-24 05:30:45.767526+00	2026-04-24 05:30:45.767526+00
d0bfbb9f-53f4-45b5-ae73-876d27168dfe	other_1_other	tl	Ulis	auto	2026-04-24 05:30:45.771213+00	2026-04-24 05:30:45.771213+00
058cd4b7-f006-4d14-bd00-b4d974d12272	other_2	es	Silencio	auto	2026-04-24 05:30:47.053543+00	2026-04-24 05:30:47.053543+00
d8171182-4962-42a8-85c7-70d1a40061f3	other_2	fr	Autres	auto	2026-04-24 05:30:47.058172+00	2026-04-24 05:30:47.058172+00
f710d714-7d80-4908-a07f-1017ce285e1e	other_2	de	Sonstige	auto	2026-04-24 05:30:47.061084+00	2026-04-24 05:30:47.061084+00
2f8994f3-e301-4de6-a7e0-9564eab328cb	other_2	zh	其他情况	auto	2026-04-24 05:30:47.064181+00	2026-04-24 05:30:47.064181+00
d0eab65f-2dfe-4f77-9bf2-5c7d53209cd0	other_2	ja	| その他	auto	2026-04-24 05:30:47.066798+00	2026-04-24 05:30:47.066798+00
00b9eb85-35c9-40ca-825d-1c21d1ba9603	other_2	ko	| 기타	auto	2026-04-24 05:30:47.069276+00	2026-04-24 05:30:47.069276+00
178e54fe-a338-4e7d-a603-52028ec55cc4	other_2	vi	Người khác	auto	2026-04-24 05:30:47.353356+00	2026-04-24 05:30:47.353356+00
2e74b3b7-21b1-451b-9906-1dccf69fce28	other_2	tr	Diğer	auto	2026-04-24 05:30:49.53945+00	2026-04-24 05:30:49.53945+00
9e8bd54d-1bff-459e-8222-5b0fe674e221	other_2	ar	| آخر	auto	2026-04-24 05:30:49.614695+00	2026-04-24 05:30:49.614695+00
2f42cc14-3f22-475b-b6c5-f47f101a2e99	other_2	fa	دیگر	auto	2026-04-24 05:30:49.619202+00	2026-04-24 05:30:49.619202+00
ea3cd4d9-e13c-40bd-ac4d-f083eec0c302	other_2	ur	کچھ اور	auto	2026-04-24 05:30:50.316916+00	2026-04-24 05:30:50.316916+00
dd37e08e-9c71-45b6-96b4-d808cf01ad11	other_2	hi	अन्य	auto	2026-04-24 05:30:50.707775+00	2026-04-24 05:30:50.707775+00
ca58b596-2058-49c4-a0ef-8651fa44777b	other_2	pt	Outros	auto	2026-04-24 05:30:50.712658+00	2026-04-24 05:30:50.712658+00
9f447696-6cf4-47f4-8fa6-8ef11211caae	other_2	ru	Другое	auto	2026-04-24 05:30:51.256672+00	2026-04-24 05:30:51.256672+00
26bb595c-7c0b-4ff0-8767-363f3d9626ef	other_2	sv	Övriga	auto	2026-04-24 05:30:51.560007+00	2026-04-24 05:30:51.560007+00
55008b18-3934-4c43-82ef-c9a174ca5087	other_2	tl	Ulis	auto	2026-04-24 05:30:51.56464+00	2026-04-24 05:30:51.56464+00
94a97de3-7c41-44a4-9917-78da4d530f7e	other_3	es	Silencio	auto	2026-04-24 05:30:52.650805+00	2026-04-24 05:30:52.650805+00
f68c0e87-9c52-427d-9d2d-4b6005557013	other_3	fr	Autres	auto	2026-04-24 05:30:52.654592+00	2026-04-24 05:30:52.654592+00
fae01162-9fb4-4411-9d4d-afad7398a639	other_3	de	Sonstige	auto	2026-04-24 05:30:52.658151+00	2026-04-24 05:30:52.658151+00
57bbfbb5-68d0-479f-9326-c2fbacd0e315	other_3	zh	其他情况	auto	2026-04-24 05:30:52.661164+00	2026-04-24 05:30:52.661164+00
b7c74870-cdb6-4a5e-9ca8-dcea2380bdbb	other_3	ja	| その他	auto	2026-04-24 05:30:52.664206+00	2026-04-24 05:30:52.664206+00
fbcc1b26-a759-4bf9-8515-e95cb46fe2bf	other_3	ko	| 기타	auto	2026-04-24 05:30:52.667055+00	2026-04-24 05:30:52.667055+00
938ccd3c-5f40-4c18-8794-fad078b61573	other_3	vi	Người khác	auto	2026-04-24 05:30:52.670149+00	2026-04-24 05:30:52.670149+00
39f32b58-2c49-4871-9cf0-0052e6961f15	other_3	tr	Diğer	auto	2026-04-24 05:30:52.672972+00	2026-04-24 05:30:52.672972+00
646632dd-e212-421f-b7bc-f1d31556e3cd	other_3	ar	| آخر	auto	2026-04-24 05:30:52.714505+00	2026-04-24 05:30:52.714505+00
c1887e94-fb81-417c-a54a-803c381cd6d5	other_3	fa	دیگر	auto	2026-04-24 05:30:53.062495+00	2026-04-24 05:30:53.062495+00
465b3646-c850-446f-b01a-716ce54c894f	other_3	ur	کچھ اور	auto	2026-04-24 05:30:53.066376+00	2026-04-24 05:30:53.066376+00
b61ad9b8-5a42-42c0-9662-f59f5e86c465	other_3	hi	अन्य	auto	2026-04-24 05:30:53.06984+00	2026-04-24 05:30:53.06984+00
aa67a792-0a45-4a27-ba29-85e96e3eaf13	other_3	pt	Outros	auto	2026-04-24 05:30:53.322178+00	2026-04-24 05:30:53.322178+00
15fb947c-0cda-4d4d-9965-819cfcbe326e	other_3	ru	Другое	auto	2026-04-24 05:30:53.32632+00	2026-04-24 05:30:53.32632+00
38aabe94-1380-45d5-a786-419e9b751ef9	other_3	sv	Övriga	auto	2026-04-24 05:30:53.33039+00	2026-04-24 05:30:53.33039+00
db6f92ef-bbff-4a2e-bc34-1e0123167816	other_3	tl	Ulis	auto	2026-04-24 05:30:53.334255+00	2026-04-24 05:30:53.334255+00
35daca94-f2f4-488d-aa45-40fd60bae237	other_4	es	Silencio	auto	2026-04-24 05:30:54.361075+00	2026-04-24 05:30:54.361075+00
5c9a8e9b-01a8-4b84-b900-51ced3c61715	other_4	fr	Autres	auto	2026-04-24 05:30:54.364105+00	2026-04-24 05:30:54.364105+00
9718f80b-6450-4069-8364-f59483fceb4b	other_4	de	Sonstige	auto	2026-04-24 05:30:54.367517+00	2026-04-24 05:30:54.367517+00
a93d4d57-d17c-43d2-aa93-a89b805c3279	other_4	zh	其他情况	auto	2026-04-24 05:30:54.595792+00	2026-04-24 05:30:54.595792+00
de469947-2e3c-4b14-abb0-bf03bd3983b6	other_4	ja	| その他	auto	2026-04-24 05:30:54.600249+00	2026-04-24 05:30:54.600249+00
e68af261-c903-4cef-acf4-c60d8669107a	other_4	ko	| 기타	auto	2026-04-24 05:30:54.604859+00	2026-04-24 05:30:54.604859+00
ff053c2a-d260-42b8-8712-a9212bb21cb0	other_4	vi	Người khác	auto	2026-04-24 05:30:54.90818+00	2026-04-24 05:30:54.90818+00
ebb0db72-2791-4908-b00f-3cdf9eed8472	other_4	tr	Diğer	auto	2026-04-24 05:30:54.912172+00	2026-04-24 05:30:54.912172+00
41a6fb1d-a2bb-4f5d-8534-9b22dd72cdcd	other_4	ar	| آخر	auto	2026-04-24 05:30:54.953447+00	2026-04-24 05:30:54.953447+00
5152deb1-2abb-44f2-a892-2fe82443dbac	other_4	fa	دیگر	auto	2026-04-24 05:30:54.957703+00	2026-04-24 05:30:54.957703+00
33f0b63d-2116-4415-b718-50701dfa8de3	other_4	ur	کچھ اور	auto	2026-04-24 05:30:54.960857+00	2026-04-24 05:30:54.960857+00
88735fe2-ead1-4e13-a822-33ecf4a0bc01	other_4	hi	अन्य	auto	2026-04-24 05:30:55.38788+00	2026-04-24 05:30:55.38788+00
e1479530-809b-4262-9354-59696da119ba	other_4	pt	Outros	auto	2026-04-24 05:30:55.392395+00	2026-04-24 05:30:55.392395+00
b5337ecc-97b1-4f12-813c-47e44704009f	other_4	ru	Другое	auto	2026-04-24 05:30:55.396085+00	2026-04-24 05:30:55.396085+00
fc53db5e-2c52-44c5-9834-f4acef0f002b	other_4	sv	Övriga	auto	2026-04-24 05:30:55.400133+00	2026-04-24 05:30:55.400133+00
d5b08525-1402-43d8-8cd2-79d70f68e1ea	other_4	tl	Ulis	auto	2026-04-24 05:30:55.40406+00	2026-04-24 05:30:55.40406+00
06f9c8d9-1e87-45d0-9bf9-f4fb82cfdb39	other_5	es	Silencio	auto	2026-04-24 05:30:56.431692+00	2026-04-24 05:30:56.431692+00
d663c3ad-43ab-4f92-8906-299ae1b71d18	other_5	fr	Autres	auto	2026-04-24 05:30:56.435056+00	2026-04-24 05:30:56.435056+00
0ed699e5-1023-4f4d-8d25-fc1c30f9ddab	other_5	de	Sonstige	auto	2026-04-24 05:30:56.437705+00	2026-04-24 05:30:56.437705+00
154744a1-d921-42ff-88ae-142a4cfe3282	other_5	zh	其他情况	auto	2026-04-24 05:30:56.662476+00	2026-04-24 05:30:56.662476+00
b7c32f7b-869c-420e-b7a9-ff0b8c0c24ef	other_5	ja	| その他	auto	2026-04-24 05:30:56.666427+00	2026-04-24 05:30:56.666427+00
0f79070c-7879-4e3e-ae51-d904fd6b9e17	other_5	ko	| 기타	auto	2026-04-24 05:30:56.669449+00	2026-04-24 05:30:56.669449+00
9e929f5d-db66-4f2f-a123-b95dac567966	other_5	vi	Người khác	auto	2026-04-24 05:30:56.67311+00	2026-04-24 05:30:56.67311+00
f4b98c30-cabd-4515-848a-d373751ec166	other_5	tr	Diğer	auto	2026-04-24 05:30:56.676324+00	2026-04-24 05:30:56.676324+00
494609bc-0d19-442f-943d-605ec6602e60	other_5	ar	| آخر	auto	2026-04-24 05:30:56.71622+00	2026-04-24 05:30:56.71622+00
e9de89f0-e22e-4396-bea3-a977d1f78ae3	other_5	fa	دیگر	auto	2026-04-24 05:30:56.719961+00	2026-04-24 05:30:56.719961+00
d0395eab-b25e-4baf-81fb-3c3176b06635	other_5	ur	کچھ اور	auto	2026-04-24 05:30:56.72301+00	2026-04-24 05:30:56.72301+00
dddc90ab-3b37-480f-bd57-615c912cb49f	other_5	hi	अन्य	auto	2026-04-24 05:30:56.726052+00	2026-04-24 05:30:56.726052+00
884a9c69-7104-46ab-ad07-845ae374fec0	other_5	pt	Outros	auto	2026-04-24 05:30:56.728851+00	2026-04-24 05:30:56.728851+00
c6a5ac54-4ff6-45e6-92e8-d045bb667c08	other_5	ru	Другое	auto	2026-04-24 05:30:57.250364+00	2026-04-24 05:30:57.250364+00
167f5b92-eea9-4390-a4d1-757622d46b0d	other_5	sv	Övriga	auto	2026-04-24 05:30:57.25443+00	2026-04-24 05:30:57.25443+00
f2bf7411-ad9a-4127-b8bb-8b6953bd79b7	other_5	tl	Ulis	auto	2026-04-24 05:30:57.571014+00	2026-04-24 05:30:57.571014+00
5a13c295-a440-4cf0-a0eb-7d6479e2373b	other_6	es	Silencio	auto	2026-04-24 05:30:58.613187+00	2026-04-24 05:30:58.613187+00
0b5f050e-a397-4ff9-b000-80fd1f8adcbb	other_6	fr	Autres	auto	2026-04-24 05:30:58.616921+00	2026-04-24 05:30:58.616921+00
3df64a8b-6a55-4ed5-9fe2-34dccafc45a1	other_6	de	Sonstige	auto	2026-04-24 05:30:58.620074+00	2026-04-24 05:30:58.620074+00
8b5700b0-dc93-41ae-9ae9-402c1ff62f25	other_6	zh	其他情况	auto	2026-04-24 05:30:58.623274+00	2026-04-24 05:30:58.623274+00
41387c00-7db8-4173-a862-743d2139e819	other_6	ja	| その他	auto	2026-04-24 05:30:58.939352+00	2026-04-24 05:30:58.939352+00
d041c5ca-0191-4eed-822c-8cd51b3938b7	other_6	ko	| 기타	auto	2026-04-24 05:30:59.249224+00	2026-04-24 05:30:59.249224+00
3fe3de96-2d88-479e-a1a5-2798393cc3fa	other_6	vi	Người khác	auto	2026-04-24 05:30:59.547591+00	2026-04-24 05:30:59.547591+00
03547ad7-158d-4f08-bb76-94cddc691369	other_6	tr	Diğer	auto	2026-04-24 05:31:01.445008+00	2026-04-24 05:31:01.445008+00
c21df850-9f5d-4eb2-9435-238e85401132	other_6	ar	| آخر	auto	2026-04-24 05:31:01.84751+00	2026-04-24 05:31:01.84751+00
b6e50ba6-8fd1-4539-8115-db45bb745344	other_6	fa	دیگر	auto	2026-04-24 05:31:02.774237+00	2026-04-24 05:31:02.774237+00
55399f16-b5fd-48e8-b38f-777be8e27c1c	other_6	ur	کچھ اور	auto	2026-04-24 05:31:02.779399+00	2026-04-24 05:31:02.779399+00
4bb68ff2-911d-4541-822d-f9bbb00fb83d	other_6	hi	अन्य	auto	2026-04-24 05:31:03.197445+00	2026-04-24 05:31:03.197445+00
2f84e982-ba6b-462a-b995-79d502372c00	other_6	pt	Outros	auto	2026-04-24 05:31:03.435699+00	2026-04-24 05:31:03.435699+00
fd4c6058-8bb2-4182-9adb-d06772961dd6	other_6	ru	Другое	auto	2026-04-24 05:31:03.966608+00	2026-04-24 05:31:03.966608+00
d5c87ff0-3a55-4cc8-b0e7-36b39447db41	other_6	sv	Övriga	auto	2026-04-24 05:31:03.970843+00	2026-04-24 05:31:03.970843+00
69e6f94b-6b69-4b00-9d02-b5a4445116eb	other_6	tl	Ulis	auto	2026-04-24 05:31:04.282232+00	2026-04-24 05:31:04.282232+00
a0d9fde8-7226-45a4-95d2-ffb44b01d43d	marriage	es	Matrimonio permanente	auto	2026-04-24 05:31:05.443746+00	2026-04-24 05:31:05.443746+00
bf7d76cb-266c-45a5-8b53-08045c96da3c	marriage	fr	Mariage	auto	2026-04-24 05:31:05.638979+00	2026-04-24 05:31:05.638979+00
e490be68-df18-4937-be6f-83778ce7e028	marriage	de	| Heirat	auto	2026-04-24 05:31:05.868261+00	2026-04-24 05:31:05.868261+00
76f7466b-9d83-43e4-89df-7224b2d48b34	marriage	zh	结婚	auto	2026-04-24 05:31:05.967933+00	2026-04-24 05:31:05.967933+00
32a9ee96-6ae1-4bca-b4ce-d77bf77c5e24	marriage	ja	| 結婚	auto	2026-04-24 05:31:06.289885+00	2026-04-24 05:31:06.289885+00
2ef5a490-7cf7-4eef-94a1-9783b4360c93	marriage	ko	| 결혼	auto	2026-04-24 05:31:06.630108+00	2026-04-24 05:31:06.630108+00
06f23895-73c0-4e36-8729-3f248c771566	marriage	vi	▪ Hôn nhân	auto	2026-04-24 05:31:06.926185+00	2026-04-24 05:31:06.926185+00
9803dcc0-7985-4e7e-97e0-a46a1525cc17	marriage	tr	| Evlilik	auto	2026-04-24 05:31:07.006323+00	2026-04-24 05:31:07.006323+00
0301ee50-50fc-4653-81c4-367431c3c4b9	marriage	ar	الزواج	auto	2026-04-24 05:31:07.234767+00	2026-04-24 05:31:07.234767+00
5bfc0c15-4f1d-4f20-b945-16d5ee65bc94	marriage	fa	ازدواج	auto	2026-04-24 05:31:07.297608+00	2026-04-24 05:31:07.297608+00
884e2e25-4a49-4955-ab26-b06b4f1ba802	marriage	ur	نکاح	auto	2026-04-24 05:31:07.356414+00	2026-04-24 05:31:07.356414+00
1f79670a-9778-4bf8-97fe-f81849f4f9cb	marriage	hi	शादी	auto	2026-04-24 05:31:07.420904+00	2026-04-24 05:31:07.420904+00
cc48c572-cd3f-497d-a5f8-312931f3c298	marriage	pt	□ Casamento	auto	2026-04-24 05:31:07.654295+00	2026-04-24 05:31:07.654295+00
c9519773-54ad-45f0-83cf-a65d66306255	marriage	ru	Брак	auto	2026-04-24 05:31:07.77192+00	2026-04-24 05:31:07.77192+00
28ee1ec2-2aec-4123-bbf2-6ab692221c81	marriage	sv	Äktenskap	auto	2026-04-24 05:31:07.878451+00	2026-04-24 05:31:07.878451+00
8e5bc2c4-4028-4537-93ac-d4fa96640acb	marriage	tl	Tamang Pag - aasawa	auto	2026-04-24 05:31:08.060028+00	2026-04-24 05:31:08.060028+00
a056b5cd-082a-4463-ba2e-16a69b01a2df	in_a_relationship	es	Silencio en una relación	auto	2026-04-24 05:31:09.199176+00	2026-04-24 05:31:09.199176+00
38118e11-361e-4937-b12a-786d1de23f6a	in_a_relationship	fr	Dans une relation	auto	2026-04-24 05:31:09.456332+00	2026-04-24 05:31:09.456332+00
134beb2c-bb6b-4517-95b0-300cab9795ee	in_a_relationship	de	| In einer Beziehung	auto	2026-04-24 05:31:09.553613+00	2026-04-24 05:31:09.553613+00
4cee4a44-77f0-44b1-b28d-55ac74bd16cd	in_a_relationship	zh	· 在关系中	auto	2026-04-24 05:31:09.667653+00	2026-04-24 05:31:09.667653+00
03c5c729-c4d9-47e0-8473-05788ef91728	in_a_relationship	ja	| 関係性	auto	2026-04-24 05:31:09.777863+00	2026-04-24 05:31:09.777863+00
7ac040ca-ab01-4ced-8b7e-4ba5d61a8a17	in_a_relationship	ko	| 관계	auto	2026-04-24 05:31:09.856023+00	2026-04-24 05:31:09.856023+00
a528070f-7181-4825-a04b-31b9edbf0d0a	in_a_relationship	vi	▪ Trong mối quan hệ	auto	2026-04-24 05:31:09.989073+00	2026-04-24 05:31:09.989073+00
50691182-973e-4d83-bb8b-a06bff9aebb5	in_a_relationship	tr	| Bir ilişkide	auto	2026-04-24 05:31:10.158861+00	2026-04-24 05:31:10.158861+00
17a15881-f189-4f4b-b8cb-e495fe7c040a	in_a_relationship	ar	في علاقة	auto	2026-04-24 05:31:10.430287+00	2026-04-24 05:31:10.430287+00
8f9f1678-ecd5-44f6-9896-85d81d85339e	in_a_relationship	fa	در یک رابطه	auto	2026-04-24 05:31:15.904638+00	2026-04-24 05:31:15.904638+00
6cbc1fe3-cd13-45e3-9b21-c9c7f2bf76d9	in_a_relationship	ur	| میاں بیوی میں	auto	2026-04-24 05:31:16.190561+00	2026-04-24 05:31:16.190561+00
63ed4089-0b6a-4c8e-a764-ef3a694480b0	in_a_relationship	hi	In a relationship	auto	2026-04-24 05:31:16.329655+00	2026-04-24 05:31:16.329655+00
d0bd1068-f4b3-4107-9bb2-6aa34ff37160	in_a_relationship	pt	Em um relacionamento	auto	2026-04-24 05:31:16.448285+00	2026-04-24 05:31:16.448285+00
f013a61c-c76b-45d3-a194-e7bf050f6ea0	in_a_relationship	ru	В отношениях	auto	2026-04-24 05:31:16.686866+00	2026-04-24 05:31:16.686866+00
50eb78ba-a6c9-4cef-914f-92fbdc4fae67	in_a_relationship	sv	I ett förhållande	auto	2026-04-24 05:31:16.826942+00	2026-04-24 05:31:16.826942+00
5c240b9a-b2a5-4a64-93d7-2961b1105ee7	in_a_relationship	tl	Eksperimento sa Isang Kaugnayan	auto	2026-04-24 05:31:17.807085+00	2026-04-24 05:31:17.807085+00
62050039-5584-43b8-8476-726084674b4a	penpals	es	Penpals	auto	2026-04-24 05:31:19.569179+00	2026-04-24 05:31:19.569179+00
cae7f59c-53a0-484b-84e1-75f8de32b9c9	penpals	fr	Penpales	auto	2026-04-24 05:31:19.653145+00	2026-04-24 05:31:19.653145+00
a9f4bedb-57bd-4ce0-bad9-556f6be77560	penpals	de	| Brieffreunde	auto	2026-04-24 05:31:20.110223+00	2026-04-24 05:31:20.110223+00
6a2c8b9b-15e8-4753-9e70-8ed256da5add	penpals	zh	彭帕尔斯	auto	2026-04-24 05:31:20.243189+00	2026-04-24 05:31:20.243189+00
ed3b7bfa-62d0-42e1-a20e-86c574989f16	penpals	ja	| ペンパル	auto	2026-04-24 05:31:20.903833+00	2026-04-24 05:31:20.903833+00
57a396bb-3805-42b7-ac9c-df6c041bd976	penpals	ko	| 펜팔	auto	2026-04-24 05:31:21.404728+00	2026-04-24 05:31:21.404728+00
a4bf4928-13a6-4ec1-a9cc-114bf2656b69	penpals	vi	Hình viết tay	auto	2026-04-24 05:31:21.528758+00	2026-04-24 05:31:21.528758+00
240daf21-11c1-439a-8b9c-398bc53a330d	penpals	tr	| mektup arkadaşları	auto	2026-04-24 05:31:23.609978+00	2026-04-24 05:31:23.609978+00
0bc33130-86b7-4b65-bac2-62bc09f09a4d	penpals	ar	Penpals	auto	2026-04-24 05:31:23.720554+00	2026-04-24 05:31:23.720554+00
5777b810-0194-4d1b-bf89-49b866eabc04	penpals	fa	Penpals	auto	2026-04-24 05:31:23.858914+00	2026-04-24 05:31:23.858914+00
53a3e4a8-d2bc-433e-9814-62b1fbccae41	penpals	ur	ایس 	auto	2026-04-24 05:31:24.145643+00	2026-04-24 05:31:24.145643+00
80ac7608-aa1e-42e7-863a-be9da1bc8136	penpals	hi	Penpals	auto	2026-04-24 05:31:24.450344+00	2026-04-24 05:31:24.450344+00
618526d6-265d-4c6e-a1e3-0ca1f0098212	penpals	pt	Penpals	auto	2026-04-24 05:31:24.551622+00	2026-04-24 05:31:24.551622+00
78627e5f-50f9-4338-97e0-765691082995	penpals	ru	Пенпалы	auto	2026-04-24 05:31:24.680902+00	2026-04-24 05:31:24.680902+00
ed102340-f387-4928-aca7-bc9251af6e6f	penpals	sv	Penpals	auto	2026-04-24 05:31:24.780409+00	2026-04-24 05:31:24.780409+00
681910f1-1d32-4d7d-9f75-18ef73f1f0d5	penpals	tl	Mga Pag - aalis ng Tagapangalaga	auto	2026-04-24 05:31:25.042834+00	2026-04-24 05:31:25.042834+00
6089855c-e157-43ed-90d2-fe1170bc8acb	virtual_relationship_1	es	← Relación Virtual	auto	2026-04-24 05:31:26.307119+00	2026-04-24 05:31:26.307119+00
e5188cdf-4592-44ee-ad77-9888d1a93856	virtual_relationship_1	fr	Relation virtuelle	auto	2026-04-24 05:31:26.536916+00	2026-04-24 05:31:26.536916+00
3c6c827e-b9ce-4339-af7b-1497a177dae9	virtual_relationship_1	de	| Virtuelle Beziehung	auto	2026-04-24 05:31:26.667587+00	2026-04-24 05:31:26.667587+00
95ab865b-9909-49b6-ba12-d5fe9f757697	virtual_relationship_1	zh	虚拟关系	auto	2026-04-24 05:31:26.967819+00	2026-04-24 05:31:26.967819+00
bb91d81c-21c0-443b-95ef-64b66bfe5497	virtual_relationship_1	ja	| 仮想関係	auto	2026-04-24 05:31:27.093613+00	2026-04-24 05:31:27.093613+00
33411d61-7114-4bf8-a7e0-27be7af8db97	virtual_relationship_1	ko	| 가상 관계	auto	2026-04-24 05:31:27.414706+00	2026-04-24 05:31:27.414706+00
43b00d6b-b3b9-44f3-a01b-d9e93c93ebea	virtual_relationship_1	vi	▪ Quan hệ ảo	auto	2026-04-24 05:31:27.576519+00	2026-04-24 05:31:27.576519+00
0e4f87b4-359f-496e-9c9a-b09a25b8b5d9	virtual_relationship_1	tr	| Sanal İlişki	auto	2026-04-24 05:31:27.922269+00	2026-04-24 05:31:27.922269+00
27878121-adae-4ba6-ad73-dc392ae54b0b	virtual_relationship_1	ar	العلاقة الافتراضية	auto	2026-04-24 05:31:28.028186+00	2026-04-24 05:31:28.028186+00
d49dce95-0960-4425-bbbb-859d6d342c05	virtual_relationship_1	fa	رابطه مجازی	auto	2026-04-24 05:31:28.127693+00	2026-04-24 05:31:28.127693+00
e2a19e07-4482-4001-ba4b-e3523bc43631	virtual_relationship_1	ur	جگہ	auto	2026-04-24 05:31:28.215059+00	2026-04-24 05:31:28.215059+00
71121108-4392-42ea-9efd-30c92a14d5b7	virtual_relationship_1	hi	आभासी संबंध	auto	2026-04-24 05:31:28.292445+00	2026-04-24 05:31:28.292445+00
9817b5a2-e3cf-4e5e-8bb1-0ececb29aaf7	virtual_relationship_1	pt	Relacionamento Virtual	auto	2026-04-24 05:31:28.379034+00	2026-04-24 05:31:28.379034+00
efd74a87-4f7b-4bc3-bfb3-1491cbe7530f	virtual_relationship_1	ru	Виртуальные отношения	auto	2026-04-24 05:31:28.5716+00	2026-04-24 05:31:28.5716+00
9d335a91-7c86-454e-aebd-6caf11e67033	virtual_relationship_1	sv	Virtuellt förhållande	auto	2026-04-24 05:31:28.718206+00	2026-04-24 05:31:28.718206+00
67e2b9cc-7fe2-419a-82e2-1f262f7878fc	virtual_relationship_1	tl	Eksperimentong Kaugnayan	auto	2026-04-24 05:31:29.030111+00	2026-04-24 05:31:29.030111+00
7415c810-70eb-4173-bd29-bf135b467b2a	self_help	es	autoayuda	auto	2026-04-24 05:31:30.209281+00	2026-04-24 05:31:30.209281+00
ba412772-29dd-4a48-80c7-f23f107da208	self_help	fr	Auto-assistance	auto	2026-04-24 05:31:30.484864+00	2026-04-24 05:31:30.484864+00
2dbf3eee-419f-4165-9c57-cbfef2bed2d7	self_help	de	| Selbsthilfe	auto	2026-04-24 05:31:31.659356+00	2026-04-24 05:31:31.659356+00
7d627500-9662-44b3-a7c6-9431ba1b415e	self_help	zh	• 自助	auto	2026-04-24 05:31:31.886727+00	2026-04-24 05:31:31.886727+00
dcf30996-19e8-4196-9ce6-c6fb03cb93e3	self_help	ja	|自助努力	auto	2026-04-24 05:31:34.190859+00	2026-04-24 05:31:34.190859+00
1479b01a-6ebe-4768-9ec5-8bdb226e95fc	self_help	ko	| 셀프 도우미	auto	2026-04-24 05:31:34.383934+00	2026-04-24 05:31:34.383934+00
910d917b-57fd-4db6-b65c-40c7c383f055	self_help	vi	Tự giúp đỡ	auto	2026-04-24 05:31:34.485603+00	2026-04-24 05:31:34.485603+00
3a0c14a3-06dd-4091-a9cb-a7b741c66243	self_help	tr	| Self-help	auto	2026-04-24 05:31:34.60003+00	2026-04-24 05:31:34.60003+00
e8d252e6-ea75-404b-9606-866cc4325e12	self_help	ar	مساعدة ذاتية	auto	2026-04-24 05:31:34.717082+00	2026-04-24 05:31:34.717082+00
e893f854-3029-4bdf-92f9-0f446eed5143	self_help	fa	کمک به خود	auto	2026-04-24 05:31:34.823943+00	2026-04-24 05:31:34.823943+00
05892f15-46d2-491f-b45d-34b06ae470ea	self_help	ur	|خودی-	auto	2026-04-24 05:31:34.950641+00	2026-04-24 05:31:34.950641+00
635ee034-13ae-4508-b34f-ba0cd87639dd	self_help	hi	Self-Help	auto	2026-04-24 05:31:35.050478+00	2026-04-24 05:31:35.050478+00
b23b618f-e661-45ea-811a-3624b682351b	self_help	pt	□ Autoajuda	auto	2026-04-24 05:31:35.376779+00	2026-04-24 05:31:35.376779+00
2a3b8a86-18fe-46a1-a4dd-ec9ae70b59de	self_help	ru	Самопомощь	auto	2026-04-24 05:31:36.017726+00	2026-04-24 05:31:36.017726+00
76fec638-1684-49e7-b2d9-8a556d6dc215	self_help	sv	Självhjälp	auto	2026-04-24 05:31:36.365992+00	2026-04-24 05:31:36.365992+00
babd9e8a-8108-48bc-bcb5-61cbe848067d	self_help	tl	Ulising Sarili-Tulong	auto	2026-04-24 05:31:36.523697+00	2026-04-24 05:31:36.523697+00
290a4856-1258-47ee-a5a6-dc2891884943	hypnosis	es	Hypnosis	auto	2026-04-24 05:31:37.725803+00	2026-04-24 05:31:37.725803+00
71a90cfb-d6d9-4e3a-bf49-ff366771e578	hypnosis	fr	Hypnose	auto	2026-04-24 05:31:37.845901+00	2026-04-24 05:31:37.845901+00
1cf3976c-8573-459b-9cc2-0ec6ef73c605	hypnosis	de	| Hypnose	auto	2026-04-24 05:31:37.974146+00	2026-04-24 05:31:37.974146+00
00f6649c-278e-4f30-b6c1-9b46b2a3312e	hypnosis	zh	催眠术	auto	2026-04-24 05:31:38.118228+00	2026-04-24 05:31:38.118228+00
d031956f-9a0b-49a9-b96e-fe4abe983d8c	hypnosis	ja	| 催眠	auto	2026-04-24 05:31:39.504541+00	2026-04-24 05:31:39.504541+00
7cf750d0-c30d-47e6-b5b6-b86eecba2913	hypnosis	ko	| 증상	auto	2026-04-24 05:31:39.828687+00	2026-04-24 05:31:39.828687+00
161f22c3-2c98-47d7-abfc-b7af2926db19	hypnosis	vi	hội chứng hypnosis	auto	2026-04-24 05:31:40.114263+00	2026-04-24 05:31:40.114263+00
ff825f26-72d5-4251-82fc-2866b3bdf4ec	hypnosis	tr	| Hipnoz	auto	2026-04-24 05:31:40.318151+00	2026-04-24 05:31:40.318151+00
7dfe23f6-ca61-43dc-8eb8-1933243e2c44	hypnosis	ar	Hypnosis	auto	2026-04-24 05:31:40.468386+00	2026-04-24 05:31:40.468386+00
2a864287-ebab-4230-9bb5-670ca866199b	hypnosis	fa	هیپنوتیزم	auto	2026-04-24 05:31:40.823835+00	2026-04-24 05:31:40.823835+00
424c00c1-a60d-482b-9de8-fb4bbde60f02	hypnosis	ur	ایچ‌پنسسس	auto	2026-04-24 05:31:40.981635+00	2026-04-24 05:31:40.981635+00
c01846af-f2be-4c9b-8948-b711a9b4d1ba	hypnosis	hi	Hypnosis	auto	2026-04-24 05:31:41.153671+00	2026-04-24 05:31:41.153671+00
a03fb661-2819-4a0f-87b4-82a3979d026c	hypnosis	pt	• Hipnose	auto	2026-04-24 05:31:41.458879+00	2026-04-24 05:31:41.458879+00
cc9c4ea3-03e6-452b-9aed-4665932490e2	hypnosis	ru	Гипноз	auto	2026-04-24 05:31:42.073986+00	2026-04-24 05:31:42.073986+00
a6f13ed1-8deb-4e9f-8768-989da625a11c	hypnosis	sv	Hypnos	auto	2026-04-24 05:31:42.203351+00	2026-04-24 05:31:42.203351+00
97c492a1-aadc-4a7b-a88d-9ddb91f857dc	hypnosis	tl	Hypnosis ng mga tao	auto	2026-04-24 05:31:42.532214+00	2026-04-24 05:31:42.532214+00
76031b0e-7e10-4c7b-9fd9-b90afa3a0ad6	subliminals	es	Subliminals	auto	2026-04-24 05:31:43.696771+00	2026-04-24 05:31:43.696771+00
775316ca-53ba-49ea-a449-a73fe28c2ac5	subliminals	fr	Sous-liminaires	auto	2026-04-24 05:31:43.808393+00	2026-04-24 05:31:43.808393+00
fce0d939-bc56-4a5b-9c61-4aa2f4dded10	subliminals	de	Subliminals	auto	2026-04-24 05:31:43.927598+00	2026-04-24 05:31:43.927598+00
9ab7dcf0-d536-445f-b000-c17004fa9f4e	subliminals	zh	子词	auto	2026-04-24 05:31:44.204052+00	2026-04-24 05:31:44.204052+00
2127fb69-22da-42ac-a9b4-a9863ba02ae1	subliminals	ja	| 取扱分野	auto	2026-04-24 05:31:44.32752+00	2026-04-24 05:31:44.32752+00
f718fc55-d8ee-43c4-8132-244e72a80982	subliminals	ko	| 연혁	auto	2026-04-24 05:31:44.415075+00	2026-04-24 05:31:44.415075+00
3c913957-6a03-4267-87ca-fced55af7b3e	subliminals	vi	hội nghị địa hạt	auto	2026-04-24 05:31:44.697777+00	2026-04-24 05:31:44.697777+00
313fb054-b598-4687-b827-90de51f968b6	subliminals	tr	| Bilinçaltılar	auto	2026-04-24 05:31:45.714781+00	2026-04-24 05:31:45.714781+00
46dcb424-3708-4359-92f9-3045f0df1d7d	subliminals	ar	| سبليمنال	auto	2026-04-24 05:31:46.860412+00	2026-04-24 05:31:46.860412+00
430c7361-bbee-47d0-8c70-a190e20d1978	subliminals	fa	Subliminals	auto	2026-04-24 05:31:46.985287+00	2026-04-24 05:31:46.985287+00
bba0baaf-6c14-4b4d-9540-d2b7ea8a18cb	subliminals	ur	پیٹ کے اندر	auto	2026-04-24 05:31:47.103729+00	2026-04-24 05:31:47.103729+00
fb8b7ee7-3935-4f77-9976-efa2017114b6	subliminals	hi	Subliminals	auto	2026-04-24 05:31:47.313862+00	2026-04-24 05:31:47.313862+00
992805a5-eca4-4f18-af1d-c1fb80155e71	subliminals	pt	□ Subliminares	auto	2026-04-24 05:31:47.456288+00	2026-04-24 05:31:47.456288+00
88febbd9-a436-42a5-b890-978f4367db50	subliminals	ru	Подсознательные	auto	2026-04-24 05:31:47.609872+00	2026-04-24 05:31:47.609872+00
75d5ddf7-9314-47ed-b11c-060a0e15ded7	subliminals	sv	Subliminaler	auto	2026-04-24 05:31:47.949984+00	2026-04-24 05:31:47.949984+00
bf810f1b-6d43-4bd3-8742-bdebb12f9b66	subliminals	tl	Mga Subliminal ng Eksistensiya	auto	2026-04-24 05:31:48.321135+00	2026-04-24 05:31:48.321135+00
ab63e076-bf9d-4215-98e8-a17637fa83c9	other_7	es	Silencio	auto	2026-04-24 05:31:49.437703+00	2026-04-24 05:31:49.437703+00
643323eb-dcce-45f5-88de-07171d27208f	other_7	fr	Autres	auto	2026-04-24 05:31:49.497288+00	2026-04-24 05:31:49.497288+00
9f045edd-9a3a-43f9-b811-00d5ce98f674	other_7	de	Sonstige	auto	2026-04-24 05:31:49.766756+00	2026-04-24 05:31:49.766756+00
baa176b3-2358-4fbe-8509-d3f55aad1824	other_7	zh	其他情况	auto	2026-04-24 05:31:49.860676+00	2026-04-24 05:31:49.860676+00
702c424d-2afa-4153-b9e6-6990f922aa41	other_7	ja	| その他	auto	2026-04-24 05:31:49.935812+00	2026-04-24 05:31:49.935812+00
c7a0ef3c-a239-4d0e-a3a7-a3eb002eabd2	other_7	ko	| 기타	auto	2026-04-24 05:31:50.012885+00	2026-04-24 05:31:50.012885+00
a73d3cd4-ef4c-4cf6-93ee-b09454d6835d	other_7	vi	Người khác	auto	2026-04-24 05:31:50.129356+00	2026-04-24 05:31:50.129356+00
10533a6c-c241-44a1-8262-ed35917a69e2	other_7	tr	Diğer	auto	2026-04-24 05:31:51.826373+00	2026-04-24 05:31:51.826373+00
a5129728-57e6-4861-b13e-f947870d2761	other_7	ar	| آخر	auto	2026-04-24 05:31:52.170079+00	2026-04-24 05:31:52.170079+00
38243f1e-c2af-413f-b7fb-a5d4bb5795fb	other_7	fa	دیگر	auto	2026-04-24 05:31:52.246093+00	2026-04-24 05:31:52.246093+00
9e9fb0d5-8c8b-479a-8eb4-a080a1be989a	other_7	ur	کچھ اور	auto	2026-04-24 05:31:52.32227+00	2026-04-24 05:31:52.32227+00
98acdfa5-c8e8-4d88-bda9-c95aec96bddf	other_7	hi	अन्य	auto	2026-04-24 05:31:52.506743+00	2026-04-24 05:31:52.506743+00
7b73d88d-4a43-4e8e-bcb1-5da87003df68	other_7	pt	Outros	auto	2026-04-24 05:31:52.581748+00	2026-04-24 05:31:52.581748+00
93cc9a10-fc03-419e-a8a2-79bada414000	other_7	ru	Другое	auto	2026-04-24 05:31:52.682013+00	2026-04-24 05:31:52.682013+00
82959bc2-db7e-47ea-bc40-4f3a70b29a70	other_7	sv	Övriga	auto	2026-04-24 05:31:52.777873+00	2026-04-24 05:31:52.777873+00
70df5c04-4260-4bbe-81db-d772f27bb5a1	other_7	tl	Ulis	auto	2026-04-24 05:31:52.933326+00	2026-04-24 05:31:52.933326+00
5fa480a5-c0ee-400d-ba0b-2e298840577e	nlp	de	HANDEL	auto	2026-04-24 05:31:54.670431+00	2026-04-24 05:31:54.670431+00
3ddbedf8-a2be-465c-ae33-5867c625f7cc	nlp	tr	HUMP	auto	2026-04-24 05:31:57.137841+00	2026-04-24 05:31:57.137841+00
4349b77b-5275-4f8c-b04b-3fd00e80b48b	nlp	fa	HUMP	auto	2026-04-24 05:31:58.030564+00	2026-04-24 05:31:58.030564+00
15e040ed-5e29-435c-856b-e5a807f73da2	nlp	sv	HUMP	auto	2026-04-24 05:31:58.89551+00	2026-04-24 05:31:58.89551+00
76ea88cc-b6b4-466e-b421-f7c4257d0f1e	nlp	tl	HUMP	auto	2026-04-24 05:31:59.014599+00	2026-04-24 05:31:59.014599+00
57af60cc-935a-4eb5-a177-123f888875ef	dried_nuts	es	Nueces ocultas	auto	2026-04-24 05:32:00.215297+00	2026-04-24 05:32:00.215297+00
1de4a67a-2745-4288-9fac-100b26ddf785	dried_nuts	fr	Noix séchées	auto	2026-04-24 05:32:00.492582+00	2026-04-24 05:32:00.492582+00
749f5be9-98cd-4e7c-a05c-32c5b31a1e75	dried_nuts	de	| Getrocknete Nüsse	auto	2026-04-24 05:32:00.823391+00	2026-04-24 05:32:00.823391+00
19e07865-db38-409f-9716-000e49c62a73	dried_nuts	zh	干坚果	auto	2026-04-24 05:32:01.271744+00	2026-04-24 05:32:01.271744+00
8da33062-6898-4026-aba6-15e6e3156fb0	dried_nuts	ja	| 乾燥ナッツ	auto	2026-04-24 05:32:01.516235+00	2026-04-24 05:32:01.516235+00
6144fe33-7043-42c7-be2f-eca60b05ce7a	dried_nuts	ko	| 건조 너트	auto	2026-04-24 05:32:01.867836+00	2026-04-24 05:32:01.867836+00
a89a7593-1741-4fe4-bcd7-317e4d466559	dried_nuts	vi	tôm khô	auto	2026-04-24 05:32:02.21357+00	2026-04-24 05:32:02.21357+00
827bb996-4962-447a-8a2a-90850505ca6a	dried_nuts	tr	|	auto	2026-04-24 05:32:05.473006+00	2026-04-24 05:32:05.473006+00
409c9745-401b-499a-9661-7fec4d167cae	dried_nuts	ar	| المكسرات المجففة	auto	2026-04-24 05:32:06.630287+00	2026-04-24 05:32:06.630287+00
70b11e50-4917-4b98-83c9-cd411053c3f5	dried_nuts	fa	| آجیل خشک	auto	2026-04-24 05:32:07.973441+00	2026-04-24 05:32:07.973441+00
e5640d30-83d3-4753-b102-867d30a1ec73	dried_nuts	ur	ایس 	auto	2026-04-24 05:32:08.252131+00	2026-04-24 05:32:08.252131+00
2e238fdc-1a13-4ada-b883-a2ec4ae7d694	dried_nuts	hi	सूखे अखरोट	auto	2026-04-24 05:32:08.318137+00	2026-04-24 05:32:08.318137+00
42a62721-0beb-477f-8b61-8872c573e847	dried_nuts	pt	Nozes secas	auto	2026-04-24 05:32:08.428465+00	2026-04-24 05:32:08.428465+00
b7f0a266-4d21-4f95-aeed-2410c4cff9d7	dried_nuts	ru	Сухие орехи	auto	2026-04-24 05:32:08.634864+00	2026-04-24 05:32:08.634864+00
50af58cf-329e-4629-8de1-048827d1ae3a	dried_nuts	sv	Torkade nötter	auto	2026-04-24 05:32:08.984742+00	2026-04-24 05:32:08.984742+00
369d854a-3153-40fa-8943-78c1ae3e1a60	dried_nuts	tl	Natuyong Nuwes	auto	2026-04-24 05:32:09.226131+00	2026-04-24 05:32:09.226131+00
b1eb8d4a-0d94-4cdc-b96c-7cd47f7a07fe	cafes	es	TENCIÓN Cafeterías	auto	2026-04-24 05:32:10.578138+00	2026-04-24 05:32:10.578138+00
9d2db57c-cf6d-4a86-8082-ee4ba69f8ce0	cafes	fr	Cafés	auto	2026-04-24 05:32:10.877023+00	2026-04-24 05:32:10.877023+00
d3e6a7fe-6439-4164-bdc3-bef3980aab4b	cafes	de	| Cafés	auto	2026-04-24 05:32:12.436615+00	2026-04-24 05:32:12.436615+00
fa73cb03-37df-4fbe-9fb5-7888ae37b5ec	cafes	zh	咖啡馆	auto	2026-04-24 05:32:12.55123+00	2026-04-24 05:32:12.55123+00
d85f8e64-2860-41b2-8f19-e26f62955210	cafes	ja	| カフェ	auto	2026-04-24 05:32:12.656944+00	2026-04-24 05:32:12.656944+00
04ea7fff-6d23-48fb-bb29-8cdc04faf071	cafes	ko	| 카페	auto	2026-04-24 05:32:12.764991+00	2026-04-24 05:32:12.764991+00
5e1b4dfd-0d94-4f1c-91f2-23d3c83cf602	cafes	vi	teppi82	auto	2026-04-24 05:32:13.051332+00	2026-04-24 05:32:13.051332+00
854a4f08-ae1d-4390-990a-25ad530e4fd9	cafes	tr	| Kafeler	auto	2026-04-24 05:32:13.429888+00	2026-04-24 05:32:13.429888+00
b83d6053-489e-4270-9dce-87a76f13a0f9	cafes	ar	مقهى	auto	2026-04-24 05:32:13.959939+00	2026-04-24 05:32:13.959939+00
5739852a-ee36-4dac-abc7-0ff097a59daf	cafes	fa	کافه ها	auto	2026-04-24 05:32:14.047084+00	2026-04-24 05:32:14.047084+00
efc9ca51-268b-45d9-a6d6-953876c95fa6	cafes	ur	ع 	auto	2026-04-24 05:32:14.267856+00	2026-04-24 05:32:14.267856+00
9f3480e2-f573-472f-bfbb-624ed8aacc4c	cafes	hi	कैफे	auto	2026-04-24 05:32:14.619239+00	2026-04-24 05:32:14.619239+00
dc4e778d-9d7d-44b0-8e0e-9d3e5ca9b252	cafes	pt	Cafés	auto	2026-04-24 05:32:14.923146+00	2026-04-24 05:32:14.923146+00
71a60fe2-6e70-42c8-840b-325d238d8686	cafes	ru	Кафе	auto	2026-04-24 05:32:15.068723+00	2026-04-24 05:32:15.068723+00
5cf22f0f-904a-4852-bfb3-a9e60d7a42ec	cafes	sv	Cafes	auto	2026-04-24 05:32:15.372186+00	2026-04-24 05:32:15.372186+00
49d0936d-5648-47eb-8489-4afa51ee4638	cafes	tl	Mga Panuntunan sa Pag - aayos	auto	2026-04-24 05:32:15.618892+00	2026-04-24 05:32:15.618892+00
4cd1592a-0c47-4320-8a3f-39944526749a	lessons	es	TENENCIAS	auto	2026-04-24 05:32:16.768581+00	2026-04-24 05:32:16.768581+00
810fe136-be10-4cdd-beb6-0e6b8dec784f	lessons	fr	Enseignements	auto	2026-04-24 05:32:16.825133+00	2026-04-24 05:32:16.825133+00
bcea65c7-0f99-4977-9291-8ee1a91457a4	lessons	de	| Unterricht	auto	2026-04-24 05:32:16.906493+00	2026-04-24 05:32:16.906493+00
a2846eba-77b2-4375-9ecd-96e26fb9bfcc	lessons	zh	经验教训	auto	2026-04-24 05:32:16.982423+00	2026-04-24 05:32:16.982423+00
628808bf-e337-4e74-b133-0c22229abf57	lessons	ja	| レッスン	auto	2026-04-24 05:32:17.073808+00	2026-04-24 05:32:17.073808+00
4991403d-b6d8-49e7-be2f-9bb53497356f	lessons	ko	| 수업	auto	2026-04-24 05:32:17.152603+00	2026-04-24 05:32:17.152603+00
e7d0dc4f-6770-4c5a-804c-75c31e0c8317	lessons	vi	▪ Bài học	auto	2026-04-24 05:32:17.260167+00	2026-04-24 05:32:17.260167+00
a69a3583-6d25-47b4-ad60-018cb95836cb	lessons	tr	Dersler |	auto	2026-04-24 05:32:17.334915+00	2026-04-24 05:32:17.334915+00
7e9dce21-69c5-4776-8f54-2160b4b6b2af	lessons	ar	| دروس	auto	2026-04-24 05:32:17.440814+00	2026-04-24 05:32:17.440814+00
4bff7700-e065-410a-acb0-cf6bc6b21657	lessons	fa	درس ها	auto	2026-04-24 05:32:17.532864+00	2026-04-24 05:32:17.532864+00
d0b67920-2c85-41f6-93f5-6736ffd5e525	lessons	ur	اہم سبق	auto	2026-04-24 05:32:17.609402+00	2026-04-24 05:32:17.609402+00
8de5f99b-8cab-4e9a-a7d2-edb8cf6b75a5	lessons	hi	पाठ	auto	2026-04-24 05:32:17.763917+00	2026-04-24 05:32:17.763917+00
2be0b425-6283-4568-9d4b-05e1de972973	lessons	pt	Lições	auto	2026-04-24 05:32:18.004769+00	2026-04-24 05:32:18.004769+00
90cad7a7-1f89-47ce-8532-eca9aeb86b1e	lessons	ru	Уроки	auto	2026-04-24 05:32:18.127295+00	2026-04-24 05:32:18.127295+00
7b4d67c6-67ed-40e8-a002-ecfda802c16f	lessons	sv	Lektioner	auto	2026-04-24 05:32:18.245605+00	2026-04-24 05:32:18.245605+00
1f74a779-5ad8-48e6-a5b7-68b2c77e8066	lessons	tl	Mga Aral sa Pagsasanay	auto	2026-04-24 05:32:18.598881+00	2026-04-24 05:32:18.598881+00
ea14c4b7-bd41-46d6-af4d-9e2e88d3eb4c	men_seeking_women	es	Hombres que buscan mujeres	auto	2026-04-24 05:32:19.894448+00	2026-04-24 05:32:19.894448+00
f802699b-32f5-4cdc-b7da-cd760fb64937	men_seeking_women	fr	Hommes cherchant des femmes	auto	2026-04-24 05:32:20.029404+00	2026-04-24 05:32:20.029404+00
3496895e-f043-4c9c-9e18-e554a451fead	men_seeking_women	de	| Männer Suche Frauen	auto	2026-04-24 05:32:20.167504+00	2026-04-24 05:32:20.167504+00
f5b98163-1bde-43dd-aa20-ccd5355fe6c3	men_seeking_women	zh	寻找妇女的男子	auto	2026-04-24 05:32:20.285395+00	2026-04-24 05:32:20.285395+00
cf62144d-daeb-4bdd-b528-2a9522f58cfc	men_seeking_women	ja	| 男子女子会	auto	2026-04-24 05:32:20.694373+00	2026-04-24 05:32:20.694373+00
8adf5eb6-eaf0-4d5f-b086-4af68fff0105	men_seeking_women	ko	| 남성용 여성	auto	2026-04-24 05:32:20.794127+00	2026-04-24 05:32:20.794127+00
ba096ac0-cd49-4ecc-ab47-9d3e28483228	men_seeking_women	vi	▪ Người nam đi tìm phụ nữ	auto	2026-04-24 05:32:20.976422+00	2026-04-24 05:32:20.976422+00
48be77e7-2ba3-485c-838c-4c104d9976db	men_seeking_women	tr	| Erkekler Kadınlara Bakıyor	auto	2026-04-24 05:32:21.096952+00	2026-04-24 05:32:21.096952+00
7417e9a7-46d9-4340-9f96-e3612be713ac	men_seeking_women	ar	الرجال يبحثون عن نساء	auto	2026-04-24 05:32:21.208426+00	2026-04-24 05:32:21.208426+00
16577abc-9a6d-472f-ac01-7311b4380e84	men_seeking_women	fa	مردان به دنبال زنان	auto	2026-04-24 05:32:21.65397+00	2026-04-24 05:32:21.65397+00
64516694-7ced-4477-a7dd-832cccbeb909	men_seeking_women	ur	| مرد خواتین کو تلاش کرتے ہیں۔	auto	2026-04-24 05:32:21.844029+00	2026-04-24 05:32:21.844029+00
0d7216dc-449a-473a-b185-86168ed32b58	men_seeking_women	hi	पुरुषों की तलाश में महिलाओं	auto	2026-04-24 05:32:23.220096+00	2026-04-24 05:32:23.220096+00
cfe43269-71ed-4ec6-be0d-45ad1751a668	men_seeking_women	pt	Homens procurando mulheres	auto	2026-04-24 05:32:23.383544+00	2026-04-24 05:32:23.383544+00
1c4948b8-097c-43c4-8bf9-511d6341a978	men_seeking_women	ru	Мужчины ищут женщин	auto	2026-04-24 05:32:23.594954+00	2026-04-24 05:32:23.594954+00
1cdd0360-9043-4ba2-a598-147f99d9de39	men_seeking_women	sv	Män söker kvinnor	auto	2026-04-24 05:32:23.920063+00	2026-04-24 05:32:23.920063+00
e44b780c-df3c-4c58-b200-f92f5d5da899	men_seeking_women	tl	Mga Batang Lalaki na Naghahanap ng mga Babae	auto	2026-04-24 05:32:24.181801+00	2026-04-24 05:32:24.181801+00
3db083f3-d9c8-41b4-896b-b6b8135ec26f	men_seeking_men	es	Hombres que buscan hombres	auto	2026-04-24 05:32:26.047621+00	2026-04-24 05:32:26.047621+00
c07ffcb7-fb1e-4fe9-92cd-205108d6cdcf	men_seeking_men	fr	Hommes cherchant des hommes	auto	2026-04-24 05:32:26.343897+00	2026-04-24 05:32:26.343897+00
015bf037-cec0-4fe1-ac8a-69fe3b8ce030	men_seeking_men	de	| Männer Suche Männer	auto	2026-04-24 05:32:26.618066+00	2026-04-24 05:32:26.618066+00
83bf8b59-9a8a-4dc2-8bc8-ff9bb8192b04	men_seeking_men	zh	寻找男人的男子	auto	2026-04-24 05:32:26.883276+00	2026-04-24 05:32:26.883276+00
c93971af-8c98-4a76-b191-265d5865081c	nlp	zh	NLP 语言	auto	2026-04-24 05:31:54.944727+00	2026-04-24 07:05:21.887227+00
477a4316-3a07-4c95-b3ea-9de0a3d4feff	nlp	ja	NLPについて	auto	2026-04-24 05:31:55.379409+00	2026-04-24 07:05:22.220555+00
6743973d-4549-4aa6-870e-5c25d2a7c68a	nlp	ko	사이트맵	auto	2026-04-24 05:31:56.849182+00	2026-04-24 07:05:22.541698+00
73810491-28a8-474b-a7d0-7a82967c093c	nlp	ur	نیل	auto	2026-04-24 05:31:58.102798+00	2026-04-24 07:05:22.883125+00
5ed47873-08c5-4bfc-b1e9-99dd4c9f1096	nlp	hi	एनएलपी	auto	2026-04-24 05:31:58.176271+00	2026-04-24 07:05:22.888526+00
9259e1a4-1689-4480-83d5-b764b4c6013d	nlp	pt	PNL	auto	2026-04-24 05:31:58.254581+00	2026-04-24 07:05:23.184823+00
ce31fb80-6e51-476d-a598-641b182daf07	nlp	ru	НЛП	auto	2026-04-24 05:31:58.815181+00	2026-04-24 07:05:23.715578+00
cbad05e3-4785-4828-a1f6-1e9b299e4400	nlp	fr	PNL	auto	2026-04-24 05:31:54.564495+00	2026-04-24 07:05:21.832492+00
894cf93c-9454-4957-aae5-686dbcfe185f	men_seeking_men	ja	| 男子 男子 男子	auto	2026-04-24 05:32:27.378446+00	2026-04-24 05:32:27.378446+00
5205f236-807a-4681-b8e2-a40590a0c6e6	men_seeking_men	ko	| 남성 남성	auto	2026-04-24 05:32:27.474596+00	2026-04-24 05:32:27.474596+00
dfe402cc-dc82-4351-b3ce-7d59f67c7092	men_seeking_men	vi	❑ Người ta tìm kiếm loài người	auto	2026-04-24 05:32:27.785707+00	2026-04-24 05:32:27.785707+00
c308824d-b077-4cc0-ac8d-0161c8b5f5b0	men_seeking_men	tr	| Erkek Arayan Erkekler	auto	2026-04-24 05:32:28.67986+00	2026-04-24 05:32:28.67986+00
9dc9c372-0407-4192-a166-984435c1b126	men_seeking_men	ar	الرجال يبحثون عن الرجال	auto	2026-04-24 05:32:28.781433+00	2026-04-24 05:32:28.781433+00
8e0ac43e-8b88-4599-b10a-5b757441e7c1	men_seeking_men	fa	مردان به دنبال مردان	auto	2026-04-24 05:32:28.935254+00	2026-04-24 05:32:28.935254+00
542195de-ffd4-41da-b7bd-1e2fe0c6da98	men_seeking_men	ur	مردوں کی تلاش	auto	2026-04-24 05:32:29.272236+00	2026-04-24 05:32:29.272236+00
3bf6fe7d-d189-49b8-b524-6da8d22a192c	men_seeking_men	hi	पुरुषों की तलाश	auto	2026-04-24 05:32:29.612342+00	2026-04-24 05:32:29.612342+00
81c73244-5229-4820-9cf6-f72aa9620a50	men_seeking_men	pt	Homens que procuram homens	auto	2026-04-24 05:32:29.779416+00	2026-04-24 05:32:29.779416+00
cf9bcf01-a94d-40d5-b930-c7708195d9ee	men_seeking_men	ru	Мужчины ищут мужчин	auto	2026-04-24 05:32:30.421367+00	2026-04-24 05:32:30.421367+00
35a42512-0a20-4261-9b38-84fdf18302f1	men_seeking_men	sv	Män söker män	auto	2026-04-24 05:32:30.761528+00	2026-04-24 05:32:30.761528+00
4f1320e7-389d-4c00-92d3-d6d0eb76cf4b	men_seeking_men	tl	Mga Lalaking Ekstatiko na Naghahanap ng mga Tao	auto	2026-04-24 05:32:31.251516+00	2026-04-24 05:32:31.251516+00
6e6b47d4-0c82-43c9-84d1-e6a0f8774fac	women_seeking_men	es	Mujeres que buscan hombres	auto	2026-04-24 05:32:32.570645+00	2026-04-24 05:32:32.570645+00
454636b6-14c3-4ae3-bead-f99454a372b2	women_seeking_men	fr	Femmes cherchant des hommes	auto	2026-04-24 05:32:32.865768+00	2026-04-24 05:32:32.865768+00
88a34525-4e6f-4b96-a87a-22aeaea75e50	women_seeking_men	de	| Frauen Suche Männer	auto	2026-04-24 05:32:32.985774+00	2026-04-24 05:32:32.985774+00
5e640726-609d-4b5b-a19c-7eba6425e1be	women_seeking_men	zh	寻找男人的妇女	auto	2026-04-24 05:32:33.11128+00	2026-04-24 05:32:33.11128+00
30ed1df7-b2fe-4bad-941e-e1c2185ed29a	women_seeking_men	ja	| 女性活躍男性	auto	2026-04-24 05:32:33.255629+00	2026-04-24 05:32:33.255629+00
fe0bf19c-8a9f-43a9-8b9d-06c84bfe3dc7	women_seeking_men	ko	| 여성 남성	auto	2026-04-24 05:32:33.35168+00	2026-04-24 05:32:33.35168+00
a453e149-14cd-4762-9aed-8b7731b2987d	women_seeking_men	vi	▪ Phụ nữ đi tìm đàn ông	auto	2026-04-24 05:32:33.546009+00	2026-04-24 05:32:33.546009+00
4433469e-90cc-49c1-8bdd-17ede121b4fa	women_seeking_men	tr	| Kadınlar Erkekleri Görüyor	auto	2026-04-24 05:32:33.686631+00	2026-04-24 05:32:33.686631+00
efb1a45f-1099-4faa-887d-7d0d2a646b6f	women_seeking_men	ar	♪ Women Seeking Men	auto	2026-04-24 05:32:33.88417+00	2026-04-24 05:32:33.88417+00
98160987-50ac-471b-8078-ceeebc220d7d	women_seeking_men	fa	زنان به دنبال مردان	auto	2026-04-24 05:32:34.356069+00	2026-04-24 05:32:34.356069+00
f2b7c71d-0b1f-4863-b2e0-e7d9b93c64fa	women_seeking_men	ur	نمبر عورتیں مردوں کی تلاش میں ہیں	auto	2026-04-24 05:32:34.712478+00	2026-04-24 05:32:34.712478+00
b5ce7614-4070-4941-afc7-2d80bc00b485	women_seeking_men	hi	To seeing men	auto	2026-04-24 05:32:35.120018+00	2026-04-24 05:32:35.120018+00
03f46fa4-0577-4049-a700-77645463e791	women_seeking_men	pt	As mulheres procuram os homens	auto	2026-04-24 05:32:36.616984+00	2026-04-24 05:32:36.616984+00
686fc094-ae12-4c0c-9072-7cea10dba0b6	women_seeking_men	ru	Женщины ищут мужчин	auto	2026-04-24 05:32:36.875689+00	2026-04-24 05:32:36.875689+00
161a4fd7-c8d0-411f-86fc-0dd687f77f7a	women_seeking_men	sv	Kvinnor söker män	auto	2026-04-24 05:32:37.788065+00	2026-04-24 05:32:37.788065+00
b5b0e1b9-c70d-4a62-98dd-ee047e36ee79	women_seeking_men	tl	Mga Babaing Ekstatiko na Naghahanap ng mga Lalaki	auto	2026-04-24 05:32:38.064654+00	2026-04-24 05:32:38.064654+00
5e34dc00-a7bc-417a-ab88-7e0e982b4130	women_seeking_women	es	Mujeres que buscan mujeres	auto	2026-04-24 05:32:39.275774+00	2026-04-24 05:32:39.275774+00
afdb70ba-7185-4d04-b67c-d24884027523	women_seeking_women	fr	Femmes en quête de femmes	auto	2026-04-24 05:32:39.446318+00	2026-04-24 05:32:39.446318+00
b8a81c33-9ece-4086-9a9f-d2f531e57ca8	women_seeking_women	de	| Frauen Suche Frauen	auto	2026-04-24 05:32:39.986409+00	2026-04-24 05:32:39.986409+00
3b1a1036-40ef-4537-bd45-fc757bc8b8c0	women_seeking_women	zh	寻找妇女的妇女	auto	2026-04-24 05:32:40.259159+00	2026-04-24 05:32:40.259159+00
60c9c7e4-4de8-4585-a286-772da4c6daf9	women_seeking_women	ja	| 女性活躍女性	auto	2026-04-24 05:32:41.088306+00	2026-04-24 05:32:41.088306+00
16d5c098-17c9-4e16-8259-2a84c0d5901f	women_seeking_women	ko	| 여성용 여성	auto	2026-04-24 05:32:41.45608+00	2026-04-24 05:32:41.45608+00
201cbf04-63bc-4c75-b45e-f9ef6223ef42	women_seeking_women	vi	▪ Phụ nữ đi tìm phụ nữ	auto	2026-04-24 05:32:41.820706+00	2026-04-24 05:32:41.820706+00
66344d15-235e-4aec-8a8d-2de3735a24a1	women_seeking_women	tr	| Kadınlar Kadınları Görüyor	auto	2026-04-24 05:32:42.256059+00	2026-04-24 05:32:42.256059+00
a9b7375e-96f9-4d18-8681-29d98dbe541b	women_seeking_women	ar	النساء اللاتي يبحثن عن نساء	auto	2026-04-24 05:32:42.404808+00	2026-04-24 05:32:42.404808+00
9dc94e2f-a94c-4064-9050-6d1e54a41600	women_seeking_women	fa	زنان در جستجوی زنان	auto	2026-04-24 05:32:42.805941+00	2026-04-24 05:32:42.805941+00
77634f4e-301d-44f3-9e5c-1484c32f8e21	women_seeking_women	ur	۳ عورتوں کو تلاش	auto	2026-04-24 05:32:43.173215+00	2026-04-24 05:32:43.173215+00
330913d7-1c8a-47de-a2f7-cbef98448ce1	women_seeking_women	hi	महिलाओं की तलाश	auto	2026-04-24 05:32:43.504885+00	2026-04-24 05:32:43.504885+00
bce7bfe8-bffc-4e0a-b48d-2614911dc6b6	women_seeking_women	pt	Mulheres em Busca de Mulheres	auto	2026-04-24 05:32:43.64583+00	2026-04-24 05:32:43.64583+00
8f1cc478-aa18-406c-9c39-433266186af6	women_seeking_women	ru	Женщины ищут женщин	auto	2026-04-24 05:32:43.87665+00	2026-04-24 05:32:43.87665+00
0244c506-8b92-4333-b638-bc8fe3e5acd6	women_seeking_women	sv	Kvinnor söker kvinnor	auto	2026-04-24 05:32:44.014211+00	2026-04-24 05:32:44.014211+00
e63bf3dc-cd5d-4288-b9b7-bca3171482c9	women_seeking_women	tl	Mga Babaing Ekstatiko na Naghahanap ng mga Babae	auto	2026-04-24 05:32:44.2934+00	2026-04-24 05:32:44.2934+00
97b74bbd-8786-451a-a75e-ad5034785dcf	english_lessons	es	← Clases de Inglés	auto	2026-04-24 05:32:45.451185+00	2026-04-24 05:32:45.451185+00
9ecf6819-ca48-4e13-a241-9b1583f83dec	english_lessons	fr	Leçons d'anglais	auto	2026-04-24 05:32:45.554483+00	2026-04-24 05:32:45.554483+00
08fabffb-1771-4408-a402-40ae86efdc8c	english_lessons	de	| Englischkurse	auto	2026-04-24 05:32:45.801225+00	2026-04-24 05:32:45.801225+00
14f5569e-4f39-4564-97e4-e9199d417dd7	english_lessons	zh	英语课	auto	2026-04-24 05:32:45.879367+00	2026-04-24 05:32:45.879367+00
b4c51e8a-d7e8-4a1d-88d0-22280e3a3d8a	english_lessons	ja	| 英語レッスン	auto	2026-04-24 05:32:45.977154+00	2026-04-24 05:32:45.977154+00
f4b4e7a6-a32a-4776-bfa3-b44117408474	english_lessons	ko	| 한국어	auto	2026-04-24 05:32:46.2712+00	2026-04-24 05:32:46.2712+00
86131c11-ddba-43aa-a7aa-c2b1e2be9a38	english_lessons	vi	▪ Bài học tiếng Anh	auto	2026-04-24 05:32:46.42318+00	2026-04-24 05:32:46.42318+00
c693d7e3-7062-4ac8-9078-8d2074589e13	english_lessons	tr	| İngilizce Dersler	auto	2026-04-24 05:32:46.499987+00	2026-04-24 05:32:46.499987+00
8d75016f-251d-4202-9320-00de3a677bc6	english_lessons	ar	| دروس اللغة الانجليزية	auto	2026-04-24 05:32:47.864358+00	2026-04-24 05:32:47.864358+00
c9b302c4-d527-413f-a00e-1dbd03f79a8d	english_lessons	fa	درس های انگلیسی	auto	2026-04-24 05:32:47.963834+00	2026-04-24 05:32:47.963834+00
3d12d89d-a0eb-402d-9933-4b0863663010	english_lessons	ur	English انگریزی ادب	auto	2026-04-24 05:32:48.272042+00	2026-04-24 05:32:48.272042+00
9956c1e6-0449-4e56-8bd3-c124527648f0	english_lessons	hi	पाठ	auto	2026-04-24 05:32:48.669886+00	2026-04-24 05:32:48.669886+00
60696f7f-d47d-4c2c-b212-f7b2e93db369	english_lessons	pt	Aulas de Inglês	auto	2026-04-24 05:32:48.783491+00	2026-04-24 05:32:48.783491+00
c99f592d-277a-478f-a182-3752f6b22265	english_lessons	ru	Уроки английского	auto	2026-04-24 05:32:48.92484+00	2026-04-24 05:32:48.92484+00
d7692447-0376-442f-a066-be581bdb96df	english_lessons	sv	Engelska lektioner	auto	2026-04-24 05:32:49.069108+00	2026-04-24 05:32:49.069108+00
6cb79934-5bea-4286-8608-67f89b67e9cd	english_lessons	tl	Mga Leksiyong Ingles sa Eksperimento	auto	2026-04-24 05:32:49.463503+00	2026-04-24 05:32:49.463503+00
6517f851-dd65-47d6-b3e3-a5769b5bc060	20___30_year_olds	es	Silencio 20 - 30 años	auto	2026-04-24 05:32:50.89058+00	2026-04-24 05:32:50.89058+00
266ab04a-5b28-46c9-aec0-fca725b4da8a	20___30_year_olds	fr	20 - 30 ans	auto	2026-04-24 05:32:51.013848+00	2026-04-24 05:32:51.013848+00
4026503c-8197-43f1-ade2-d132f8c3c8fd	20___30_year_olds	de	| 20 - 30 Jahre	auto	2026-04-24 05:32:51.14657+00	2026-04-24 05:32:51.14657+00
cc4d2d7a-dfdb-48cc-a854-cd5d5278c364	20___30_year_olds	zh	20-30岁	auto	2026-04-24 05:32:51.287194+00	2026-04-24 05:32:51.287194+00
44f48f97-58fc-4cc1-8dd3-5491d012642f	20___30_year_olds	ja	| 20～30歳	auto	2026-04-24 05:32:51.410014+00	2026-04-24 05:32:51.410014+00
cbcff7f4-6c29-4d31-8b01-80c8f2c4835a	20___30_year_olds	ko	| 20～30세	auto	2026-04-24 05:32:51.562226+00	2026-04-24 05:32:51.562226+00
0571e4ff-6b69-4a1c-8a75-78b1827c1126	20___30_year_olds	vi	20 - 30 tuổi	auto	2026-04-24 05:32:51.68243+00	2026-04-24 05:32:51.68243+00
4dc0b413-fab1-469d-910f-7caf5ecda9a2	20___30_year_olds	tr	| 20 - 30 Yıl Yaşlılar	auto	2026-04-24 05:32:52.986298+00	2026-04-24 05:32:52.986298+00
35e6e792-12b6-4bab-8119-6f4af0fed04c	20___30_year_olds	ar	20-30 سنة	auto	2026-04-24 05:32:53.163185+00	2026-04-24 05:32:53.163185+00
be2fbc5f-b11a-4425-915e-d60d727f5d7c	20___30_year_olds	fa	20 - 30 ساله	auto	2026-04-24 05:32:54.352082+00	2026-04-24 05:32:54.352082+00
7af631ef-a471-45ec-be57-d7ff131b36f7	20___30_year_olds	ur	20 - 30 سال-	auto	2026-04-24 05:32:54.509656+00	2026-04-24 05:32:54.509656+00
0f6283de-429d-45a6-b0c6-46de4040de34	20___30_year_olds	hi	20 - 30 वर्ष पुराना	auto	2026-04-24 05:32:54.622474+00	2026-04-24 05:32:54.622474+00
81047c2b-5ff8-4da4-8854-becf1b33e670	20___30_year_olds	pt	20 - 30 Anos	auto	2026-04-24 05:32:54.900303+00	2026-04-24 05:32:54.900303+00
a4fd3da3-98c6-461b-9b4d-74e59fc589f1	20___30_year_olds	ru	20-30-летние дети	auto	2026-04-24 05:32:55.503436+00	2026-04-24 05:32:55.503436+00
d3e5eaa2-d534-48a0-9e39-232841a02428	20___30_year_olds	sv	20 - 30 år gammal	auto	2026-04-24 05:32:55.61872+00	2026-04-24 05:32:55.61872+00
a0ea3261-1bd3-43b4-8fdb-e3ff6e32cf86	20___30_year_olds	tl	Eksperimento 20 - 30 Taóng-Luma	auto	2026-04-24 05:32:55.970436+00	2026-04-24 05:32:55.970436+00
75c08250-ffda-48cb-94b8-4a7c0a1521f2	30___40_year_olds	es	Silencio 30 - 40 años	auto	2026-04-24 05:32:57.171744+00	2026-04-24 05:32:57.171744+00
d49f1349-3267-47d1-a3d6-9cdf892424c9	30___40_year_olds	fr	30 - 40 ans	auto	2026-04-24 05:32:57.295965+00	2026-04-24 05:32:57.295965+00
e6ab33fd-56bc-45b0-81af-741fbc3c2cba	30___40_year_olds	de	| 30 - 40 Jahre	auto	2026-04-24 05:32:57.577386+00	2026-04-24 05:32:57.577386+00
0bd938ab-5026-4073-a24b-daaf0db49018	30___40_year_olds	zh	30-40岁	auto	2026-04-24 05:32:57.847219+00	2026-04-24 05:32:57.847219+00
8a8a4d9b-315d-43a6-9612-3fa7e824df3d	30___40_year_olds	ja	| 30～40歳	auto	2026-04-24 05:32:57.981942+00	2026-04-24 05:32:57.981942+00
5d8c88f6-a87c-485d-9976-a56790fe3ca6	30___40_year_olds	ko	| 30 - 40 세	auto	2026-04-24 05:32:58.323555+00	2026-04-24 05:32:58.323555+00
6c9d6144-e74d-4d4a-9524-e204c289d90f	30___40_year_olds	vi	30 - 40 tuổi	auto	2026-04-24 05:32:58.450327+00	2026-04-24 05:32:58.450327+00
746a94b2-f4b4-443c-bc95-6a9d427652ee	30___40_year_olds	tr	| 30 - 40 Yıl Yaşlılar	auto	2026-04-24 05:32:58.604263+00	2026-04-24 05:32:58.604263+00
0f296186-006f-4594-b54c-108403c7dbe8	30___40_year_olds	ar	30 - 40 سنة	auto	2026-04-24 05:32:58.895427+00	2026-04-24 05:32:58.895427+00
45e1e753-e31a-4f02-b65b-0e5b994f7bd5	30___40_year_olds	fa	30 تا 40 سالگی	auto	2026-04-24 05:32:59.195797+00	2026-04-24 05:32:59.195797+00
997657c7-10ca-4c51-b45e-f41faade8816	30___40_year_olds	ur	30 - 40 سال-	auto	2026-04-24 05:32:59.326729+00	2026-04-24 05:32:59.326729+00
8ed55e6c-685b-4ca5-91ee-3674ce1c719b	30___40_year_olds	hi	30 - 40 वर्ष पुराना	auto	2026-04-24 05:32:59.433325+00	2026-04-24 05:32:59.433325+00
60122766-23ce-44db-b1f8-a791ccd0d6a0	30___40_year_olds	pt	30 - 40 anos	auto	2026-04-24 05:32:59.574977+00	2026-04-24 05:32:59.574977+00
54d62ce6-f431-469c-87ab-33d63f1eb3ed	30___40_year_olds	ru	30 - 40-летние дети	auto	2026-04-24 05:33:00.219363+00	2026-04-24 05:33:00.219363+00
d71b7fce-c5f1-4eaa-8bcf-9be3f3972277	30___40_year_olds	sv	30 - 40 år gammal	auto	2026-04-24 05:33:00.356952+00	2026-04-24 05:33:00.356952+00
89e5e8de-6c63-4916-9ebe-97bd3be7f225	30___40_year_olds	tl	Eksperimento 30 - 40 Taóng-Luma	auto	2026-04-24 05:33:00.600503+00	2026-04-24 05:33:00.600503+00
e6151476-3198-4ba2-9fdd-3f96705215cb	40___50_year_olds	es	Ø 40 - 50 años	auto	2026-04-24 05:33:01.828544+00	2026-04-24 05:33:01.828544+00
586a64c8-2c20-4557-8478-282871580d45	40___50_year_olds	fr	40 - 50 ans	auto	2026-04-24 05:33:01.954263+00	2026-04-24 05:33:01.954263+00
ce9039d2-4d32-4413-bb9f-f7d8f391874e	40___50_year_olds	de	| 40 - 50 Jahre	auto	2026-04-24 05:33:02.104485+00	2026-04-24 05:33:02.104485+00
45287a11-984c-4e12-a5bf-bf8686255095	40___50_year_olds	zh	40-50岁	auto	2026-04-24 05:33:02.267832+00	2026-04-24 05:33:02.267832+00
c10c5442-e4e5-41cb-b5cd-cf83bdc20dfa	40___50_year_olds	ja	| 40～50歳	auto	2026-04-24 05:33:02.700919+00	2026-04-24 05:33:02.700919+00
5afabf83-2e45-4abd-9bbf-15993592f7f6	40___50_year_olds	ko	| 40～50세	auto	2026-04-24 05:33:02.864509+00	2026-04-24 05:33:02.864509+00
8ad12da5-7423-43ee-ab1f-f0d1cd021e7c	40___50_year_olds	vi	40 - 50 tuổi	auto	2026-04-24 05:33:03.16971+00	2026-04-24 05:33:03.16971+00
02f82271-e283-458a-afe0-df48641f1952	40___50_year_olds	tr	40 - 50 Yıl Yaşlılar	auto	2026-04-24 05:33:03.352635+00	2026-04-24 05:33:03.352635+00
666e0937-65b9-4bd0-a30a-31789f83bb56	40___50_year_olds	ar	| 40 - 50 سنة	auto	2026-04-24 05:33:04.793612+00	2026-04-24 05:33:04.793612+00
8b5bdf26-3c9b-4722-ab99-0a6e0d167aa4	40___50_year_olds	fa	40 - 50 ساله	auto	2026-04-24 05:33:04.901757+00	2026-04-24 05:33:04.901757+00
6d98dc60-7cf6-4894-a95a-8ad0be7d41f1	40___50_year_olds	ur	40 - 50 سال-	auto	2026-04-24 05:33:05.059568+00	2026-04-24 05:33:05.059568+00
cd4238ec-2aed-4aaf-9d2d-110545d4f006	40___50_year_olds	hi	40 - 50 वर्ष पुराना	auto	2026-04-24 05:33:05.183636+00	2026-04-24 05:33:05.183636+00
16a2dd7a-d8b3-4565-9526-b3033b6ec988	40___50_year_olds	pt	40 - 50 anos	auto	2026-04-24 05:33:05.319671+00	2026-04-24 05:33:05.319671+00
0aa1616a-8ff5-4841-9e7e-8a6e18b220fa	40___50_year_olds	ru	40 - 50-летние дети	auto	2026-04-24 05:33:05.574164+00	2026-04-24 05:33:05.574164+00
8a6ed00a-7d8c-4217-ba4b-f4974f17feca	40___50_year_olds	sv	40 - 50 år gammal	auto	2026-04-24 05:33:05.712145+00	2026-04-24 05:33:05.712145+00
d5661935-a428-40bc-a927-a25ede4228a8	40___50_year_olds	tl	Tagapangulo 40 - 50 Taóng-Luma	auto	2026-04-24 05:33:05.978657+00	2026-04-24 05:33:05.978657+00
1e899d53-fe1c-4d66-a98d-95c9410ec98b	50___60_year_olds	es	Silencio 50 - 60 años	auto	2026-04-24 05:33:07.334053+00	2026-04-24 05:33:07.334053+00
4beb26ec-75c1-447f-b50f-8383624ca6de	50___60_year_olds	fr	50 - 60 ans	auto	2026-04-24 05:33:07.609418+00	2026-04-24 05:33:07.609418+00
b7f0a8e9-2168-4552-87b6-0010743f676d	50___60_year_olds	de	| 50 - 60 Jahre	auto	2026-04-24 05:33:07.759745+00	2026-04-24 05:33:07.759745+00
a628c188-dd56-4064-97da-4efb8f37bdb3	50___60_year_olds	zh	50-60岁	auto	2026-04-24 05:33:07.86565+00	2026-04-24 05:33:07.86565+00
e1a7a359-3fce-4f10-a4a4-aa9ec7e33942	50___60_year_olds	ja	| 50歳～60歳	auto	2026-04-24 05:33:07.98831+00	2026-04-24 05:33:07.98831+00
d20016a4-4764-4685-8567-dd01e2a80e10	50___60_year_olds	ko	| 50 - 60 세	auto	2026-04-24 05:33:08.105999+00	2026-04-24 05:33:08.105999+00
d55e5dac-7deb-437a-9cb0-c78c1eb2f1e4	50___60_year_olds	vi	50 - 60 tuổi	auto	2026-04-24 05:33:08.23043+00	2026-04-24 05:33:08.23043+00
bddd5433-bac0-446d-9309-7b500962bd32	50___60_year_olds	tr	50 - 60 Yıl Yaşlılar	auto	2026-04-24 05:33:08.619693+00	2026-04-24 05:33:08.619693+00
600a6d83-c1ba-4366-92cb-eb6f844b1f96	50___60_year_olds	ar	| 50 - 60 سنة	auto	2026-04-24 05:33:10.062173+00	2026-04-24 05:33:10.062173+00
97fc020d-cfa9-4417-8a6c-7ab487844684	50___60_year_olds	fa	50 - 60 ساله	auto	2026-04-24 05:33:10.168011+00	2026-04-24 05:33:10.168011+00
f0c901f6-54b0-4f6a-a1b1-12ae7310287b	50___60_year_olds	ur	| 50 - 60 سال-	auto	2026-04-24 05:33:10.337995+00	2026-04-24 05:33:10.337995+00
2e35b025-63d0-4525-8c1d-48ecc3ebabae	50___60_year_olds	hi	60 वर्ष पुराना	auto	2026-04-24 05:33:10.453372+00	2026-04-24 05:33:10.453372+00
93c93605-64e6-4955-b44a-0a5148e14905	50___60_year_olds	pt	50 - 60 anos	auto	2026-04-24 05:33:10.588591+00	2026-04-24 05:33:10.588591+00
4b1fe4af-b701-4703-9f6a-f5f35c02f083	50___60_year_olds	ru	50 - 60-летние дети	auto	2026-04-24 05:33:10.829769+00	2026-04-24 05:33:10.829769+00
696a2b86-9c12-4cbf-b560-e2fef44c3b70	50___60_year_olds	sv	50 - 60 år gammal	auto	2026-04-24 05:33:12.315121+00	2026-04-24 05:33:12.315121+00
a59120e3-fdd0-46a0-abc4-1171c63d5930	50___60_year_olds	tl	Eksperimento 50 - 60 Taóng-Luma	auto	2026-04-24 05:33:12.580599+00	2026-04-24 05:33:12.580599+00
8bdacc81-8303-45c6-aa9a-8fc024fe73a0	60__year_olds	es	tención 60+ Año-Olds	auto	2026-04-24 05:33:14.847049+00	2026-04-24 05:33:14.847049+00
afe4f41f-93fd-4565-a50f-aa38ee0beba5	60__year_olds	fr	60 ans et plus	auto	2026-04-24 05:33:14.948946+00	2026-04-24 05:33:14.948946+00
b9d7c110-0040-46ff-84d7-e23ed5b870a5	60__year_olds	de	| 60+ Jahre	auto	2026-04-24 05:33:15.089325+00	2026-04-24 05:33:15.089325+00
34aa5069-ca3a-4e67-9eee-13f1371ab1d4	60__year_olds	zh	60岁以上	auto	2026-04-24 05:33:15.407777+00	2026-04-24 05:33:15.407777+00
d23608e3-c61d-41de-83c1-0a83d78096b8	60__year_olds	ja	| 60歳以上	auto	2026-04-24 05:33:15.764255+00	2026-04-24 05:33:15.764255+00
9c6f5a0d-8cc8-4bd4-a117-a9e5877ac3cb	60__year_olds	ko	| 60세 이상	auto	2026-04-24 05:33:15.866646+00	2026-04-24 05:33:15.866646+00
ea1ff118-bda8-4858-87f2-81e7264b1585	60__year_olds	vi	 60 tuổi+	auto	2026-04-24 05:33:16.169719+00	2026-04-24 05:33:16.169719+00
3d9607c3-b84c-489d-8790-93aff9589eb7	60__year_olds	tr	60+ Yıl Yaşlılar	auto	2026-04-24 05:33:16.31563+00	2026-04-24 05:33:16.31563+00
b318aed1-1af5-4155-86b6-428d2e8b792f	60__year_olds	ar	| الأشخاص الذين تزيد أعمارهم عن 60 عامًا	auto	2026-04-24 05:33:17.28218+00	2026-04-24 05:33:17.28218+00
2b49d211-228a-4147-a346-fe7b12e77542	60__year_olds	fa	60+ ساله	auto	2026-04-24 05:33:17.640814+00	2026-04-24 05:33:17.640814+00
396bb448-fb71-4ef4-a839-02c8fb4a2bad	60__year_olds	ur	| 60+سال-قدیم	auto	2026-04-24 05:33:17.813229+00	2026-04-24 05:33:17.813229+00
11a3a960-b9c6-455c-83f6-deba39a7a4b6	60__year_olds	hi	60+ वर्ष पुराना	auto	2026-04-24 05:33:17.906642+00	2026-04-24 05:33:17.906642+00
dd659e45-120b-4b7a-9c27-f99436ef2efb	60__year_olds	pt	Mais de 60 anos	auto	2026-04-24 05:33:18.02486+00	2026-04-24 05:33:18.02486+00
5a590b9d-e826-4c93-9fcc-ac4f87eed6d7	60__year_olds	ru	60+ летних	auto	2026-04-24 05:33:18.210253+00	2026-04-24 05:33:18.210253+00
da3efeab-ca77-4cfe-ae9c-4591c8de4934	60__year_olds	sv	60+ år gammal	auto	2026-04-24 05:33:18.316612+00	2026-04-24 05:33:18.316612+00
f80f368e-fff6-43e6-ac58-975e34724efc	60__year_olds	tl	Eksperimento 60+ Taong-Matanda	auto	2026-04-24 05:33:18.683969+00	2026-04-24 05:33:18.683969+00
a4094a6a-6228-44d4-b956-74b2d0b55e58	nlp	es	PNL	auto	2026-04-24 05:31:54.488414+00	2026-04-24 07:05:21.538994+00
a28c80be-5251-41cc-aa2c-7790a5022391	nlp	ar	البرمجة اللغوية العصبية	auto	2026-04-24 05:31:57.320558+00	2026-04-24 07:05:22.751393+00
7915cc77-ea0e-4d87-9b47-f2e10d1ca995	nlp	vi	NLP	auto	2026-04-24 07:05:38.874183+00	2026-04-24 07:05:38.874183+00
ed7fa11f-989d-4982-9245-ef392b1e800c	fashion	tr	Moda	auto	2026-04-24 05:29:08.947208+00	2026-04-24 05:29:08.947208+00
572a0ef4-d5a4-4058-8ec5-64190d8dcc9d	crowdfunding	ru	Краудфандинг	auto	2026-04-26 17:19:46.412936+00	2026-04-26 18:10:58.541651+00
36cfdb12-44ae-49fc-a80e-fa8d630c183a	crowdfunding	tl	Nagkulumpunan	auto	2026-04-26 17:19:47.958845+00	2026-04-26 18:10:58.982409+00
3303db36-aadc-4077-9cf1-f65f7b0e3bd7	crowdfunding	de	Schwarmfinanzierung	manual	2026-04-26 17:40:26.154653+00	2026-04-26 18:18:14.995252+00
922c38c0-3a14-4a76-847a-848b525a2e7c	crowdfunding	sv	Folkfinansiering	manual	2026-04-26 17:40:26.570005+00	2026-04-26 18:21:59.516156+00
b7385214-cfef-468c-b66a-382c8b6d43f8	real_estate	sv	Fastigheter	manual	2026-04-24 05:29:44.684522+00	2026-04-26 18:23:03.576714+00
8c3ad770-0dc9-4a4e-b027-d56929ebce0c	jobs	fr	Emploi	auto	2026-04-26 19:56:35.921783+00	2026-04-26 19:56:35.921783+00
a580e7fa-8562-4cd6-a90f-faa4cc8b433e	jobs	zh	工作	auto	2026-04-26 19:56:37.425999+00	2026-04-26 19:56:37.425999+00
d376a32a-6a8c-4192-999f-e9d0501de72a	jobs	ja	求人情報	auto	2026-04-26 19:56:38.016611+00	2026-04-26 19:56:38.016611+00
f34ba95f-82f9-48ca-8e10-ef143245adf6	jobs	ko	한국어	auto	2026-04-26 19:56:38.683996+00	2026-04-26 19:56:38.683996+00
3da1be1e-4d16-4a84-998d-5b7c39753f60	jobs	tr	İşler	auto	2026-04-26 19:56:39.995298+00	2026-04-26 19:56:39.995298+00
4f6b3774-e2e6-43f5-8ebf-ce94a86ca13b	jobs	ar	الوظائف	auto	2026-04-26 19:56:41.76399+00	2026-04-26 19:56:41.76399+00
5d37fe1c-74c8-48e8-a8de-27fc2dde40f7	jobs	fa	شغل های شغلی	auto	2026-04-26 19:56:42.468987+00	2026-04-26 19:56:42.468987+00
f9ac094e-08e8-443a-829b-82a8580ec77b	jobs	ur	کام	auto	2026-04-26 19:56:42.945972+00	2026-04-26 19:56:42.945972+00
0642a0d4-e7bb-45b7-85c2-f31daa3ea863	jobs	hi	नौकरियां	auto	2026-04-26 19:56:43.662379+00	2026-04-26 19:56:43.662379+00
8171ebfa-c845-4638-b4e3-60fedf6d9af3	jobs	pt	Empregos	auto	2026-04-26 19:56:44.956798+00	2026-04-26 19:56:44.956798+00
83fc4a6c-a2ad-4d51-bb6f-6f7e3cda1599	jobs	ru	Работа	auto	2026-04-26 19:56:45.930565+00	2026-04-26 19:56:45.930565+00
755a856b-ea98-4240-8f5d-f18d990b41d5	jobs	sv	Jobb	auto	2026-04-26 19:56:46.287801+00	2026-04-26 19:56:46.287801+00
cbfdc215-712e-4c20-aef9-97802eb1a4e8	jobs	tl	Trabaho	auto	2026-04-26 19:56:46.571226+00	2026-04-26 19:56:46.571226+00
6ea4d5d0-ed02-48e6-a01d-a20999497276	jobs	es	Empleos	manual	2026-04-26 19:56:35.13722+00	2026-04-26 19:59:58.789962+00
8d67e4d8-3f12-4176-8c1d-50793300e706	jobs	de	Jobs / Stellenangebote	manual	2026-04-26 20:01:06.87532+00	2026-04-26 20:01:06.87532+00
7e3be551-716e-4374-8204-3a1a77557937	_9	es	mascotas	auto	2026-04-26 20:09:53.474851+00	2026-04-26 20:09:53.474851+00
5f04a6ef-bc8d-42c7-8d75-c1f20073a8ad	_9	fr	animaux de compagnie	auto	2026-04-26 20:09:55.766765+00	2026-04-26 20:09:55.766765+00
00cdbf6a-c2c9-43fb-a379-6bc9af07be6c	_9	de	Haustiere	auto	2026-04-26 20:09:57.038502+00	2026-04-26 20:09:57.038502+00
aec4ab75-b93a-406b-8589-c3e02b7731ca	_9	zh	宠物	auto	2026-04-26 20:09:57.445604+00	2026-04-26 20:09:57.445604+00
4aca93a2-dbe2-4c18-b44e-46865755ad42	_9	ja	ペット	auto	2026-04-26 20:09:58.087213+00	2026-04-26 20:09:58.087213+00
f718130c-f8ac-4dff-a523-cdc7e09a7e51	_9	ko	애완 동물	auto	2026-04-26 20:09:58.765785+00	2026-04-26 20:09:58.765785+00
ca50624a-0ee8-4474-80be-150c3e0bf317	_9	vi	Thú cưng	auto	2026-04-26 20:10:01.78728+00	2026-04-26 20:10:01.78728+00
f25ab19d-fd6c-402b-8459-7773e16bd70a	_9	tr	Evcil hayvan	auto	2026-04-26 20:10:02.279088+00	2026-04-26 20:10:02.279088+00
4117e13e-0b84-4ac6-b6d5-a00966c351ad	_9	ar	حيوانات أليفة	auto	2026-04-26 20:10:04.036002+00	2026-04-26 20:10:04.036002+00
1ce984d4-8c54-43ce-9661-355d97b80c79	_9	ur	جانوروں	auto	2026-04-26 20:10:04.659091+00	2026-04-26 20:10:04.659091+00
61966509-324a-4070-81f8-45772c717186	_9	hi	पालतू जानवर।	auto	2026-04-26 20:10:05.358786+00	2026-04-26 20:10:05.358786+00
3ddc0773-95b4-4e19-9d76-79ea8c208cf8	crowdfunding	es	Financiamiento colectivo	auto	2026-04-26 17:19:41.026509+00	2026-04-26 18:10:54.18259+00
56ff99c6-3cd3-4432-a85b-87a80b11db5b	crowdfunding	fr	Financement participatif	auto	2026-04-26 17:19:41.115637+00	2026-04-26 18:10:54.19513+00
29df99c8-f36d-42ce-bc0b-c99c37c8c6b0	_9	pt	Animais de estimação	auto	2026-04-26 20:10:05.90819+00	2026-04-26 20:10:05.90819+00
d4c7b16e-f229-43d7-88e9-97b10180ab8f	_9	ru	питомцы	auto	2026-04-26 20:10:09.380185+00	2026-04-26 20:10:09.380185+00
3ecef5bd-308a-4a51-8130-9e5ad6370e10	_9	sv	husdjur	auto	2026-04-26 20:10:10.074937+00	2026-04-26 20:10:10.074937+00
31227d28-5949-4bc3-920a-cfbb08c87dd8	_9	tl	alagang hayop	auto	2026-04-26 20:10:10.636646+00	2026-04-26 20:10:10.636646+00
82482c0e-a3c5-4624-8ad3-31022c82406f	crowdfunding	zh	人群资助	auto	2026-04-26 17:19:41.524469+00	2026-04-26 18:10:55.812202+00
3afe9412-141f-42a5-81fc-411a35bf555d	pets_pet_supplies	fr	Animaux de compagnie / fournitures pour animaux de compagnie	auto	2026-04-26 20:12:22.023468+00	2026-04-26 20:12:22.023468+00
3375aa17-8831-44c5-92be-febc42495825	crowdfunding	ja	クラウドファンディング	auto	2026-04-26 17:19:41.624141+00	2026-04-26 18:10:56.056182+00
f09ac3cd-70af-4b03-bbd0-1eb0d5657c50	crowdfunding	ko	구매하기	auto	2026-04-26 17:19:42.777974+00	2026-04-26 18:10:56.336516+00
f30d434b-32c8-4a0f-b65b-92a60ca1b5d9	crowdfunding	vi	Đám đông vui chơi	auto	2026-04-26 17:19:43.055864+00	2026-04-26 18:10:56.351018+00
e0ee2ea8-2188-43fa-81fb-dcbd5f51fb8f	crowdfunding	tr	Kitlesel fonlama	auto	2026-04-26 17:19:44.347883+00	2026-04-26 18:10:56.505566+00
69a1eb3b-549d-4cc9-ad20-247337fd6635	crowdfunding	ar	تمويل الحشد	auto	2026-04-26 17:19:44.654267+00	2026-04-26 18:10:56.795667+00
f4f97935-8a74-4e47-9a36-753029121850	crowdfunding	fa	بودجه جمعی	auto	2026-04-26 17:19:45.044485+00	2026-04-26 18:10:57.165601+00
60d36e49-e0c1-463e-be51-8c5ea4d7835a	crowdfunding	ur	نقل‌مکانی	auto	2026-04-26 17:19:45.130206+00	2026-04-26 18:10:57.360226+00
a7f19bca-451d-4d7f-aa6e-6490939954e3	crowdfunding	hi	क्राउडफंडिंग	auto	2026-04-26 17:19:45.461352+00	2026-04-26 18:10:57.663958+00
16f8711f-6805-4334-9758-1df4f10a3b86	crowdfunding	pt	Financiamento de multidões	auto	2026-04-26 17:19:45.732396+00	2026-04-26 18:10:57.907726+00
7d44fec2-1653-4288-a7d5-269ece2bf262	pets_pet_supplies	de	Haustiere / Haustiere	auto	2026-04-26 20:12:22.661618+00	2026-04-26 20:12:22.661618+00
60f7a789-aeaa-4e56-ab74-2de85630e679	pets_pet_supplies	zh	宠物/宠物用品	auto	2026-04-26 20:12:25.391225+00	2026-04-26 20:12:25.391225+00
39cc61ce-d1a0-462b-9e40-2bdac1f71c68	pets_pet_supplies	ja	ペット/ペット用品	auto	2026-04-26 20:12:26.237966+00	2026-04-26 20:12:26.237966+00
7deab69f-9410-408e-8479-d1c1fc90e5c6	pets_pet_supplies	ko	애완 동물 / 애완 동물 용품	auto	2026-04-26 20:12:26.596907+00	2026-04-26 20:12:26.596907+00
9abde59d-b58b-4267-a2ce-cc1e8b7560a9	pets_pet_supplies	vi	Vật nuôi / vật nuôi	auto	2026-04-26 20:12:26.935185+00	2026-04-26 20:12:26.935185+00
8c87f02e-b8bf-42db-a558-4e424eb7e867	pets_pet_supplies	tr	Evcil hayvanlar / Pet	auto	2026-04-26 20:12:27.555279+00	2026-04-26 20:12:27.555279+00
728deb66-2cc1-46f5-b1a8-f6cafc015395	pets_pet_supplies	ar	اللوازم المدرسية	auto	2026-04-26 20:12:28.132633+00	2026-04-26 20:12:28.132633+00
cc83c362-bc16-415b-810e-e01725bf8ee3	pets_pet_supplies	fa	حیوانات خانگی / لوازم خانگی	auto	2026-04-26 20:12:29.177487+00	2026-04-26 20:12:29.177487+00
703da12c-f03b-4201-a24d-edf01a10f9e6	pets_pet_supplies	ur	پَرَس / پَروں	auto	2026-04-26 20:12:31.034611+00	2026-04-26 20:12:31.034611+00
b25d1e80-0160-4e5f-96e7-5f6ac4bbe1a0	pets_pet_supplies	hi	पालतू पशु आपूर्ति	auto	2026-04-26 20:12:31.387666+00	2026-04-26 20:12:31.387666+00
1239832f-5f68-4065-8e63-c8b597394695	pets_pet_supplies	pt	Animais de estimação / Fornecimentos de animais de estimação	auto	2026-04-26 20:12:31.846068+00	2026-04-26 20:12:31.846068+00
b7b289fa-9e1a-4838-aba2-f05c1a74976a	pets_pet_supplies	ru	Питомцы / Pet Supplies	auto	2026-04-26 20:12:34.401969+00	2026-04-26 20:12:34.401969+00
7b466dcf-5447-481c-bc28-334f7699ec93	pets_pet_supplies	sv	Husdjur / Pet Supplies	auto	2026-04-26 20:12:35.145811+00	2026-04-26 20:12:35.145811+00
2b6845f4-2707-445f-a177-1252a745a3d4	pets_pet_supplies	tl	Mga Alagang Hayop / Alagang Hayop	auto	2026-04-26 20:12:35.981297+00	2026-04-26 20:12:35.981297+00
864a060d-5057-4c6e-85c7-97188d84bd4c	pets_pet_supplies	es	Mascotas	manual	2026-04-26 20:12:21.344329+00	2026-04-26 20:13:04.066896+00
ce7e0b5d-b28d-49ea-a117-49df74950507	jobs	vi	Công việc	manual	2026-04-26 19:56:39.16316+00	2026-04-26 20:34:24.493346+00
0c9b5721-d27d-4100-948e-95e06ff586a9	personals	hi	डेटिंग / दोस्ती	manual	2026-04-24 05:29:48.698998+00	2026-04-26 20:39:56.945607+00
\.


--
-- Data for Name: competitor_insights; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.competitor_insights (id, seller_id, category, avg_competitor_price_cents, price_position, market_share_percent, competitive_advantage, recommended_action, created_at) FROM stdin;
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversations (id, listing_id, buyer_id, seller_id, subject, last_message_at, created_at) FROM stdin;
8decc8d4-f579-40f1-ba8f-5a2fea5024c0	10fbf492-a8a5-40c9-8143-f6e944161c0c	e8ce3170-c7c9-48d3-8ba2-529a2dcf2d7d	dfb80e70-2782-4e00-a328-384d8806897f	10 Googol Raised to The Power of 10 x Strength Subliminal	2026-04-19 04:23:13.044104	2026-04-19 04:19:47.2218
\.


--
-- Data for Name: dispute_evidence; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dispute_evidence (id, dispute_id, uploaded_by, file_url, file_type, created_at) FROM stdin;
\.


--
-- Data for Name: dispute_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dispute_messages (id, dispute_id, sender_id, message, is_admin_message, created_at) FROM stdin;
\.


--
-- Data for Name: disputes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.disputes (id, user_id, transaction_id, order_id, title, description, status, resolution_notes, resolved_by, resolved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: escrow_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.escrow_transactions (id, order_id, buyer_id, seller_id, listing_id, amount_cents, platform_fee_cents, seller_payout_cents, paypal_order_id, paypal_capture_id, status, held_at, released_at, released_by, tracking_number, tracking_carrier, delivery_confirmed_at, buyer_acceptance, auto_release_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: exchange_rates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.exchange_rates (id, from_currency, to_currency, rate, updated_by, created_at, updated_at) FROM stdin;
78e7e3ef-f7c9-4334-bec8-314537c95708	Credon-USD	Credon-CAD	1.35000000	\N	2026-04-07 05:27:50.52505	2026-04-07 05:27:50.52505
84b9a1d6-8b70-40ef-b35c-6e77361bb019	Credon-USD	Credon-EUR	0.92000000	\N	2026-04-07 05:27:50.52505	2026-04-07 05:27:50.52505
26bfd51e-60a1-487b-87ba-0a2e4197afc6	Credon-USD	Credon-VND	25000.00000000	\N	2026-04-07 05:27:50.52505	2026-04-07 05:27:50.52505
92794e6b-6cda-43a7-b418-65e398f0a674	Credon-USD	Credon-BTC	0.00001500	\N	2026-04-07 05:27:50.52505	2026-04-07 05:27:50.52505
e24226f8-ae12-431a-b5d5-ef182f2fac70	Credon-USD	Credon-ETH	0.00025000	\N	2026-04-07 05:27:50.52505	2026-04-07 05:27:50.52505
6a6f36f8-e8ef-4cc2-ba54-a34cb2c8dcaf	Credon-USD	USD	1.00000000	\N	2026-04-07 05:27:50.52505	2026-04-07 05:27:50.52505
d05a4d88-d90f-4ef9-9fd5-41d5d45fdab6	Credon-USD	CAD	1.35000000	\N	2026-04-07 05:27:50.52505	2026-04-07 05:27:50.52505
5ad1fb1a-6b17-4e7a-b993-d2339fc01df8	Credon-USD	EUR	0.92000000	\N	2026-04-07 05:27:50.52505	2026-04-07 05:27:50.52505
a4905524-d57a-4ee3-8160-bbb040758e82	Credon-USD	GBP	0.79000000	\N	2026-04-07 05:27:50.52505	2026-04-07 05:27:50.52505
fefcb877-312b-4003-8cce-bd6715c2290f	Credon-CAD	Credon-USD	0.74000000	\N	2026-04-07 05:27:50.52505	2026-04-07 05:27:50.52505
8d62c933-430e-4e15-9280-49a585f19eb7	Credon-EUR	Credon-USD	1.08700000	\N	2026-04-07 05:27:50.52505	2026-04-07 05:27:50.52505
be1fe5c4-ab98-4650-8e29-85a18ebb2062	Credon-BTC	Credon-USD	66666.67000000	\N	2026-04-07 05:27:50.52505	2026-04-07 05:27:50.52505
66e76ef3-94ab-4c61-bc3e-b920e414d2be	Credon-ETH	Credon-USD	4000.00000000	\N	2026-04-07 05:27:50.52505	2026-04-07 05:27:50.52505
\.


--
-- Data for Name: fee_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fee_transactions (id, order_id, amount_cents, fee_percent, collected_at) FROM stdin;
\.


--
-- Data for Name: gift_card_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gift_card_transactions (id, gift_card_id, purchase_id, amount_cents, transaction_type, balance_after_cents, created_at) FROM stdin;
\.


--
-- Data for Name: gift_cards; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gift_cards (id, code, initial_amount_cents, current_balance_cents, purchaser_id, purchaser_email, recipient_name, recipient_email, message, is_redeemed, redeemed_by, redeemed_at, expires_at, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: help_articles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.help_articles (id, title, slug, content, category, views, is_published, created_by, created_at, updated_at) FROM stdin;
0f4e35d6-ceb1-4e3f-bc4f-3796b46478e7	Getting Started as a Buyer	buyer-getting-started	# Getting Started as a Buyer\\n\\nWelcome to HeavensLive Shop! This guide will help you start buying.\\n\\n## Finding Items\\nUse the search bar or browse categories.\\n\\n## Making an Offer\\nFor classifieds and mall items, you can make an offer.\\n\\n## Bidding on Auctions\\nPlace bids on auction items. Bids must be at least 10% higher than the current bid.	buyer	0	t	\N	2026-04-14 06:01:36.052626	2026-04-14 06:01:36.052626
40271e1f-9734-4fbe-9214-edcfb3a24377	Getting Started as a Seller	seller-getting-started	# Getting Started as a Seller\\n\\nWelcome to HeavensLive Shop! Start selling today.\\n\\n## Creating a Listing\\nClick Post a Listing and fill out the details.\\n\\n## Listing Types\\n- Mall: Fixed price items\\n- Classifieds: Fixed price with offer option\\n- Auction: Bidding format\\n- Reverse Auction: Sellers compete for your business	seller	0	t	\N	2026-04-14 06:01:36.052626	2026-04-14 06:01:36.052626
3ba84bca-9581-4d5d-b92c-c6b973c28810	Fees and Payments	fees-and-payments	# Fees and Payments\\n\\n## Platform Fees\\nPlatform fees are calculated at checkout.\\n\\n## Payment Methods\\nWe accept PayPal for all transactions.\\n\\n## Receiving Payments\\nSellers receive payments directly to their PayPal account.	general	0	t	\N	2026-04-14 06:01:36.052626	2026-04-14 06:01:36.052626
2411c63b-5e57-40b9-9262-604c22e1585b	Shipping Guidelines	shipping-guidelines	# Shipping Guidelines\\n\\n## Shipping Options\\nChoose from multiple carriers at checkout.\\n\\n## Tracking\\nAlways provide tracking numbers for shipped items.\\n\\n## International Shipping\\nCurrently available to select countries.	shipping	0	t	\N	2026-04-14 06:01:36.052626	2026-04-14 06:01:36.052626
\.


--
-- Data for Name: listing_translations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.listing_translations (id, listing_id, language_code, title, description, translated_by, created_at, updated_at, search_vector) FROM stdin;
d5a959e9-4462-4f64-ae85-3cc4389c96cf	64193ab0-3546-4c83-9a2d-06651461ba80	es	1x Subliminales personalizados de fuerza	Tendrás que comunicar tus metas con eficacia a mí a través de una ruta de comunicación acordada. Y crearé tu grabación de audio subliminal de fuerza 1x dentro de unos días a una semana. La entrega puede ser instantánea con un método de entrega digital o para la entrega de memoria USB física, por favor proporcione detalles de envío.	auto	2026-04-24 03:46:27.237365+00	2026-04-24 03:46:27.237365+00	'1x':1A,32B 'acordada':22B 'audio':28B 'comunicación':21B 'comunicar':8B 'con':11B,45B 'crearé':24B 'de':4A,17B,20B,27B,30B,34B,48B,55B,63B 'dentro':33B 'detall':62B 'digit':50B 'días':36B 'eficacia':12B 'entrega':41B,49B,54B 'envío':64B 'favor':60B 'fuerza':5A,31B 'física':58B 'grabación':26B 'instantánea':44B 'la':40B,53B 'memoria':56B 'meta':10B 'método':47B 'mí':14B 'o':51B 'para':52B 'personalizado':3A 'por':59B 'proporcion':61B 'pued':42B 'que':7B 'ruta':19B 'semana':39B 'ser':43B 'sublimin':29B 'subliminal':2A 'tendrá':6B 'travé':16B 'tu':25B 'tus':9B 'un':46B 'una':18B,38B 'uno':35B 'usb':57B 'y':23B
4fd9cf6e-284a-4ad2-9a00-6b12c6fe844d	64193ab0-3546-4c83-9a2d-06651461ba80	fr	1x subliminaux personnalisés de force	Vous devrez me communiquer vos objectifs efficacement par un itinéraire de communication convenu. Et je vais créer votre enregistrement sonore subliminal de force 1x dans quelques jours à une semaine. La livraison peut être instantanée avec une méthode de livraison numérique ou pour la livraison de clé USB physique, veuillez fournir des détails d'expédition.	auto	2026-04-24 03:46:30.264318+00	2026-04-24 03:46:30.264318+00	'1x':1A,29B 'avec':41B 'clé':52B 'communic':17B 'communiqu':9B 'convenu':18B 'créer':22B 'd':59B 'dan':30B 'de':4A,16B,27B,44B,51B 'des':57B 'devrez':7B 'détail':58B 'efficac':12B 'enregistr':24B 'et':19B 'expédit':60B 'forc':5A,28B 'fournir':56B 'instantané':40B 'itinérair':15B 'je':20B 'jour':32B 'la':36B,49B 'livraison':37B,45B,50B 'méthode':43B 'numériqu':46B 'objectif':11B 'ou':47B 'par':13B 'personnalisé':3A 'peut':38B 'physiqu':54B 'pour':48B 'quelqu':31B 'semain':35B 'sonor':25B 'sublimin':26B 'subliminaux':2A 'un':14B 'une':34B,42B 'usb':53B 'vai':21B 'veuillez':55B 'vos':10B 'votr':23B 'vous':6B 'à':33B 'être':39B
7a90673c-f05c-4558-9737-87e6dc630c93	64193ab0-3546-4c83-9a2d-06651461ba80	de	1x Stärke kundenspezifische Subliminale	Sie müssen Ihre Ziele über eine vereinbarte Kommunikationsroute effektiv mit mir kommunizieren. Und ich werde Ihre 1x Stärke Subliminal-Audioaufnahme innerhalb von wenigen Tagen bis zu einer Woche erstellen. Lieferung kann sofort mit einer digitalen Liefermethode oder zur physischen USB-Stick-Lieferung, bitte liefern Versanddetails.	auto	2026-04-24 03:46:30.678141+00	2026-04-24 03:46:30.678141+00	'1x':1A,21B 'audioaufnahm':25B 'bis':30B 'bitt':49B 'digitalen':40B 'effektiv':13B 'ein':10B 'einer':32B,39B 'erstellen':34B 'ich':18B 'ihr':7B,20B 'innerhalb':26B 'kann':36B 'kommunikationsrout':12B 'kommunizieren':16B 'kundenspezifisch':3A 'liefermethod':41B 'liefern':50B 'lieferung':35B,48B 'mir':15B 'mit':14B,38B 'müssen':6B 'oder':42B 'physischen':44B 'sie':5B 'sofort':37B 'stick':47B 'stärke':2A,22B 'sublimin':24B 'subliminal':4A 'subliminal-audioaufnahm':23B 'tagen':29B 'und':17B 'usb':46B 'usb-stick-lieferung':45B 'vereinbart':11B 'versanddetail':51B 'von':27B 'wenigen':28B 'werd':19B 'woch':33B 'ziel':8B 'zu':31B 'zur':43B 'über':9B
676de8e8-e385-49fc-9fb3-1fa45659b39f	64193ab0-3546-4c83-9a2d-06651461ba80	zh	1x 强度自定义子符号	你得通过一条商定的通信路线 有效地向我传达你的目标 我会在几天到一个星期内 创建你的1x强度 潜心录音 以数字投递方法即时投递,或用于有形的USB棒投递,请提供运输详情.	auto	2026-04-24 03:46:32.333051+00	2026-04-24 03:46:32.333051+00	'1x':1A '以数字投递方法即时投递':8B '你得通过一条商定的通信路线':3B '创建你的1x强度':6B '强度自定义子符号':2A '我会在几天到一个星期内':5B '或用于有形的usb棒投递':9B '有效地向我传达你的目标':4B '潜心录音':7B '请提供运输详情':10B
59bb0983-dc8b-45db-bfeb-9c6cf6039dfb	64193ab0-3546-4c83-9a2d-06651461ba80	ja	1x強さの注文の昇華	コミュニケーション経路で合意した上で、目標を効果的に伝える必要があります。 そして、数日以内に1xの強度のサブリムジンオーディオ録画を週に作成します。 配達はデジタル配達方法とまたは物理的なUSBの棒配達のためにすぐに、船積みの細部を提供できます.	auto	2026-04-24 03:46:33.929904+00	2026-04-24 03:46:33.929904+00	'1x強さの注文の昇華':1A 'そして':4B 'コミュニケーション経路で合意した上で':2B '数日以内に1xの強度のサブリムジンオーディオ録画を週に作成します':5B '目標を効果的に伝える必要があります':3B '船積みの細部を提供できます':7B '配達はデジタル配達方法とまたは物理的なusbの棒配達のためにすぐに':6B
dd9b3daf-90c8-4092-8668-0ed98edad5c6	64193ab0-3546-4c83-9a2d-06651461ba80	ko	1x 힘 관례 승화	의사 소통 경로를 통해 목표를 효과적으로 의사 소통해야합니다. 그리고 나는 당신의 1x 힘 subliminal 오디오 녹음을 일주일에 몇 일 안에 창조할 것입니다. 납품은 디지털 방식으로 납품 방법 또는 물리적 USB 지팡이 납품을 위해 즉시 일 수 있습니다, 선박 세부사항을 제공하십시오.	auto	2026-04-24 03:46:35.2282+00	2026-04-24 03:46:35.2282+00	'1x':1A,16B 'sublimin':18B 'usb':34B '것입니다':26B '경로를':7B '관례':3A '그리고':13B '나는':14B '납품':30B '납품은':27B '납품을':36B '녹음을':20B '당신의':15B '디지털':28B '또는':32B '몇':22B '목표를':9B '물리적':33B '방법':31B '방식으로':29B '선박':42B '세부사항을':43B '소통':6B '소통해야합니다':12B '수':40B '승화':4A '안에':24B '오디오':19B '위해':37B '의사':5B,11B '일':23B,39B '일주일에':21B '있습니다':41B '제공하십시오':44B '즉시':38B '지팡이':35B '창조할':25B '통해':8B '효과적으로':10B '힘':2A,17B
2e7abf53-d5e6-48b6-b836-cbd95120a5b5	64193ab0-3546-4c83-9a2d-06651461ba80	vi	1x phụ cấp sức mạnh	Anh sẽ cần giao tiếp một cách hiệu quả với tôi thông qua một thỏa thuận trên đường liên lạc. Và tôi sẽ tạo ra đoạn ghi âm siêu âm 1x trong vòng vài ngày đến một tuần. Giao hàng có thể ngay lập tức với phương pháp giao hàng kỹ thuật số hoặc để chuyển giao thẻ USB vật lý, xin vui lòng cung cấp chi tiết vận chuyển.	auto	2026-04-24 03:46:36.764782+00	2026-04-24 03:46:36.764782+00	'1x':1A,36B 'anh':6B 'chi':72B 'chuyển':61B,75B 'cung':70B 'cách':12B 'có':46B 'cấp':3A,71B 'cần':8B 'ghi':32B 'giao':9B,44B,54B,62B 'hiệu':13B 'hoặc':59B 'hàng':45B,55B 'kỹ':56B 'liên':24B 'lòng':69B 'lý':66B 'lạc':25B 'lập':49B 'mạnh':5A 'một':11B,19B,42B 'ngay':48B 'ngài':40B 'pháp':53B 'phương':52B 'phụ':2A 'qua':18B 'quả':14B 'ra':30B 'siêu':34B 'sẽ':7B,28B 'số':58B 'sức':4A 'thuận':21B 'thuật':57B 'thông':17B 'thẻ':63B 'thể':47B 'thỏa':20B 'tiếp':10B 'tiết':73B 'trong':37B 'trên':22B 'tuần':43B 'tôi':16B,27B 'tạo':29B 'tức':50B 'usb':64B 'vui':68B 'và':26B 'vài':39B 'vòng':38B 'vận':74B 'vật':65B 'với':15B,51B 'xin':67B 'âm':33B,35B 'đoạn':31B 'đường':23B 'đến':41B 'để':60B
73c5d065-561e-4cae-86df-7162ba8fca81	64193ab0-3546-4c83-9a2d-06651461ba80	tr	1x Güç Özel Bilinçaltı	Hedeflerinizi iletişim rotasında kabul edilen bir şekilde benimle etkin bir şekilde iletişim kurmanız gerekecek. Ve 1x güç subliminal ses kaydınızı haftada birkaç gün içinde yaratacağım. Teslimat dijital teslimat yöntemiyle veya fiziksel USB çubuğu teslimat için anında olabilir, lütfen nakliye ayrıntıları sağlayın.	auto	2026-04-24 03:46:38.270866+00	2026-04-24 03:46:38.270866+00	'1x':1A,20B 'anında':40B 'ayrıntıları':44B 'beniml':12B 'bilinçaltı':4A 'bir':10B,14B 'birkaç':26B 'dijit':31B 'edilen':9B 'etkin':13B 'fiziksel':35B 'gerekecek':18B 'gün':27B 'güç':2A,21B 'haftada':25B 'hedeflerinizi':5B 'iletişim':6B,16B 'için':39B 'içind':28B 'kabul':8B 'kaydınızı':24B 'kurmanız':17B 'lütfen':42B 'nakliy':43B 'olabilir':41B 'rotasında':7B 'sağlayın':45B 'ses':23B 'sublimin':22B 'teslimat':30B,32B,38B 'usb':36B 've':19B 'veya':34B 'yaratacağım':29B 'yöntemiyl':33B 'çubuğu':37B 'özel':3A 'şekild':11B,15B
cbb31221-3c64-4d5f-af62-c9385ab23ebc	64193ab0-3546-4c83-9a2d-06651461ba80	ar	1x سبليمنال مخصص للقوة	سوف تحتاج إلى إبلاغ أهدافك لي بشكل فعال عن طريق الاتصال المتفق عليه. وسأقوم بصنع تسجيل صوتك الـ1x خلال بضعة أيام إلى أسبوع ويمكن أن يكون التبليغ فورياً باستخدام طريقة توصيل رقمية أو من أجل تسليم العصي الفيزيائية، يرجى تقديم تفاصيل الشحن.	auto	2026-04-24 03:46:40.428323+00	2026-04-24 03:46:40.428323+00	'1x':1A 'أجل':39B 'أسبوع':27B 'أن':29B 'أهدافك':9B 'أو':37B 'أيام':25B 'إبلاغ':8B 'إلى':7B,26B 'الاتصال':15B 'التبليغ':31B 'الشحن':46B 'العصي':41B 'الـ1x':22B 'الفيزيائية':42B 'المتفق':16B 'باستخدام':33B 'بشكل':11B 'بصنع':19B 'بضعة':24B 'تحتاج':6B 'تسجيل':20B 'تسليم':40B 'تفاصيل':45B 'تقديم':44B 'توصيل':35B 'خلال':23B 'رقمية':36B 'سبليمنال':2A 'سوف':5B 'صوتك':21B 'طريق':14B 'طريقة':34B 'عليه':17B 'عن':13B 'فعال':12B 'فورياً':32B 'للقوة':4A 'لي':10B 'مخصص':3A 'من':38B 'وسأقوم':18B 'ويمكن':28B 'يرجى':43B 'يكون':30B
4fbae8ec-cd24-444d-b34b-fd6fd658232e	64193ab0-3546-4c83-9a2d-06651461ba80	fa	1x استحکام سابلیمینال سفارشی	شما باید اهداف خود را به طور موثر برای من از طریق یک توافق شده در مسیر ارتباطی برقرار کنید. و من ضبط صوتی 1x را در عرض چند روز تا یک هفته ایجاد خواهم کرد. تحویل می تواند با یک روش تحویل دیجیتال یا برای تحویل چوب USB فیزیکی فوری باشد، لطفا جزئیات حمل و نقل را ارائه دهید.	auto	2026-04-24 03:46:42.804958+00	2026-04-24 03:46:42.804958+00	'1x':1A,29B 'usb':53B 'ارائه':63B 'ارتباطی':22B 'از':15B 'استحکام':2A 'اهداف':7B 'ایجاد':38B 'با':44B 'باشد':56B 'باید':6B 'برای':13B,50B 'برقرار':23B 'به':10B 'تا':35B 'تحویل':41B,47B,51B 'توافق':18B 'تواند':43B 'جزئیات':58B 'حمل':59B 'خواهم':39B 'خود':8B 'در':20B,31B 'دهید':64B 'دیجیتال':48B 'را':9B,30B,62B 'روز':34B 'روش':46B 'سابلیمینال':3A 'سفارشی':4A 'شده':19B 'شما':5B 'صوتی':28B 'ضبط':27B 'طریق':16B 'طور':11B 'عرض':32B 'فوری':55B 'فیزیکی':54B 'لطفا':57B 'مسیر':21B 'من':14B,26B 'موثر':12B 'می':42B 'نقل':61B 'هفته':37B 'و':25B,60B 'چند':33B 'چوب':52B 'کرد':40B 'کنید':24B 'یا':49B 'یک':17B,36B,45B
80c22890-e3f3-4c80-a1fb-14490166ad56	64193ab0-3546-4c83-9a2d-06651461ba80	ur	۱ وزنی تناؤ	آپ کو اپنے نشانوں سے بات کرنے کی ضرورت ہے ۔ اور میں آپ کی 1x مضبوط آڈیو ریکارڈنگ ایک ہفتے میں ایک ہفتے تک بنائے گا. بچت کو ڈیجیٹل ادائیگی کے طریقے کے ساتھ فوری طور پر کیا جا سکتا ہے یا جسمانی USB مستقل ادائیگی کے لیے، براہ راست تفصیلات فراہم کر سکتا ہے۔.	auto	2026-04-24 03:46:44.478683+00	2026-04-24 03:46:44.478683+00	'1x':18B 'usb':47B 'آپ':4B,16B 'آڈیو':20B 'ادائیگی':33B,49B 'اور':14B 'اپنے':6B 'ایک':22B,25B 'بات':9B 'براہ':52B 'بنائے':28B 'بچت':30B 'تفصیلات':54B 'تناؤ':3A 'تک':27B 'جا':42B 'جسمانی':46B 'راست':53B 'ریکارڈنگ':21B 'ساتھ':37B 'سکتا':43B,57B 'سے':8B 'ضرورت':12B 'طریقے':35B 'طور':39B 'فراہم':55B 'فوری':38B 'لیے':51B 'مستقل':48B 'مضبوط':19B 'میں':15B,24B 'نشانوں':7B 'وزنی':2A 'پر':40B 'ڈیجیٹل':32B 'کر':56B 'کرنے':10B 'کو':5B,31B 'کی':11B,17B 'کیا':41B 'کے':34B,36B,50B 'گا':29B 'ہفتے':23B,26B 'ہے':13B,44B,58B 'یا':45B '۱':1A
990904a5-cd7c-44d4-81ac-dbc46b2f2ad6	64193ab0-3546-4c83-9a2d-06651461ba80	hi	1x शक्ति कस्टम अचेतन	आपको अपने लक्ष्यों को प्रभावी ढंग से संवाद करने की आवश्यकता होगी। और मैं कुछ दिनों के भीतर कुछ दिनों के भीतर अपने 1x शक्ति सब्लिमाइनल ऑडियो रिकॉर्डिंग बनाऊंगा। डिलीवरी डिजिटल डिलीवरी विधि के साथ या भौतिक यूएसबी स्टिक डिलीवरी के लिए तत्काल हो सकती है, कृपया शिपिंग विवरण प्रदान करें।.	auto	2026-04-24 03:46:46.646371+00	2026-04-24 03:46:46.646371+00	'1x':1A,28B 'अचेतन':4A 'अपने':6B,27B 'आपको':5B 'आवश्यकता':15B 'ऑडियो':31B 'और':17B 'करने':13B 'करें':55B 'कस्टम':3A 'की':14B 'कुछ':19B,23B 'कृपया':51B 'के':21B,25B,38B,45B 'को':8B 'डिजिटल':35B 'डिलीवरी':34B,36B,44B 'ढंग':10B 'तत्काल':47B 'दिनों':20B,24B 'प्रदान':54B 'प्रभावी':9B 'बनाऊंगा':33B 'भीतर':22B,26B 'भौतिक':41B 'मैं':18B 'या':40B 'यूएसबी':42B 'रिकॉर्डिंग':32B 'लक्ष्यों':7B 'लिए':46B 'विधि':37B 'विवरण':53B 'शक्ति':2A,29B 'शिपिंग':52B 'संवाद':12B 'सकती':49B 'सब्लिमाइनल':30B 'साथ':39B 'से':11B 'स्टिक':43B 'है':50B 'हो':48B 'होगी':16B
270807ff-461e-4ecd-9280-5382371ffe14	64193ab0-3546-4c83-9a2d-06651461ba80	pt	1x Força Subliminares Personalizados	Você precisará comunicar seus objetivos efetivamente para mim através de uma rota de comunicação acordada. E vou criar a tua gravação subliminar de áudio de 1x de força dentro de alguns dias a uma semana. A entrega pode ser instantânea com um método de entrega digital ou para a entrega física do stick USB, por favor forneça detalhes do transporte.	auto	2026-04-24 03:46:47.076861+00	2026-04-24 03:46:47.076861+00	'1x':1A,30B 'acordada':19B 'algun':35B 'atravé':13B 'com':45B 'comunicar':7B 'comunicação':18B 'criar':22B 'de':14B,17B,27B,29B,31B,34B,48B 'dentro':33B 'detalh':62B 'dia':36B 'digit':50B 'e':20B 'efetivament':10B 'entrega':41B,49B,54B 'favor':60B 'forneça':61B 'força':2A,32B 'física':55B 'gravação':25B 'instantânea':44B 'mim':12B 'método':47B 'objetivo':9B 'ou':51B 'para':11B,52B 'personalizado':4A 'pode':42B 'por':59B 'precisará':6B 'rota':16B 'semana':39B 'ser':43B 'seus':8B 'stick':57B 'subliminar':3A,26B 'transport':64B 'tua':24B 'um':46B 'uma':15B,38B 'usb':58B 'você':5B 'vou':21B 'áudio':28B
47c263ae-3524-49fe-acdb-146c9be6aa0b	64193ab0-3546-4c83-9a2d-06651461ba80	ru	1x Силовые пользовательские сублиминалы	Вам нужно будет эффективно сообщать мне свои цели по согласованному маршруту связи. И я создам вашу подсознательную аудиозапись в 1 раз в неделю. Доставка может быть мгновенной с помощью цифрового метода доставки или для физической доставки USB-накопителя, пожалуйста, предоставьте подробную информацию о доставке.	auto	2026-04-24 03:46:47.086189+00	2026-04-24 03:46:47.086189+00	'1':24B '1x':1A 'usb':42B 'usb-накопителя':41B 'аудиозапись':22B 'будет':7B 'быть':30B 'в':23B,26B 'вам':5B 'вашу':20B 'для':38B 'доставка':28B 'доставке':49B 'доставки':36B,40B 'и':17B 'или':37B 'информацию':47B 'маршруту':15B 'мгновенной':31B 'метода':35B 'мне':10B 'может':29B 'накопителя':43B 'неделю':27B 'нужно':6B 'о':48B 'по':13B 'подробную':46B 'подсознательную':21B 'пожалуйста':44B 'пользовательские':3A 'помощью':33B 'предоставьте':45B 'раз':25B 'с':32B 'свои':11B 'связи':16B 'силовые':2A 'согласованному':14B 'создам':19B 'сообщать':9B 'сублиминалы':4A 'физической':39B 'цели':12B 'цифрового':34B 'эффективно':8B 'я':18B
17aee26b-8989-42f0-a607-3b00b6a15546	64193ab0-3546-4c83-9a2d-06651461ba80	sv	1x styrka anpassade subliminaler	Du måste kommunicera dina mål effektivt till mig via en överenskommen kommunikationsväg. Och jag kommer att skapa din 1x styrka subliminal ljudinspelning inom några dagar till en vecka. Leverans kan vara omedelbar med en digital leveransmetod eller för fysisk USB-minnesleverans, vänligen ange fraktinformation.	auto	2026-04-24 03:46:48.631428+00	2026-04-24 03:46:48.631428+00	'1x':1A,23B 'ang':48B 'anpassad':3A 'att':20B 'dagar':29B 'digit':39B 'din':22B 'dina':8B 'du':5B 'effektivt':10B 'eller':41B 'en':14B,31B,38B 'fraktinform':49B 'fysisk':43B 'för':42B 'inom':27B 'jag':18B 'kan':34B 'kommer':19B 'kommunicera':7B 'kommunikationsväg':16B 'leveran':33B 'leveransmetod':40B 'ljudinspeln':26B 'med':37B 'mig':12B 'minnesleveran':46B 'mål':9B 'måste':6B 'några':28B 'och':17B 'omedelbar':36B 'skapa':21B 'styrka':2A,24B 'sublimin':25B 'subliminal':4A 'till':11B,30B 'usb':45B 'usb-minnesleveran':44B 'vara':35B 'vecka':32B 'via':13B 'vänligen':47B 'överenskommen':15B
dcbe7f9d-81a8-4069-a1d1-4e8ac583739e	64193ab0-3546-4c83-9a2d-06651461ba80	tl	1x Mga Subliminal ng Lakas	Kakailanganin mong ipakipag - usap sa akin nang mabisa ang iyong mga tunguhin sa pamamagitan ng isang napagkasunduang ruta sa komunikasyon. At lilikhain ko ang iyong 1x na lakas na subliminal audio recording sa loob ng ilang araw sa isang linggo. Ang paghahatid ay maaaring instant sa pamamagitan ng isang digital na paraan ng paghahatid o para sa pisikal na USB stick delivery, pakisuyong magbigay ng mga detalye sa shipping.	auto	2026-04-24 03:46:50.891179+00	2026-04-24 03:46:50.891179+00	'1x':1A,31B 'akin':11B 'ang':14B,29B,46B 'araw':42B 'audio':36B 'ay':48B 'deliveri':67B 'detaly':72B 'digit':55B 'ilang':41B 'instant':50B 'ipakipag':8B 'isang':21B,44B,54B 'iyong':15B,30B 'kakailanganin':6B 'ko':28B 'komunikasyon':25B 'laka':5A,33B 'lilikhain':27B 'linggo':45B 'loob':39B 'maaar':49B 'mabisa':13B 'magbigay':69B 'mga':2A,16B,71B 'mong':7B 'na':32B,34B,56B,64B 'nang':12B 'napagkasunduang':22B 'ng':4A,20B,40B,53B,58B,70B 'o':60B 'paghahatid':47B,59B 'pakisuyong':68B 'pamamagitan':19B,52B 'para':61B 'paraan':57B 'pisik':63B 'record':37B 'ruta':23B 'sa':10B,18B,24B,38B,43B,51B,62B,73B 'ship':74B 'stick':66B 'sublimin':3A,35B 'tunguhin':17B 'usap':9B 'usb':65B
\.


--
-- Data for Name: listing_views; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.listing_views (id, listing_id, viewer_id, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: listings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.listings (id, seller_id, store_id, type, title, description, category, price_cents, starting_price_cents, reserve_price_cents, buy_it_now_price_cents, current_bid_cents, bid_increment_cents, reverse_target_specs, quantity_available, quantity_sold, images, video_url, location_city, location_state, location_country, latitude, longitude, is_local_pickup, shipping_options, inventory_tracking, status, approved_by, approved_at, auction_end_time, created_at, updated_at, duration, expires_at, min_bid_cents, max_bid_cents, bid_increment_percent, current_bidder_id, bid_count, shipping_provider, shipping_tracking, weight_oz, dimensions, deleted_at, deletion_reason, is_dutch_auction, dutch_clearing_price_cents, allow_local_pickup, pickup_address, pickup_city, pickup_state, pickup_zip, pickup_instructions, pickup_country, poster_role, item_condition, is_featured) FROM stdin;
64193ab0-3546-4c83-9a2d-06651461ba80	dfb80e70-2782-4e00-a328-384d8806897f	af9ace4f-e0a6-4ea1-a596-2a3069dab55c	mall	1x Strength Custom Subliminals	You will need to communicate your goals effectively to me via an agreed upon communication route. And I will create your 1x strength subliminal audio recording within a few days to a week. Delivery can be instant with a digital delivery method or for physical USB stick delivery, please provide shipping details.	subliminals	14900	\N	\N	\N	\N	100	\N	10000000	0	{/uploads/listings/listing-1776200686391-241859528.jpg}	\N			Worldwide	\N	\N	f	[]	\N	active	dfb80e70-2782-4e00-a328-384d8806897f	2026-04-14 21:06:37.948999	\N	2026-04-14 21:04:46.636782	2026-04-14 21:04:46.636782	2weeks	\N	\N	\N	10	\N	0	\N	\N	\N	{"width": "", "height": "", "length": ""}	\N	\N	f	\N	f	\N	\N	\N	\N	\N	CA	seller	new	f
c1d049d3-cb99-4478-a99c-bdf1c8882100	dfb80e70-2782-4e00-a328-384d8806897f	af9ace4f-e0a6-4ea1-a596-2a3069dab55c	mall	10 Googol x Strength Custom Subliminal	You will need to clearly communicate your goals to me via an agreed upon communication route. After that I will create the base audio files and then the 1x subliminal audio file, and finally the 10 googol x subliminal audio file within up to 7 days. Delivery will be instant through digital online media delivery, or if you require it shipped to your door, provide complete shipping details.	subliminals	49500	\N	\N	\N	\N	100	\N	10000000	0	{/uploads/listings/listing-1776221775192-97567584.jpg}	\N			Worldwide	\N	\N	f	[]	\N	active	dfb80e70-2782-4e00-a328-384d8806897f	2026-04-15 02:57:04.587416	\N	2026-04-15 02:56:15.3119	2026-04-15 02:56:15.3119	2weeks	\N	\N	\N	10	\N	0	\N	\N	\N	{"width": "", "height": "", "length": ""}	\N	\N	f	\N	f	\N	\N	\N	\N	\N	CA	seller	new	f
10fbf492-a8a5-40c9-8143-f6e944161c0c	dfb80e70-2782-4e00-a328-384d8806897f	af9ace4f-e0a6-4ea1-a596-2a3069dab55c	mall	10 Googol Raised to The Power of 10 x Strength Subliminal	You will need to clearly communicate your goals to me via an agreed upon communication route. I will first create the raw audio files, then 1x strength subliminal audio file, and finally within 7 days from finalizing your purchase we will have the 10 googol raised to the power of 10 x strength audio subliminal file. Digital online delivery method is instant, but shipping to your front door is available too (on a USB stick). Please indicate your shipping preferrence during the checkout process.	subliminals	99500	\N	\N	\N	\N	100	\N	10000000	0	{/uploads/listings/listing-1776222692624-266069580.jpg}	\N			Worldwide	\N	\N	f	[]	\N	active	dfb80e70-2782-4e00-a328-384d8806897f	2026-04-15 03:12:48.771465	\N	2026-04-15 03:11:32.739945	2026-04-15 03:11:32.739945	2weeks	\N	\N	\N	10	\N	0	\N	\N	\N	{"width": "", "height": "", "length": ""}	\N	\N	f	\N	f	\N	\N	\N	\N	\N	CA	seller	new	f
10b75adb-1bc1-4547-bc43-19a27763e6bc	dfb80e70-2782-4e00-a328-384d8806897f	\N	classifieds	Let's have fun!	Hi.	virtual_relationship_1	0	\N	\N	\N	\N	100	\N	1	0	{}	\N	Toronto	ON	Canada	43.65320000	-79.38320000	f	[]	\N	deleted	dfb80e70-2782-4e00-a328-384d8806897f	2026-04-14 06:51:48.74676	2027-04-14 06:50:47.22	2026-04-14 06:50:47.228386	2026-04-14 06:50:47.228386	2weeks	2027-04-14 06:50:47.22	\N	\N	10	\N	0	\N	\N	152	{"width": "1", "height": "65.5", "length": "5"}	2026-04-14 07:29:44.578111	\N	f	\N	f	\N	\N	\N	\N	\N	CA	seller	new	f
d18ffb55-7c93-4007-a60d-a449edd396c3	dfb80e70-2782-4e00-a328-384d8806897f	af9ace4f-e0a6-4ea1-a596-2a3069dab55c	auction	5 Bags of Nuts for Sale	5 bags of nuts for sale through auction, for local pickup > Downtown Toronto, Ontario, Canada.	dried_nuts	0	\N	\N	\N	100	100	\N	5	0	{}	\N	Toronto	ON	Canada	43.65320000	-79.38320000	f	[]	\N	expired	dfb80e70-2782-4e00-a328-384d8806897f	2026-04-15 07:16:51.509056	2026-04-16 07:15:52.051	2026-04-15 07:15:52.059806	2026-04-15 07:15:52.059806	2weeks	2026-04-16 07:15:52.051	100	\N	10	dfb80e70-2782-4e00-a328-384d8806897f	1	\N	\N	\N	{"width": "", "height": "", "length": ""}	\N	\N	f	\N	f	\N	\N	\N	\N	\N	CA	seller	new	f
cda0ab23-2668-4902-9618-676b8fdb96c1	dfb80e70-2782-4e00-a328-384d8806897f	\N	auction	A Bag of Nuts for Sale	A bag of nuts for sale through Auction.	dried_nuts	0	\N	\N	\N	100	100	\N	1	0	{}	\N	Toronto	ON	Local Pickup Only - Canada	43.65320000	-79.38320000	f	[]	\N	expired	dfb80e70-2782-4e00-a328-384d8806897f	2026-04-15 05:58:04.873994	2026-04-29 05:56:29.443	2026-04-15 05:56:29.450987	2026-04-15 05:56:29.450987	2weeks	2026-04-29 05:56:29.443	100	\N	10	dfb80e70-2782-4e00-a328-384d8806897f	1	\N	\N	\N	{"width": "", "height": "", "length": ""}	\N	\N	f	\N	f	\N	\N	\N	\N	\N	CA	seller	new	f
702df270-98b1-48d9-9994-9a5abe05ff8f	dfb80e70-2782-4e00-a328-384d8806897f	af9ace4f-e0a6-4ea1-a596-2a3069dab55c	mall	Enjoy A Coffee with Bruno!	24/7 - Call ahead or just knock on my door any time:\n138 Claremont Street Unit 104\nToronto, Ontario M6J 2M8 Canada\nTel: +1-647-228-1215	cafes	200	\N	\N	\N	\N	100	\N	9999999	1	{/uploads/listings/listing-1776263180289-533834713.jpg}	\N	Toronto	ON	CA	43.65320000	-79.38320000	f	[]	\N	active	dfb80e70-2782-4e00-a328-384d8806897f	2026-04-15 14:29:41.789525	\N	2026-04-15 14:26:20.521459	2026-04-15 14:26:20.521459	2weeks	\N	\N	\N	10	\N	0	\N	\N	\N	{"width": "", "height": "", "length": ""}	\N	\N	f	\N	t	138 Claremont Street Unit #104	Toronto	ON	M6J 2M8	Call ahead (+1-647-228-1215), or just show up and call then to let you in.	CA	seller	new	f
44dfff4e-8151-4541-b235-2ce931af2b3f	dfb80e70-2782-4e00-a328-384d8806897f	af9ace4f-e0a6-4ea1-a596-2a3069dab55c	mall	Single 30-Minute English Lesson (For Children)	Single lesson will be ideal to test things. You will book your lesson via Google Calendar and we will meet for the lesson through Google Meet.	english_lessons	1500	\N	\N	\N	\N	100	\N	10000000	0	{/uploads/listings/listing-1776272424601-585287896.jpg}	\N	Toronto	ON	CA	43.65348170	-79.38393470	f	[]	\N	active	dfb80e70-2782-4e00-a328-384d8806897f	2026-04-15 17:19:20.042012	\N	2026-04-15 17:00:25.299672	2026-04-15 17:00:25.299672	2weeks	\N	\N	\N	10	\N	0	\N	\N	\N	{"width": "", "height": "", "length": ""}	\N	\N	f	\N	t						CA	seller	new	f
c93b6c4e-3f44-476b-b649-523b1262b392	dfb80e70-2782-4e00-a328-384d8806897f	af9ace4f-e0a6-4ea1-a596-2a3069dab55c	mall	10-Lesson Block of English Instruction for Children	Each lesson is 30 minutes. You book your lessons via Google Calendar and we meet for the lessons through Google Meet.	english_lessons	12000	\N	\N	\N	\N	100	\N	10000000	0	{/uploads/listings/listing-1776272859612-840101662.jpg}	\N	Toronto	ON	CA	43.65348170	-79.38393470	f	[]	\N	active	dfb80e70-2782-4e00-a328-384d8806897f	2026-04-15 17:19:21.708573	\N	2026-04-15 17:07:39.73822	2026-04-15 17:07:39.73822	2weeks	\N	\N	\N	10	\N	0	\N	\N	\N	{"width": "", "height": "", "length": ""}	\N	\N	f	\N	t						CA	seller	new	f
18dc44ca-8169-4e32-b607-2e4854fe1b40	dfb80e70-2782-4e00-a328-384d8806897f	af9ace4f-e0a6-4ea1-a596-2a3069dab55c	mall	Single 1-Hour English Lesson (For Adults)	Single lesson is ideal for testing things. You book your lessons via Google Calendar and we meet for the lesson through Google Meet.	english_lessons	2500	\N	\N	\N	\N	100	\N	10000000	0	{/uploads/listings/listing-1776273241779-141150333.jpg}	\N	Toronto	ON	CA	43.65348170	-79.38393470	f	[]	\N	active	dfb80e70-2782-4e00-a328-384d8806897f	2026-04-15 17:19:26.534065	\N	2026-04-15 17:14:01.911413	2026-04-15 17:14:01.911413	2weeks	\N	\N	\N	10	\N	0	\N	\N	\N	{"width": "", "height": "", "length": ""}	\N	\N	f	\N	t						CA	seller	new	f
d19b67d5-943e-4c96-80f8-895d2a23c58a	dfb80e70-2782-4e00-a328-384d8806897f	af9ace4f-e0a6-4ea1-a596-2a3069dab55c	mall	10-Lesson Block of 1-Hour English Lessons (For Adults)	Ultimate value for your money! Book your lessons through Google Calendar and we will meet for the lessons via Google Meet.	english_lessons	20000	\N	\N	\N	\N	100	\N	10000000	0	{/uploads/listings/listing-1776273514310-474852360.jpg}	\N	Toronto	ON	CA	43.65348170	-79.38393470	f	[]	\N	active	dfb80e70-2782-4e00-a328-384d8806897f	2026-04-15 17:19:27.541436	\N	2026-04-15 17:18:34.412792	2026-04-15 17:18:34.412792	2weeks	\N	\N	\N	10	\N	0	\N	\N	\N	{"width": "", "height": "", "length": ""}	\N	\N	f	\N	t						CA	seller	new	f
cbee725d-f42a-4581-962e-63bc22787f1a	dfb80e70-2782-4e00-a328-384d8806897f	\N	classifieds	Test Free Item Classified Posting	N/A.	english_lessons	0	\N	\N	\N	\N	100	\N	98	2	{}	\N	Toronto	ON	CA	43.65348170	-79.38393470	f	[]	\N	active	dfb80e70-2782-4e00-a328-384d8806897f	2026-04-19 02:52:00.499632	2027-04-19 02:50:53.098	2026-04-19 02:50:53.106634	2026-04-19 02:50:53.106634	2weeks	2027-04-19 02:50:53.098	\N	\N	10	\N	0	\N	\N	\N	{"width": "", "height": "", "length": ""}	\N	\N	f	\N	t						CA	seller	new	f
\.


--
-- Data for Name: login_verification_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.login_verification_codes (id, user_id, code, session_id, expires_at, verified, created_at) FROM stdin;
030c8835-e4ea-422b-a201-f1008e972ba7	dfb80e70-2782-4e00-a328-384d8806897f	640360	292258ca-f241-48d5-a87a-3712475e6245	2026-04-10 11:36:25.761	t	2026-04-10 11:26:25.762302
fd966b6a-0db5-4320-90f6-64153c19c9c8	dfb80e70-2782-4e00-a328-384d8806897f	198369	0501f8c9-1b68-4bc1-afe4-e2e06604befe	2026-04-10 12:55:25.874	t	2026-04-10 12:45:25.875147
11249187-0c1f-41ac-b6a9-1be9ca2beb18	dfb80e70-2782-4e00-a328-384d8806897f	526576	2ca5744b-6b3a-4fd4-b60f-629057851919	2026-04-10 16:36:19.167	t	2026-04-10 16:26:19.167295
c9ba3ca2-2ad9-4492-a31e-6fe3799296e6	e8ce3170-c7c9-48d3-8ba2-529a2dcf2d7d	564314	ffbd8e6a-4757-476a-8e9f-33e25f4e2205	2026-04-15 13:18:42.648	t	2026-04-15 13:08:42.648304
700359e5-3411-48c4-9e25-4d1ea6037640	dfb80e70-2782-4e00-a328-384d8806897f	322745	ebda4566-e51c-4f6a-8d10-4c74370fbb4a	2026-04-20 07:05:45.561	t	2026-04-20 06:55:45.56227
a0243472-a0a0-427f-9f9e-3d9335d15661	e8ce3170-c7c9-48d3-8ba2-529a2dcf2d7d	602212	2ae49b36-92df-4f3e-950f-621ae4980dee	2026-04-20 07:07:06.634	t	2026-04-20 06:57:06.634384
d9410ec6-04a9-4d90-8e41-26a3bc5a64db	2fabcd4d-044e-47a5-a4f5-78a71ae50490	640661	50a74b4e-1e40-4f72-ba93-392a485f151c	2026-04-26 09:27:22.688538	t	2026-04-26 09:17:22.688538
1c47c55d-7661-42c2-afb2-d3196e1d2039	dfb80e70-2782-4e00-a328-384d8806897f	378173	83c713b6-7e1a-4200-8996-2c947be632d5	2026-04-26 10:28:06.979612	t	2026-04-26 10:18:06.979612
e0fb933f-53b8-4d65-a344-f1cad1930e2b	e27eff2f-1fd9-498a-a3b6-10ea3f3c2424	629775	186ef065-8a1e-486c-9a39-839432ee5b09	2026-04-26 11:34:25.712944	t	2026-04-26 11:24:25.712944
a2ddda4c-068c-4146-aee7-9902f20d488c	dfb80e70-2782-4e00-a328-384d8806897f	421608	1ebdc302-2dab-4751-94af-f0bd8a1a692d	2026-04-28 07:29:15.699444	t	2026-04-28 07:19:15.699444
\.


--
-- Data for Name: market_trends; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.market_trends (id, category, date, avg_price_cents, median_price_cents, sales_volume, demand_score, supply_score, trending_keywords, created_at) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messages (id, sender_id, receiver_id, listing_id, message, is_read, created_at) FROM stdin;
\.


--
-- Data for Name: minting_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.minting_logs (id, admin_id, action, amount_cents, reason, is_automatic, created_at) FROM stdin;
\.


--
-- Data for Name: offers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.offers (id, listing_id, buyer_id, offer_cents, message, status, seller_response, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orders (id, user_id, type, amount_usd, status, paypal_order_id, shipping_address, shipping_tracking_number, shipping_carrier, notes, created_at, updated_at, listing_id, listing_type, seller_id, escrow_status, escrow_release_date, escrow_id) FROM stdin;
\.


--
-- Data for Name: platform_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.platform_settings (id, setting_key, setting_value, updated_by, created_at, updated_at) FROM stdin;
96efecfb-bec6-4b89-8047-2bca2a151a4c	credon_enabled	{"value": false}	\N	2026-04-13 15:53:33.461577	2026-04-13 15:53:33.461577
c2c67053-798f-4c88-894e-7779e81e21b6	listing_approval_required	{"value": true}	\N	2026-04-13 15:53:33.461577	2026-04-13 15:53:33.461577
be35ce3a-0f66-417b-b6bb-1d6327a105d3	max_listings_per_user	{"value": 100}	\N	2026-04-13 15:53:33.461577	2026-04-13 15:53:33.461577
f3dad775-fc67-44c4-95f3-b0c1029190bd	platform_fee_percent	{"value": 17}	dfb80e70-2782-4e00-a328-384d8806897f	2026-04-13 15:53:33.461577	2026-04-22 12:54:56.724483
\.


--
-- Data for Name: price_predictions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.price_predictions (id, category, predicted_price_cents, confidence_score, best_time_to_sell, expected_demand, created_at) FROM stdin;
\.


--
-- Data for Name: procurement_matches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.procurement_matches (id, procurement_id, matching_listing_id, match_score, match_reason, notified_buyer, notified_seller, status, created_at) FROM stdin;
\.


--
-- Data for Name: promotion_usage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.promotion_usage (id, promotion_id, user_id, purchase_id, discount_cents, created_at) FROM stdin;
\.


--
-- Data for Name: promotions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.promotions (id, seller_id, listing_id, store_id, promotion_type, code, description, value_percent, applies_to, category, min_purchase_cents, max_discount_cents, usage_limit, used_count, starts_at, expires_at, is_active, created_at, updated_at) FROM stdin;
35f857eb-141d-4285-9caf-07f6b0ed993e	dfb80e70-2782-4e00-a328-384d8806897f	10fbf492-a8a5-40c9-8143-f6e944161c0c	\N	discount	SS-2026	Spring Special	10	\N	\N	50000	9950	\N	0	2026-04-20 08:59:01.802479	2026-05-20 08:59:01.533	t	2026-04-20 08:59:01.802479	2026-04-20 08:59:01.802479
\.


--
-- Data for Name: purchases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchases (id, buyer_id, listing_id, seller_id, amount_cents, shipping_address, paypal_transaction_id, status, tracking_number, tracking_carrier, estimated_delivery, created_at, updated_at, shipping_carrier, shipping_service, shipping_cost_cents, estimated_delivery_days, delivery_method, pickup_deadline, platform_fee_cents, seller_payout_cents, paypal_order_id, paypal_capture_id, escrow_status, buyer_role, seller_role) FROM stdin;
440ace6d-97ad-4982-82ca-905bd2fc1b6f	e8ce3170-c7c9-48d3-8ba2-529a2dcf2d7d	702df270-98b1-48d9-9994-9a5abe05ff8f	dfb80e70-2782-4e00-a328-384d8806897f	200	\N	\N	paid	\N	\N	\N	2026-04-15 14:50:23.697214	2026-04-15 14:50:23.697214	\N	\N	0	\N	pickup	\N	10	190	\N	\N	pending	buyer	seller
c606fb93-6ffe-4c46-a824-20bd4ad03c63	dfb80e70-2782-4e00-a328-384d8806897f	cbee725d-f42a-4581-962e-63bc22787f1a	dfb80e70-2782-4e00-a328-384d8806897f	0	\N	\N	paid	\N	\N	\N	2026-04-19 02:54:02.675885	2026-04-19 02:54:02.675885	\N	\N	0	\N	pickup	\N	0	0	\N	\N	pending	buyer	seller
7046ca2c-332b-4abc-8fcf-add3c7f616be	e8ce3170-c7c9-48d3-8ba2-529a2dcf2d7d	cbee725d-f42a-4581-962e-63bc22787f1a	dfb80e70-2782-4e00-a328-384d8806897f	0	\N	\N	paid	\N	\N	\N	2026-04-19 03:31:55.048673	2026-04-19 03:31:55.048673	\N	\N	0	\N	pickup	\N	0	0	\N	\N	pending	buyer	seller
\.


--
-- Data for Name: ratings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ratings (id, order_id, transaction_type, reviewer_id, reviewee_id, listing_id, rating, feedback, response_text, would_recommend, item_as_described, communication, shipping_speed, release_escrow, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sales_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_history (id, listing_id, listing_title, listing_type, buyer_id, seller_id, amount_cents, platform_fee_cents, seller_payout_cents, paypal_transaction_id, shipping_address, tracking_number, completed_at, retained_until, created_at) FROM stdin;
6d680d8a-d34c-45a7-a763-e79de27f93bc	702df270-98b1-48d9-9994-9a5abe05ff8f	Enjoy A Coffee with Bruno!	mall	e8ce3170-c7c9-48d3-8ba2-529a2dcf2d7d	dfb80e70-2782-4e00-a328-384d8806897f	200	0	200	\N	\N	\N	2026-04-15 14:50:23.697214	2029-04-15 14:50:23.697214	2026-04-19 02:31:55.395931
3a53c41c-fa20-4646-9a3e-7fe486e1fa42	cbee725d-f42a-4581-962e-63bc22787f1a	Test Free Item Classified Posting	classifieds	dfb80e70-2782-4e00-a328-384d8806897f	dfb80e70-2782-4e00-a328-384d8806897f	0	0	0	\N	\N	\N	2026-04-19 02:54:02.675885	2029-04-19 02:54:02.675885	2026-04-19 02:54:02.675885
513543f2-e2f2-4ae4-846b-cb97743f7a5c	cbee725d-f42a-4581-962e-63bc22787f1a	Test Free Item Classified Posting	classifieds	e8ce3170-c7c9-48d3-8ba2-529a2dcf2d7d	dfb80e70-2782-4e00-a328-384d8806897f	0	0	0	\N	\N	\N	2026-04-19 03:31:55.048673	2029-04-19 03:31:55.048673	2026-04-19 03:31:55.048673
\.


--
-- Data for Name: saved_searches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.saved_searches (id, user_id, name, search_type, filters, notification_frequency, last_notified_at, is_active, created_at, updated_at) FROM stdin;
249111e3-b6e2-4252-8a23-60b4b63912b5	dfb80e70-2782-4e00-a328-384d8806897f	Casa Loma in Toronto for Sale	buying	{"type": "", "category": "real_estate", "keywords": "Castle, Mansion,", "maxPrice": "5000.00", "minPrice": "0.00"}	instant	\N	t	2026-04-22 06:40:07.268095	2026-04-22 06:40:07.268095
\.


--
-- Data for Name: search_matches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.search_matches (id, saved_search_id, listing_id, match_score, match_reason, notified_at, created_at) FROM stdin;
\.


--
-- Data for Name: seasonal_trends; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.seasonal_trends (id, category, month, demand_multiplier, price_multiplier, keywords) FROM stdin;
\.


--
-- Data for Name: seller_analytics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.seller_analytics (id, seller_id, date, listings_active, sales_count, revenue_cents, views, inquiries, conversion_rate, avg_response_time_minutes, created_at) FROM stdin;
\.


--
-- Data for Name: seller_ratings_summary; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.seller_ratings_summary (seller_id, average_rating, total_ratings, five_star, four_star, three_star, two_star, one_star, item_as_described_avg, communication_avg, shipping_speed_avg, would_recommend_percent, updated_at) FROM stdin;
\.


--
-- Data for Name: shop_admins; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop_admins (id, user_id, role, permissions, created_by, created_at, updated_at) FROM stdin;
3d07cd8a-530e-44a8-b482-2b6a01074605	dfb80e70-2782-4e00-a328-384d8806897f	admin	{"adjust_fees": true, "suspend_users": true, "view_analytics": true, "manage_disputes": true, "approve_listings": true}	dfb80e70-2782-4e00-a328-384d8806897f	2026-04-13 16:21:07.063219	2026-04-13 16:21:07.063219
\.


--
-- Data for Name: shop_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop_categories (id, category, display_name, parent_category, icon, display_order, is_active, created_at, updated_at, full_path, level, sort_order) FROM stdin;
7726929a-cb54-4c4c-b3d8-57ef414c2c2b	18___20_year_olds	18 - 20 Year-Olds	men_seeking_women	📱	0	t	2026-04-14 02:10:24.38351	2026-04-14 02:10:24.38351	personals/men_seeking_women/18___20_year_olds	3	0
747735a9-b23c-4dc7-b944-cce1c139f35a	other_8	Other	18___20_year_olds	📦	0	t	2026-04-14 02:11:57.310644	2026-04-14 02:11:57.310644	personals/men_seeking_women/18___20_year_olds/other_8	4	999
cc6a952b-24d4-4784-84c1-b6b1cce7b9fc	casual_dating	Casual Dating	18___20_year_olds	📱	0	t	2026-04-14 02:12:55.081079	2026-04-14 02:12:55.081079	personals/men_seeking_women/18___20_year_olds/casual_dating	4	0
f6404e03-ade9-4abb-b8ea-3983d0d2cc9e	long_term_relationship	Long-Term Relationship	18___20_year_olds	📱	0	t	2026-04-14 02:14:05.332047	2026-04-14 02:14:05.332047	personals/men_seeking_women/18___20_year_olds/long_term_relationship	4	0
f3f77106-e884-452d-b9a4-423bc9e81190	electronics	Electronics	\N	📱	10	t	2026-04-13 17:24:39.024563	2026-04-13 17:24:39.024563	electronics	1	0
d15585b3-eb24-4a76-93fb-c5895b45e284	fashion	Fashion	\N	👕	20	t	2026-04-13 17:24:39.024563	2026-04-13 17:24:39.024563	fashion	1	0
9e934225-7b82-46df-a897-6f306c772a66	home_garden	Home & Garden	\N	🏠	30	t	2026-04-13 17:24:39.024563	2026-04-13 17:24:39.024563	home_garden	1	0
56b96f39-acde-41c9-89bd-854be70bc851	collectibles	Collectibles	\N	🏆	40	t	2026-04-13 17:24:39.024563	2026-04-13 17:24:39.024563	collectibles	1	0
7b2d76a1-707f-4995-8e71-aa689894a760	vehicles	Vehicles	\N	🚗	50	t	2026-04-13 17:24:39.024563	2026-04-13 17:24:39.024563	vehicles	1	0
0e376e39-75fa-4279-aa45-3735a3eccc7b	services	Services	\N	🛠️	60	t	2026-04-13 17:24:39.024563	2026-04-13 17:24:39.024563	services	1	0
9d414c8b-9903-49fb-b058-60bad615aa84	real_estate	Real Estate	\N	📚	0	t	2026-04-13 20:32:15.760615	2026-04-13 20:32:15.760615	real_estate	1	0
efb10ec2-7134-4221-851e-c9a4b0e7697b	personals	Personals	\N	📱	0	t	2026-04-13 20:38:48.575418	2026-04-13 20:38:48.575418	personals	1	0
c7dbc904-2961-43a4-8d07-a07698086aea	virtual_relationship	Virtual Relationship	18___20_year_olds	📱	0	t	2026-04-14 02:15:18.038005	2026-04-14 02:15:18.038005	personals/men_seeking_women/18___20_year_olds/virtual_relationship	4	0
daca6df9-78aa-45aa-9d10-7f4917e97a64	apartments	Apartments	real_estate	📚	0	t	2026-04-13 21:01:48.084087	2026-04-13 21:01:48.084087	real_estate/apartments	2	0
9a5f83f4-1b2c-4f51-a872-257cd2bb551f	houses	Houses	real_estate	📚	0	t	2026-04-13 21:11:40.230781	2026-04-13 21:11:40.230781	real_estate/houses	2	0
4f05bb57-2d79-478c-a3ba-415d497eec14	mansions	Mansions	real_estate	📚	0	t	2026-04-13 21:11:55.182247	2026-04-13 21:11:55.182247	real_estate/mansions	2	0
252eb8f4-bfdb-4842-97bc-a98da38c0356	food_and_beverage	Food and Beverage	\N	🍔	0	t	2026-04-14 01:02:27.532844	2026-04-14 01:02:27.532844	food_and_beverage	1	0
be587c56-34f4-4472-a725-4f8f27b0dc7d	just_friends	Just Friends	18___20_year_olds	📱	0	t	2026-04-14 02:16:24.794589	2026-04-14 02:16:24.794589	personals/men_seeking_women/18___20_year_olds/just_friends	4	0
af11de99-10ee-4bdb-8bdf-b9f4b9ec6757	other	Other	collectibles	📦	100	t	2026-04-13 17:24:39.024563	2026-04-13 17:24:39.024563	collectibles/other	2	999
68c99b77-e783-4c49-8489-a60c3682f7c1	real_estate_other	Other	real_estate	📦	0	t	2026-04-13 22:14:45.270875	2026-04-13 22:14:45.270875	real_estate/real_estate_other	2	999
d3d20d1a-8179-4788-ad42-eee584ea4e30	food_and_beverage_other	Other	food_and_beverage	📦	0	t	2026-04-14 01:02:27.532844	2026-04-14 01:02:27.532844	food_and_beverage/other	2	999
4829db39-8f91-4bc3-9681-10b8438594bd	other_1	Other	\N	📦	0	t	2026-04-14 01:32:20.923567	2026-04-14 01:32:20.923567	other_1	1	999
b9ff0f94-8015-41fd-9ec9-82691f54a01c	other_1_other	Other	other_1	📦	0	t	2026-04-14 01:32:20.923567	2026-04-14 01:32:20.923567	other_1/other	2	0
251cf545-cb93-4abf-a93f-78e8f44c430c	other_2	Other	electronics	📦	0	t	2026-04-14 01:33:03.306209	2026-04-14 01:33:03.306209	electronics/other_2	2	999
9d30e5ba-39f0-46fe-9fec-2bbf088346ab	other_3	Other	fashion	📦	0	t	2026-04-14 01:33:26.310137	2026-04-14 01:33:26.310137	fashion/other_3	2	999
41a855e2-0a9a-463a-b6df-1220861f1668	other_4	Other	home_garden	📦	0	t	2026-04-14 01:34:23.238675	2026-04-14 01:34:23.238675	home_garden/other_4	2	999
f31d630f-e770-4142-9bb0-983bc839e943	other_5	Other	personals	📦	0	t	2026-04-14 01:34:52.332771	2026-04-14 01:34:52.332771	personals/other_5	2	999
38b33d9f-554f-4c2a-a9e1-1209d0e9ffe4	other_6	Other	services	📦	0	t	2026-04-14 01:35:27.330086	2026-04-14 01:35:27.330086	services/other_6	2	999
c3ecb41a-4d54-438a-bd73-34e8471c1ac9	marriage	Marriage	18___20_year_olds	📱	0	t	2026-04-14 02:19:43.744634	2026-04-14 02:19:43.744634	personals/men_seeking_women/18___20_year_olds/marriage	4	0
c243f27e-2890-443f-ad79-2939463431b3	in_a_relationship	In a Relationship	18___20_year_olds	📱	0	t	2026-04-14 02:20:56.226595	2026-04-14 02:20:56.226595	personals/men_seeking_women/18___20_year_olds/in_a_relationship	4	0
2d9f371e-e47f-484a-88b8-d861eaaae740	penpals	Penpals	18___20_year_olds	📱	0	t	2026-04-14 02:32:03.607688	2026-04-14 02:32:03.607688	personals/men_seeking_women/18___20_year_olds/penpals	4	0
5d8e526d-49c9-43ec-8101-632d663979dc	virtual_relationship_1	Virtual Relationship	50___60_year_olds	📱	0	t	2026-04-14 06:17:24.672559	2026-04-14 06:17:24.672559	personals/men_seeking_women/50___60_year_olds/virtual_relationship_1	4	0
f2961968-68da-4f52-8692-25fafd5ab24e	self_help	Self-Help	services	🛠️	0	t	2026-04-14 20:41:08.590643	2026-04-14 20:41:08.590643	services/self_help	2	0
b1d51096-d578-4b2c-bf3e-0617c8bfe26e	hypnosis	Hypnosis	self_help	🛠️	0	t	2026-04-14 20:41:48.7355	2026-04-14 20:41:48.7355	services/self_help/hypnosis	3	0
08d0f114-b8e6-43c2-ada2-1e31bb7fbf0e	subliminals	Subliminals	self_help	🛠️	0	t	2026-04-14 20:43:51.198426	2026-04-14 20:43:51.198426	services/self_help/subliminals	3	0
8ad8d6cc-d1ee-428a-921d-ed00a030bd7b	other_7	Other	vehicles	📦	0	t	2026-04-14 01:36:02.856167	2026-04-14 01:36:02.856167	vehicles/other_7	2	999
872ea416-b7a1-4ba9-ab5d-155066d57e65	nlp	NLP	self_help	🛠️	0	t	2026-04-14 20:44:31.49942	2026-04-14 20:44:31.49942	services/self_help/nlp	3	0
89efc9bd-85d6-4828-9e27-9f42d126b62d	dried_nuts	Dried Nuts	food_and_beverage	🍔	0	t	2026-04-15 05:53:05.798514	2026-04-15 05:53:05.798514	food_and_beverage/dried_nuts	2	0
0baebe80-ea9d-421d-9d23-4bdb867ef30a	cafes	Cafes	food_and_beverage	🍔	0	t	2026-04-15 09:06:52.440014	2026-04-15 09:06:52.440014	food_and_beverage/cafes	2	0
3c91ac95-f25a-46be-abcc-c6529495cdd2	lessons	Lessons	services	🛠️	0	t	2026-04-15 16:55:47.842844	2026-04-15 16:55:47.842844	services/lessons	2	0
3ef41b2a-7d70-4465-8470-50316313d79f	men_seeking_women	Men Seeking Women	personals	📱	0	t	2026-04-14 01:51:53.96485	2026-04-14 01:51:53.96485	personals/men_seeking_women	2	0
54620b95-efbb-4bba-ae92-773501a5cdbb	men_seeking_men	Men Seeking Men	personals	📱	0	t	2026-04-14 01:52:09.051804	2026-04-14 01:52:09.051804	personals/men_seeking_men	2	0
c8b1c9c0-b3f2-453e-97b3-f33ae78854cd	women_seeking_men	Women Seeking Men	personals	📱	0	t	2026-04-14 01:52:25.250202	2026-04-14 01:52:25.250202	personals/women_seeking_men	2	0
97fe7447-8da2-4c94-9bda-cb97c4e5090f	women_seeking_women	Women Seeking Women	personals	📱	0	t	2026-04-14 01:52:48.052421	2026-04-14 01:52:48.052421	personals/women_seeking_women	2	0
eb06a4a6-7890-4584-bdb9-c72669467ae7	english_lessons	English Lessons	lessons	🛠️	0	t	2026-04-15 16:56:40.93383	2026-04-15 16:56:40.93383	services/lessons/english_lessons	3	0
d784c7d1-f2a1-48cb-b5fd-90667c0b0d4d	20___30_year_olds	20 - 30 Year-Olds	men_seeking_women	📱	0	t	2026-04-14 02:02:17.222733	2026-04-14 02:02:17.222733	personals/men_seeking_women/20___30_year_olds	3	0
c3b85884-dd5a-4a35-96d7-731ee5c8a0aa	30___40_year_olds	30 - 40 Year-Olds	men_seeking_women	📱	0	t	2026-04-14 02:03:34.833623	2026-04-14 02:03:34.833623	personals/men_seeking_women/30___40_year_olds	3	0
b54b2ae0-0a95-4f94-8c93-05f50b541674	40___50_year_olds	40 - 50 Year-Olds	men_seeking_women	📱	0	t	2026-04-14 02:06:16.720561	2026-04-14 02:06:16.720561	personals/men_seeking_women/40___50_year_olds	3	0
29bc8d7f-b4c3-4589-906f-c915b6a98433	50___60_year_olds	50 - 60 Year-Olds	men_seeking_women	📱	0	t	2026-04-14 02:07:20.232661	2026-04-14 02:07:20.232661	personals/men_seeking_women/50___60_year_olds	3	0
0aa9266c-901a-4563-b86b-80541fa74830	60__year_olds	60+ Year-Olds	men_seeking_women	📱	0	t	2026-04-14 02:09:19.521856	2026-04-14 02:09:19.521856	personals/men_seeking_women/60__year_olds	3	0
afe84265-56b8-4fb7-a779-a35a3fdc7a96	crowdfunding	Crowdfunding	\N	🌿	0	t	2026-04-26 17:19:40.646164	2026-04-26 17:19:40.646164	\N	1	0
f4723c7b-0dcb-4c7a-a021-17872552a0ea	crowdfunding_other	Other	crowdfunding	📦	0	t	2026-04-26 17:19:40.646164	2026-04-26 17:19:40.646164	\N	2	0
3b82c5e2-4078-4780-bc37-263b561fed8f	jobs	Jobs	\N	📁	0	t	2026-04-26 19:56:34.296764	2026-04-26 19:56:34.296764	\N	1	0
610066c3-53c6-4d72-ac3e-95a2b240458c	jobs_other	Other	jobs	📦	0	t	2026-04-26 19:56:34.296764	2026-04-26 19:56:34.296764	\N	2	0
edd3e626-1574-42a0-bca8-0230c8efb3de	pets_pet_supplies	Pets / Pet Supplies	\N	🐾	0	t	2026-04-26 20:12:19.257878	2026-04-26 20:12:19.257878	\N	1	0
e2b7cbe8-c7d4-46bb-b50e-c2ae5f5f8347	pets_pet_supplies_other	Other	pets_pet_supplies	📦	0	t	2026-04-26 20:12:19.257878	2026-04-26 20:12:19.257878	\N	2	0
\.


--
-- Data for Name: shop_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop_messages (id, conversation_id, sender_id, message, is_read, created_at) FROM stdin;
58264bc0-165e-4018-a56a-2ca43aa514c8	8decc8d4-f579-40f1-ba8f-5a2fea5024c0	e8ce3170-c7c9-48d3-8ba2-529a2dcf2d7d	Can I offer you 50% of the asking price?	t	2026-04-19 04:19:47.2218
0eaaf972-f941-4223-bbde-6ea9d515f567	8decc8d4-f579-40f1-ba8f-5a2fea5024c0	dfb80e70-2782-4e00-a328-384d8806897f	Yes, that would be okay.	t	2026-04-19 04:23:13.044104
\.


--
-- Data for Name: store_stats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.store_stats (id, store_id, views, orders, revenue_cents, rating, review_count, updated_at) FROM stdin;
8d745dd5-b744-4768-a3e1-f5e59c6f3901	af9ace4f-e0a6-4ea1-a596-2a3069dab55c	0	0	0	0.00	0	2026-04-14 16:28:27.027522
\.


--
-- Data for Name: stores; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stores (id, seller_id, store_name, slug, description, logo_url, banner_url, custom_domain, is_custom_domain_verified, is_active, store_settings, created_at, updated_at, paypal_email, return_policy, shipping_policy, processing_time_days, settings, theme_color, secondary_color, text_color, font_family, layout_style, show_seller_info) FROM stdin;
af9ace4f-e0a6-4ea1-a596-2a3069dab55c	dfb80e70-2782-4e00-a328-384d8806897f	Heavenly Subliminals	heavenly-subliminals	I can create custom subliminals of varying strengths from x1 all the way to xgoogols. Processing time and the final price depend on the strength ordered.	\N	\N	\N	f	t	{"allow_offers": true, "return_policy": "", "shipping_zones": [], "processing_time_days": 2}	2026-04-14 16:28:27.024663	2026-04-14 16:28:27.024663	bmirkalami@gmail.com	No returns accepted!	Ships within a maximum of a week. Digital online delivery of shipped to your doorfront on a USB stick.	7	{"accept_offers": true, "vacation_mode": false, "vacation_message": "", "auto_approve_offers": true, "minimum_offer_percent": 50}	#0b1f3f	#ffd700	#f5f5f5	Arial, sans-serif	grid	t
\.


--
-- Data for Name: subscription_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscription_plans (id, name, slug, description, price_monthly_cents, price_yearly_cents, platform_fee_percent, features, is_active, sort_order, created_at, updated_at) FROM stdin;
f0468af6-b05e-476b-89ec-88b4ffdfe1c6	Free	free	Basic access for casual sellers	0	0	17.00	{"analytics": false, "max_images": 3, "promotions": false, "bulk_import": false, "max_listings": 20, "customization": false, "priority_support": false, "featured_listings": 0}	t	1	2026-04-22 13:05:29.485778	2026-04-22 13:23:22.568412
7a3da65d-5e5f-4d1b-846b-78bbdff413f7	Pro	pro	For serious sellers	1999	19990	16.00	{"analytics": false, "max_images": 5, "promotions": true, "bulk_import": true, "max_listings": 200, "customization": true, "priority_support": false, "featured_listings": 3}	t	2	2026-04-22 13:05:29.485778	2026-04-22 13:27:08.370548
c079c7d2-43e5-4a2d-9a66-f9b42e7f0044	Business	business	For high-volume sellers	4999	49990	15.50	{"analytics": true, "max_images": 10, "promotions": true, "bulk_import": true, "max_listings": 2000, "customization": true, "priority_support": true, "featured_listings": 10}	t	3	2026-04-22 13:05:29.485778	2026-04-22 13:29:42.364413
63de18d9-ea94-4898-bfc8-60fcb51d2860	Enterprise	enterprise	Unlimited everything	9999	99990	15.00	{"analytics": true, "max_images": 20, "promotions": true, "bulk_import": true, "max_listings": -1, "customization": true, "priority_support": true, "featured_listings": -1}	t	4	2026-04-22 13:05:29.485778	2026-04-22 13:31:29.581337
\.


--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.support_tickets (id, user_id, name, email, subject, message, category, status, admin_response, responded_by, responded_at, created_at, updated_at) FROM stdin;
63aac7cb-5723-4316-af2a-029e0b68d8d4	\N	Seyed B Mirkalami	bmirkalami@gmail.com	New Rent Amount Assessed	General enquiry email's body.	general	open	\N	\N	\N	2026-04-14 17:00:39.36219	2026-04-14 17:00:39.36219
33b5862d-2205-4df6-8fbd-8bb423837b03	\N	test	test@test.me	general	General's body.	general	open	\N	\N	\N	2026-04-22 14:12:58.206252	2026-04-22 14:12:58.206252
\.


--
-- Data for Name: suspension_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.suspension_logs (id, user_id, admin_id, action, duration_days, reason, created_at) FROM stdin;
\.


--
-- Data for Name: transaction_ratings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transaction_ratings (id, purchase_id, listing_id, rater_id, ratee_id, rating_type, overall_rating, communication_rating, payment_speed_rating, shipping_speed_rating, item_accuracy_rating, feedback, is_public, created_at) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transactions (id, transaction_hash, user_id, type, amount_cents, balance_after_cents, currency_clone, reference_id, description, is_mock, created_at) FROM stdin;
\.


--
-- Data for Name: trusted_devices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trusted_devices (id, user_id, device_fingerprint, user_agent, ip_address, last_verified_at, created_at) FROM stdin;
db7174b9-647f-41af-95df-a37b1df26061	dfb80e70-2782-4e00-a328-384d8806897f	TW96aWxsYS81LjAgKFgxMTsgTGludXggeDg2XzY0KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJv	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	::1	2026-04-26 02:26:39.236257	2026-04-10 16:27:08.951771
e752cc0c-1874-44fa-a886-5e227b524ea1	55825b3e-9fd4-440f-94ba-643eb2c7835e	TW96aWxsYS81LjAgKExpbnV4OyBBbmRyb2lkIDEwOyBLKSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBT	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/29.0 Chrome/136.0.0.0 Mobile Safari/537.36	::1	2026-04-13 17:41:58.76697	2026-04-13 17:41:44.157539
6985ebed-2bd0-47f6-8ce5-7a48434ff8d5	2fabcd4d-044e-47a5-a4f5-78a71ae50490	3e7ef43ef4b39479e70fb3af2650bad9c06186104eaa35b1a1e1b82457695f04	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	::1	2026-04-26 09:16:43.714424	2026-04-26 09:16:43.714424
5ae005fb-e58e-46e2-82f5-2a3271596c7e	2fabcd4d-044e-47a5-a4f5-78a71ae50490	3f293e15f0f5d4bd8b0228e4b0cb2cfe0dc898cf75e06d07bbe3956becd6f1ed	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	::ffff:127.0.0.1	2026-04-26 09:17:52.652744	2026-04-26 09:17:52.652744
b446aa37-9c28-4a30-9697-e2f1f83c0b5f	e27eff2f-1fd9-498a-a3b6-10ea3f3c2424	395e8d933b1647a32ecb83c5b87ee38c14e898234d5e8a548411e9c107677b07	Mozilla/5.0 (Linux; Android 14; V2424 Build/UP1A.231005.007_NN; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/147.0.7727.55 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/558.0.0.46.77;]	::ffff:127.0.0.1	2026-04-26 11:25:04.575966	2026-04-26 11:25:04.575966
cf8feef8-641e-4077-a53f-38f05c33d2b4	e27eff2f-1fd9-498a-a3b6-10ea3f3c2424	b4d92e37981532fbb4f37fd275e0e1139dd1576903235b2dd567fb0d9022b794	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	::ffff:127.0.0.1	2026-04-26 11:29:06.99134	2026-04-26 11:22:25.921698
1a198037-c6ad-4968-ac6d-144426916245	e8ce3170-c7c9-48d3-8ba2-529a2dcf2d7d	TW96aWxsYS81LjAgKExpbnV4OyBBbmRyb2lkIDEwOyBLKSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBD	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	::1	2026-04-20 06:57:35.106202	2026-04-20 06:57:35.106202
8e3fbdb3-9c52-41d3-8889-71b40a64e399	e8ce3170-c7c9-48d3-8ba2-529a2dcf2d7d	TW96aWxsYS81LjAgKFgxMTsgTGludXggeDg2XzY0KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJv	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	::1	2026-04-22 09:45:11.964076	2026-04-15 13:09:19.621304
6397672c-3a68-48fb-8f95-8523f5ad6f4e	dfb80e70-2782-4e00-a328-384d8806897f	3f293e15f0f5d4bd8b0228e4b0cb2cfe0dc898cf75e06d07bbe3956becd6f1ed	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	::ffff:127.0.0.1	2026-04-28 07:23:47.974947	2026-04-26 10:19:03.25079
e8062adf-195a-401a-a026-be4747e3ea74	a3428681-b224-4461-9235-9f94618aaa4b	8b00e635016f1a5b4b3d95896e95fd860940050c9de8bc43db5be0fc3122bcc2	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/29.0 Chrome/136.0.0.0 Mobile Safari/537.36	::1	2026-04-28 19:46:44.112878	2026-04-28 19:46:44.112878
19b59ab8-30ba-4fe1-89c4-fbb3eeb4d8e3	dfb80e70-2782-4e00-a328-384d8806897f	TW96aWxsYS81LjAgKExpbnV4OyBBbmRyb2lkIDEwOyBLKSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBD	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	::ffff:127.0.0.1	2026-04-25 18:34:49.711743	2026-04-20 06:56:19.566962
\.


--
-- Data for Name: user_rating_summaries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_rating_summaries (user_id, seller_avg_rating, seller_total_ratings, seller_communication_avg, seller_shipping_avg, seller_item_accuracy_avg, buyer_avg_rating, buyer_total_ratings, buyer_communication_avg, buyer_payment_speed_avg, updated_at) FROM stdin;
\.


--
-- Data for Name: user_subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_subscriptions (id, user_id, plan_id, billing_cycle, status, started_at, expires_at, auto_renew, paypal_subscription_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, full_name, whatsapp_number, is_super_admin, is_suspended, suspension_end_date, suspension_reason, created_at, updated_at, last_login, email_verified, email_verification_token, password_reset_token, password_reset_expires, last_mandatory_2fa, is_active, paypal_email, referral_code, referred_by, affiliate_balance_cents, total_referrals, total_affiliate_earned_cents, max_listings, max_images_per_listing, can_use_bulk_import, can_create_promotions, can_customize_store, can_view_analytics, featured_listings_count, priority_support, current_plan_id) FROM stdin;
e8ce3170-c7c9-48d3-8ba2-529a2dcf2d7d	bryanjbenevolence@gmail.com	$2b$10$bQqmJvFrBFVO4j8XZvHIgOG2ttCq.1P32cEK3cNIFsR907bcVtYJe	Bryan J Benevolence	+1-647-228-1215	f	f	\N	\N	2026-04-12 20:48:43.354831	2026-04-22 15:38:37.751483	\N	t	\N	\N	\N	2026-04-20 06:57:35.104155	t	\N	1A9EE319	\N	0	0	0	20	3	f	f	f	f	0	f	f0468af6-b05e-476b-89ec-88b4ffdfe1c6
dfb80e70-2782-4e00-a328-384d8806897f	bmirkalami@gmail.com	$2b$10$lkeccfhZAQoauG4A1rUnmer5sJUZiG9.f0nr1TxTgQvQwL5O4K1TG	Bryan J Benevolence	+1-647-228-1215	t	f	\N	\N	2026-04-07 07:11:08.249076	2026-04-28 07:20:08.862573	2026-04-08 06:45:27.12962	t	92ad14e9b4c1fb3256855538096c3fe832ac8b94d44c40005d5f6592a612b6e9	\N	\N	2026-04-28 07:20:08.862573	t	\N	AEB9DB2E	\N	0	0	0	20	3	f	f	f	f	0	f	f0468af6-b05e-476b-89ec-88b4ffdfe1c6
55825b3e-9fd4-440f-94ba-643eb2c7835e	netiamodester8@gmail.com	$2b$10$hIx2pmsr/6iuV2d7C5F3g.AemCW4H/lWeKFJC2GKEbisM5qQSyA7G	Modester netia 	+254115163345	f	f	\N	\N	2026-04-13 17:40:21.325392	2026-04-22 15:38:37.751483	\N	t	\N	\N	\N	2026-04-13 17:41:44.152489	t	\N	\N	\N	0	0	0	20	3	f	f	f	f	0	f	f0468af6-b05e-476b-89ec-88b4ffdfe1c6
e2f77a8e-18cf-46d5-851e-18a0a8bb891a	test@example.com	$2b$10$CeKNedJJpv49zleOekjjoONiTeSZ7v07LVFxsnBKYNi6C1ul.xA.C	\N	\N	f	f	\N	\N	2026-04-07 07:09:26.28187	2026-04-22 15:38:37.751483	\N	f	6a10c5c5ee930464ccb2f9aec6c95f501ac55be1d416b0b87056ca09d897ab58	\N	\N	\N	t	\N	\N	\N	0	0	0	20	3	f	f	f	f	0	f	f0468af6-b05e-476b-89ec-88b4ffdfe1c6
f2c3041f-58f0-4397-905f-499f5d19c5fc	test@test.com	$2b$12$NfLOs7pHR3kpzzlSmK.C7e26FYuFv.WAsJ..gVmD3SKaeYhmuijy6	Test User	\N	f	f	\N	\N	2026-04-26 02:06:23.94448	2026-04-26 02:06:23.94448	\N	f	\N	\N	\N	\N	t	\N	\N	\N	0	0	0	10	3	f	f	f	f	0	f	\N
70573c6c-0708-4831-802f-fd0acba08ecd	best@example.com	$2b$12$177.mlOb/a1QsaLdGsO5VO3FUa0CCNaHUrRvqnowbE1RGBswDuIA6	Best	\N	f	f	\N	\N	2026-04-26 02:07:39.492534	2026-04-26 02:07:39.492534	\N	f	\N	\N	\N	\N	t	\N	\N	\N	0	0	0	10	3	f	f	f	f	0	f	\N
a25196da-2a52-4f24-9b39-5412764c22fa	test6@test.com	$2b$12$x4JAw7jh8bit5/Tjp677JO0oUzo8lx2FlCLpoOcK8GU3iDlVELh7u	Test User	\N	f	f	\N	\N	2026-04-26 03:10:46.136124	2026-04-26 03:10:46.136124	\N	f	1be7fff16c9dd4512abd9211bcd2f88d580a36f926ff18c4e87eea4773fdea4a	\N	\N	\N	t	\N	\N	\N	0	0	0	10	3	f	f	f	f	0	f	\N
17977207-87a0-40ca-a47b-1470048ffd8d	mukasanelly114@gmail.com	$2b$12$rL1K087kmYeXBlk2OZZlV.b6OetSnZ0WdA7etL28PmiVfJZsVM2RG	Mukasa nelly 	\N	f	f	\N	\N	2026-04-28 14:09:26.719985	2026-04-28 14:09:26.719985	\N	f	2f8bc0fcb4c40070da4f1d09001a50bcb9d680fbb3fbd4b874f52cd87a3dba1c	\N	\N	\N	t	\N	\N	\N	0	0	0	10	3	f	f	f	f	0	f	\N
2fabcd4d-044e-47a5-a4f5-78a71ae50490	credoncentral@gmail.com	$2b$12$n3dft10PE5E0DNQobW1BbO1MgL1XtG6LxnLjd37ASYyPPblHiKE8e	Credon Central	\N	f	f	\N	\N	2026-04-26 09:15:36.935074	2026-04-26 09:17:52.64939	\N	t	\N	\N	\N	2026-04-26 09:17:52.64939	t	\N	\N	\N	0	0	0	10	3	f	f	f	f	0	f	\N
0b5dd698-777f-4cf0-89ef-8fe4661b8495	test789@test.com	$2b$12$DI/AFXBXdrygixXQPbp1c.wKc5pyh5CbkTP1H6.cA21DEqdkcMp5e	Test User	\N	f	f	\N	\N	2026-04-26 04:42:16.247005	2026-04-26 04:42:16.247005	\N	f	f77237381660c22bade3fc7d43e5865bba3b03150dec77cd0ddaad3f77749c74	\N	\N	\N	t	\N	\N	\N	0	0	0	10	3	f	f	f	f	0	f	\N
a3428681-b224-4461-9235-9f94618aaa4b	bagalanaenoch114@gmail.com	$2b$12$2vvqCAtmVD2bNIAJx/FDfOkjk7jzEzJm7uzjYO4W2aSQFZLgEJ6ES	Bagalana Enoch 	\N	f	f	\N	\N	2026-04-28 19:45:50.955501	2026-04-28 19:46:44.105924	\N	t	\N	\N	\N	2026-04-28 19:46:44.105924	t	\N	\N	\N	0	0	0	10	3	f	f	f	f	0	f	\N
e27eff2f-1fd9-498a-a3b6-10ea3f3c2424	mary_grace102011@yahoo.com	$2b$12$H.57xbdqztEWXctWzy5/9.TK.FQAWk31DDcls2ewd.yTw7bEln8L2	Mary Grace Biscocho	\N	f	f	\N	\N	2026-04-26 11:21:40.723377	2026-04-26 11:25:04.573056	\N	t	\N	\N	\N	2026-04-26 11:25:04.573056	t	\N	\N	\N	0	0	0	10	3	f	f	f	f	0	f	\N
8bf4be6f-9d39-4b6d-a94a-9614071e6232	bagalanaenoch@114gmail.com	$2b$12$aueW4oVkqQw743QmKyGrweliGGn0BMw9w.sAAtJLqt7vB8J0t3VCi	Bagalana 	\N	f	f	\N	\N	2026-04-27 19:35:10.023374	2026-04-27 19:35:10.023374	\N	f	74b4f53cf2caedeb117321b387615a764294f2ba2a58a5a9aea30169ad996674	\N	\N	\N	t	\N	\N	\N	0	0	0	10	3	f	f	f	f	0	f	\N
\.


--
-- Data for Name: wallets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wallets (id, user_id, balance_cents, created_at, updated_at) FROM stdin;
2513dfd0-89bd-48fb-a615-f6c912893e13	e2f77a8e-18cf-46d5-851e-18a0a8bb891a	0	2026-04-07 07:09:26.285627	2026-04-07 07:09:26.285627
d33eaf06-e68a-45ae-a364-f97e9e211343	dfb80e70-2782-4e00-a328-384d8806897f	0	2026-04-07 07:11:08.252211	2026-04-07 07:11:08.252211
\.


--
-- Data for Name: wishlists; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wishlists (id, user_id, listing_id, created_at) FROM stdin;
\.


--
-- Name: affiliate_settings affiliate_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.affiliate_settings
    ADD CONSTRAINT affiliate_settings_pkey PRIMARY KEY (id);


--
-- Name: affiliate_settings affiliate_settings_setting_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.affiliate_settings
    ADD CONSTRAINT affiliate_settings_setting_key_key UNIQUE (setting_key);


--
-- Name: analytics_daily analytics_daily_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analytics_daily
    ADD CONSTRAINT analytics_daily_date_key UNIQUE (date);


--
-- Name: analytics_daily analytics_daily_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analytics_daily
    ADD CONSTRAINT analytics_daily_pkey PRIMARY KEY (id);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: auction_bids auction_bids_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auction_bids
    ADD CONSTRAINT auction_bids_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: bids bids_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bids
    ADD CONSTRAINT bids_pkey PRIMARY KEY (id);


--
-- Name: carts carts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT carts_pkey PRIMARY KEY (id);


--
-- Name: carts carts_user_id_listing_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT carts_user_id_listing_id_key UNIQUE (user_id, listing_id);


--
-- Name: category_analytics category_analytics_date_category_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category_analytics
    ADD CONSTRAINT category_analytics_date_category_key UNIQUE (date, category);


--
-- Name: category_analytics category_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category_analytics
    ADD CONSTRAINT category_analytics_pkey PRIMARY KEY (id);


--
-- Name: category_suggestions category_suggestions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category_suggestions
    ADD CONSTRAINT category_suggestions_pkey PRIMARY KEY (id);


--
-- Name: category_translations category_translations_category_language_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category_translations
    ADD CONSTRAINT category_translations_category_language_code_key UNIQUE (category, language_code);


--
-- Name: category_translations category_translations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category_translations
    ADD CONSTRAINT category_translations_pkey PRIMARY KEY (id);


--
-- Name: competitor_insights competitor_insights_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.competitor_insights
    ADD CONSTRAINT competitor_insights_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_listing_id_buyer_id_seller_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_listing_id_buyer_id_seller_id_key UNIQUE (listing_id, buyer_id, seller_id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: dispute_evidence dispute_evidence_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dispute_evidence
    ADD CONSTRAINT dispute_evidence_pkey PRIMARY KEY (id);


--
-- Name: dispute_messages dispute_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dispute_messages
    ADD CONSTRAINT dispute_messages_pkey PRIMARY KEY (id);


--
-- Name: disputes disputes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disputes
    ADD CONSTRAINT disputes_pkey PRIMARY KEY (id);


--
-- Name: escrow_transactions escrow_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.escrow_transactions
    ADD CONSTRAINT escrow_transactions_pkey PRIMARY KEY (id);


--
-- Name: exchange_rates exchange_rates_from_currency_to_currency_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exchange_rates
    ADD CONSTRAINT exchange_rates_from_currency_to_currency_key UNIQUE (from_currency, to_currency);


--
-- Name: exchange_rates exchange_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exchange_rates
    ADD CONSTRAINT exchange_rates_pkey PRIMARY KEY (id);


--
-- Name: fee_transactions fee_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fee_transactions
    ADD CONSTRAINT fee_transactions_pkey PRIMARY KEY (id);


--
-- Name: gift_card_transactions gift_card_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gift_card_transactions
    ADD CONSTRAINT gift_card_transactions_pkey PRIMARY KEY (id);


--
-- Name: gift_cards gift_cards_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gift_cards
    ADD CONSTRAINT gift_cards_code_key UNIQUE (code);


--
-- Name: gift_cards gift_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gift_cards
    ADD CONSTRAINT gift_cards_pkey PRIMARY KEY (id);


--
-- Name: help_articles help_articles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.help_articles
    ADD CONSTRAINT help_articles_pkey PRIMARY KEY (id);


--
-- Name: help_articles help_articles_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.help_articles
    ADD CONSTRAINT help_articles_slug_key UNIQUE (slug);


--
-- Name: listing_translations listing_translations_listing_id_language_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_translations
    ADD CONSTRAINT listing_translations_listing_id_language_code_key UNIQUE (listing_id, language_code);


--
-- Name: listing_translations listing_translations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_translations
    ADD CONSTRAINT listing_translations_pkey PRIMARY KEY (id);


--
-- Name: listing_views listing_views_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_views
    ADD CONSTRAINT listing_views_pkey PRIMARY KEY (id);


--
-- Name: listings listings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listings
    ADD CONSTRAINT listings_pkey PRIMARY KEY (id);


--
-- Name: login_verification_codes login_verification_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_verification_codes
    ADD CONSTRAINT login_verification_codes_pkey PRIMARY KEY (id);


--
-- Name: market_trends market_trends_category_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.market_trends
    ADD CONSTRAINT market_trends_category_date_key UNIQUE (category, date);


--
-- Name: market_trends market_trends_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.market_trends
    ADD CONSTRAINT market_trends_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: minting_logs minting_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.minting_logs
    ADD CONSTRAINT minting_logs_pkey PRIMARY KEY (id);


--
-- Name: offers offers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT offers_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: platform_settings platform_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_settings
    ADD CONSTRAINT platform_settings_pkey PRIMARY KEY (id);


--
-- Name: platform_settings platform_settings_setting_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_settings
    ADD CONSTRAINT platform_settings_setting_key_key UNIQUE (setting_key);


--
-- Name: price_predictions price_predictions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_predictions
    ADD CONSTRAINT price_predictions_pkey PRIMARY KEY (id);


--
-- Name: procurement_matches procurement_matches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.procurement_matches
    ADD CONSTRAINT procurement_matches_pkey PRIMARY KEY (id);


--
-- Name: procurement_matches procurement_matches_procurement_id_matching_listing_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.procurement_matches
    ADD CONSTRAINT procurement_matches_procurement_id_matching_listing_id_key UNIQUE (procurement_id, matching_listing_id);


--
-- Name: promotion_usage promotion_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promotion_usage
    ADD CONSTRAINT promotion_usage_pkey PRIMARY KEY (id);


--
-- Name: promotions promotions_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promotions
    ADD CONSTRAINT promotions_code_key UNIQUE (code);


--
-- Name: promotions promotions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promotions
    ADD CONSTRAINT promotions_pkey PRIMARY KEY (id);


--
-- Name: purchases purchases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_pkey PRIMARY KEY (id);


--
-- Name: ratings ratings_order_id_reviewer_id_reviewee_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ratings
    ADD CONSTRAINT ratings_order_id_reviewer_id_reviewee_id_key UNIQUE (order_id, reviewer_id, reviewee_id);


--
-- Name: ratings ratings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ratings
    ADD CONSTRAINT ratings_pkey PRIMARY KEY (id);


--
-- Name: sales_history sales_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_history
    ADD CONSTRAINT sales_history_pkey PRIMARY KEY (id);


--
-- Name: saved_searches saved_searches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_searches
    ADD CONSTRAINT saved_searches_pkey PRIMARY KEY (id);


--
-- Name: search_matches search_matches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_matches
    ADD CONSTRAINT search_matches_pkey PRIMARY KEY (id);


--
-- Name: search_matches search_matches_saved_search_id_listing_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_matches
    ADD CONSTRAINT search_matches_saved_search_id_listing_id_key UNIQUE (saved_search_id, listing_id);


--
-- Name: seasonal_trends seasonal_trends_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seasonal_trends
    ADD CONSTRAINT seasonal_trends_pkey PRIMARY KEY (id);


--
-- Name: seller_analytics seller_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seller_analytics
    ADD CONSTRAINT seller_analytics_pkey PRIMARY KEY (id);


--
-- Name: seller_analytics seller_analytics_seller_id_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seller_analytics
    ADD CONSTRAINT seller_analytics_seller_id_date_key UNIQUE (seller_id, date);


--
-- Name: seller_ratings_summary seller_ratings_summary_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seller_ratings_summary
    ADD CONSTRAINT seller_ratings_summary_pkey PRIMARY KEY (seller_id);


--
-- Name: shop_admins shop_admins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_admins
    ADD CONSTRAINT shop_admins_pkey PRIMARY KEY (id);


--
-- Name: shop_admins shop_admins_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_admins
    ADD CONSTRAINT shop_admins_user_id_key UNIQUE (user_id);


--
-- Name: shop_categories shop_categories_category_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_categories
    ADD CONSTRAINT shop_categories_category_key UNIQUE (category);


--
-- Name: shop_categories shop_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_categories
    ADD CONSTRAINT shop_categories_pkey PRIMARY KEY (id);


--
-- Name: shop_messages shop_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_messages
    ADD CONSTRAINT shop_messages_pkey PRIMARY KEY (id);


--
-- Name: store_stats store_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store_stats
    ADD CONSTRAINT store_stats_pkey PRIMARY KEY (id);


--
-- Name: store_stats store_stats_store_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store_stats
    ADD CONSTRAINT store_stats_store_id_key UNIQUE (store_id);


--
-- Name: stores stores_custom_domain_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stores
    ADD CONSTRAINT stores_custom_domain_key UNIQUE (custom_domain);


--
-- Name: stores stores_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stores
    ADD CONSTRAINT stores_pkey PRIMARY KEY (id);


--
-- Name: stores stores_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stores
    ADD CONSTRAINT stores_slug_key UNIQUE (slug);


--
-- Name: subscription_plans subscription_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_pkey PRIMARY KEY (id);


--
-- Name: subscription_plans subscription_plans_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_slug_key UNIQUE (slug);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);


--
-- Name: suspension_logs suspension_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suspension_logs
    ADD CONSTRAINT suspension_logs_pkey PRIMARY KEY (id);


--
-- Name: transaction_ratings transaction_ratings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transaction_ratings
    ADD CONSTRAINT transaction_ratings_pkey PRIMARY KEY (id);


--
-- Name: transaction_ratings transaction_ratings_purchase_id_rater_id_rating_type_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transaction_ratings
    ADD CONSTRAINT transaction_ratings_purchase_id_rater_id_rating_type_key UNIQUE (purchase_id, rater_id, rating_type);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: trusted_devices trusted_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trusted_devices
    ADD CONSTRAINT trusted_devices_pkey PRIMARY KEY (id);


--
-- Name: trusted_devices trusted_devices_user_id_device_fingerprint_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trusted_devices
    ADD CONSTRAINT trusted_devices_user_id_device_fingerprint_key UNIQUE (user_id, device_fingerprint);


--
-- Name: user_rating_summaries user_rating_summaries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_rating_summaries
    ADD CONSTRAINT user_rating_summaries_pkey PRIMARY KEY (user_id);


--
-- Name: user_subscriptions user_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_subscriptions
    ADD CONSTRAINT user_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_referral_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_referral_code_key UNIQUE (referral_code);


--
-- Name: wallets wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT wallets_pkey PRIMARY KEY (id);


--
-- Name: wallets wallets_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT wallets_user_id_key UNIQUE (user_id);


--
-- Name: wishlists wishlists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wishlists
    ADD CONSTRAINT wishlists_pkey PRIMARY KEY (id);


--
-- Name: wishlists wishlists_user_id_listing_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wishlists
    ADD CONSTRAINT wishlists_user_id_listing_id_key UNIQUE (user_id, listing_id);


--
-- Name: idx_appointments_appointment_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_appointment_time ON public.appointments USING btree (appointment_time);


--
-- Name: idx_appointments_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_user_id ON public.appointments USING btree (user_id);


--
-- Name: idx_auction_bids_bidder_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auction_bids_bidder_id ON public.auction_bids USING btree (bidder_id);


--
-- Name: idx_auction_bids_listing_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auction_bids_listing_id ON public.auction_bids USING btree (listing_id);


--
-- Name: idx_audit_logs_admin_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_admin_id ON public.audit_logs USING btree (admin_id);


--
-- Name: idx_audit_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: idx_bids_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bids_status ON public.bids USING btree (status);


--
-- Name: idx_bids_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bids_user_id ON public.bids USING btree (user_id);


--
-- Name: idx_category_translations_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_category_translations_category ON public.category_translations USING btree (category);


--
-- Name: idx_category_translations_lang; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_category_translations_lang ON public.category_translations USING btree (language_code);


--
-- Name: idx_conversations_buyer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_conversations_buyer_id ON public.conversations USING btree (buyer_id);


--
-- Name: idx_conversations_seller_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_conversations_seller_id ON public.conversations USING btree (seller_id);


--
-- Name: idx_disputes_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_disputes_status ON public.disputes USING btree (status);


--
-- Name: idx_disputes_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_disputes_user_id ON public.disputes USING btree (user_id);


--
-- Name: idx_listing_translations_lang; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listing_translations_lang ON public.listing_translations USING btree (language_code);


--
-- Name: idx_listing_translations_listing; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listing_translations_listing ON public.listing_translations USING btree (listing_id);


--
-- Name: idx_listings_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listings_expires_at ON public.listings USING btree (expires_at);


--
-- Name: idx_listings_seller_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listings_seller_id ON public.listings USING btree (seller_id);


--
-- Name: idx_listings_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listings_status ON public.listings USING btree (status);


--
-- Name: idx_listings_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listings_type ON public.listings USING btree (type);


--
-- Name: idx_login_verification_codes_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_login_verification_codes_expires_at ON public.login_verification_codes USING btree (expires_at);


--
-- Name: idx_login_verification_codes_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_login_verification_codes_session_id ON public.login_verification_codes USING btree (session_id);


--
-- Name: idx_orders_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_status ON public.orders USING btree (status);


--
-- Name: idx_orders_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_user_id ON public.orders USING btree (user_id);


--
-- Name: idx_promotions_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_promotions_active ON public.promotions USING btree (is_active);


--
-- Name: idx_promotions_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_promotions_code ON public.promotions USING btree (code);


--
-- Name: idx_promotions_seller_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_promotions_seller_id ON public.promotions USING btree (seller_id);


--
-- Name: idx_shop_messages_conversation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_shop_messages_conversation_id ON public.shop_messages USING btree (conversation_id);


--
-- Name: idx_shop_messages_is_read; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_shop_messages_is_read ON public.shop_messages USING btree (is_read);


--
-- Name: idx_shop_messages_sender_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_shop_messages_sender_id ON public.shop_messages USING btree (sender_id);


--
-- Name: idx_suspension_logs_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_suspension_logs_user_id ON public.suspension_logs USING btree (user_id);


--
-- Name: idx_transactions_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_created_at ON public.transactions USING btree (created_at);


--
-- Name: idx_transactions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_user_id ON public.transactions USING btree (user_id);


--
-- Name: idx_translations_search; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_translations_search ON public.listing_translations USING gin (search_vector);


--
-- Name: shop_categories add_other_subcategory_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER add_other_subcategory_trigger AFTER INSERT ON public.shop_categories FOR EACH ROW EXECUTE FUNCTION public.add_other_subcategory();


--
-- Name: listing_translations trg_translation_search_vector; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_translation_search_vector BEFORE INSERT OR UPDATE ON public.listing_translations FOR EACH ROW EXECUTE FUNCTION public.update_translation_search_vector();


--
-- Name: appointments update_appointments_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_appointments_updated_at BEFORE UPDATE ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: bids update_bids_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_bids_updated_at BEFORE UPDATE ON public.bids FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: disputes update_disputes_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_disputes_updated_at BEFORE UPDATE ON public.disputes FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: exchange_rates update_exchange_rates_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_exchange_rates_updated_at BEFORE UPDATE ON public.exchange_rates FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: orders update_orders_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_orders_updated_at BEFORE UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: wallets update_wallets_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_wallets_updated_at BEFORE UPDATE ON public.wallets FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: appointments appointments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: auction_bids auction_bids_bidder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auction_bids
    ADD CONSTRAINT auction_bids_bidder_id_fkey FOREIGN KEY (bidder_id) REFERENCES public.users(id);


--
-- Name: auction_bids auction_bids_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auction_bids
    ADD CONSTRAINT auction_bids_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.listings(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: bids bids_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bids
    ADD CONSTRAINT bids_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: carts carts_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT carts_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.listings(id) ON DELETE CASCADE;


--
-- Name: carts carts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT carts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: category_suggestions category_suggestions_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category_suggestions
    ADD CONSTRAINT category_suggestions_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: category_suggestions category_suggestions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category_suggestions
    ADD CONSTRAINT category_suggestions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: competitor_insights competitor_insights_seller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.competitor_insights
    ADD CONSTRAINT competitor_insights_seller_id_fkey FOREIGN KEY (seller_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: conversations conversations_buyer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_buyer_id_fkey FOREIGN KEY (buyer_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: conversations conversations_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.listings(id) ON DELETE SET NULL;


--
-- Name: conversations conversations_seller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_seller_id_fkey FOREIGN KEY (seller_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: dispute_evidence dispute_evidence_dispute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dispute_evidence
    ADD CONSTRAINT dispute_evidence_dispute_id_fkey FOREIGN KEY (dispute_id) REFERENCES public.disputes(id) ON DELETE CASCADE;


--
-- Name: dispute_evidence dispute_evidence_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dispute_evidence
    ADD CONSTRAINT dispute_evidence_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: dispute_messages dispute_messages_dispute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dispute_messages
    ADD CONSTRAINT dispute_messages_dispute_id_fkey FOREIGN KEY (dispute_id) REFERENCES public.disputes(id) ON DELETE CASCADE;


--
-- Name: dispute_messages dispute_messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dispute_messages
    ADD CONSTRAINT dispute_messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: disputes disputes_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disputes
    ADD CONSTRAINT disputes_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: disputes disputes_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disputes
    ADD CONSTRAINT disputes_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: disputes disputes_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disputes
    ADD CONSTRAINT disputes_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.transactions(id);


--
-- Name: disputes disputes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disputes
    ADD CONSTRAINT disputes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: escrow_transactions escrow_transactions_buyer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.escrow_transactions
    ADD CONSTRAINT escrow_transactions_buyer_id_fkey FOREIGN KEY (buyer_id) REFERENCES public.users(id);


--
-- Name: escrow_transactions escrow_transactions_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.escrow_transactions
    ADD CONSTRAINT escrow_transactions_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.listings(id);


--
-- Name: escrow_transactions escrow_transactions_released_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.escrow_transactions
    ADD CONSTRAINT escrow_transactions_released_by_fkey FOREIGN KEY (released_by) REFERENCES public.users(id);


--
-- Name: escrow_transactions escrow_transactions_seller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.escrow_transactions
    ADD CONSTRAINT escrow_transactions_seller_id_fkey FOREIGN KEY (seller_id) REFERENCES public.users(id);


--
-- Name: exchange_rates exchange_rates_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exchange_rates
    ADD CONSTRAINT exchange_rates_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: gift_card_transactions gift_card_transactions_gift_card_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gift_card_transactions
    ADD CONSTRAINT gift_card_transactions_gift_card_id_fkey FOREIGN KEY (gift_card_id) REFERENCES public.gift_cards(id) ON DELETE CASCADE;


--
-- Name: gift_card_transactions gift_card_transactions_purchase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gift_card_transactions
    ADD CONSTRAINT gift_card_transactions_purchase_id_fkey FOREIGN KEY (purchase_id) REFERENCES public.purchases(id) ON DELETE SET NULL;


--
-- Name: gift_cards gift_cards_purchaser_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gift_cards
    ADD CONSTRAINT gift_cards_purchaser_id_fkey FOREIGN KEY (purchaser_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: gift_cards gift_cards_redeemed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gift_cards
    ADD CONSTRAINT gift_cards_redeemed_by_fkey FOREIGN KEY (redeemed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: help_articles help_articles_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.help_articles
    ADD CONSTRAINT help_articles_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: listing_translations listing_translations_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_translations
    ADD CONSTRAINT listing_translations_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.listings(id) ON DELETE CASCADE;


--
-- Name: listing_views listing_views_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_views
    ADD CONSTRAINT listing_views_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.listings(id);


--
-- Name: listing_views listing_views_viewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_views
    ADD CONSTRAINT listing_views_viewer_id_fkey FOREIGN KEY (viewer_id) REFERENCES public.users(id);


--
-- Name: listings listings_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listings
    ADD CONSTRAINT listings_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: listings listings_current_bidder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listings
    ADD CONSTRAINT listings_current_bidder_id_fkey FOREIGN KEY (current_bidder_id) REFERENCES public.users(id);


--
-- Name: listings listings_seller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listings
    ADD CONSTRAINT listings_seller_id_fkey FOREIGN KEY (seller_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: listings listings_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listings
    ADD CONSTRAINT listings_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id) ON DELETE SET NULL;


--
-- Name: login_verification_codes login_verification_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_verification_codes
    ADD CONSTRAINT login_verification_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: messages messages_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.listings(id);


--
-- Name: messages messages_receiver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_receiver_id_fkey FOREIGN KEY (receiver_id) REFERENCES public.users(id);


--
-- Name: messages messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id);


--
-- Name: minting_logs minting_logs_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.minting_logs
    ADD CONSTRAINT minting_logs_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.users(id);


--
-- Name: offers offers_buyer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT offers_buyer_id_fkey FOREIGN KEY (buyer_id) REFERENCES public.users(id);


--
-- Name: offers offers_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT offers_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.listings(id);


--
-- Name: orders orders_escrow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_escrow_id_fkey FOREIGN KEY (escrow_id) REFERENCES public.escrow_transactions(id);


--
-- Name: orders orders_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: platform_settings platform_settings_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_settings
    ADD CONSTRAINT platform_settings_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: procurement_matches procurement_matches_matching_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.procurement_matches
    ADD CONSTRAINT procurement_matches_matching_listing_id_fkey FOREIGN KEY (matching_listing_id) REFERENCES public.listings(id) ON DELETE CASCADE;


--
-- Name: procurement_matches procurement_matches_procurement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.procurement_matches
    ADD CONSTRAINT procurement_matches_procurement_id_fkey FOREIGN KEY (procurement_id) REFERENCES public.listings(id) ON DELETE CASCADE;


--
-- Name: promotion_usage promotion_usage_promotion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promotion_usage
    ADD CONSTRAINT promotion_usage_promotion_id_fkey FOREIGN KEY (promotion_id) REFERENCES public.promotions(id) ON DELETE CASCADE;


--
-- Name: promotion_usage promotion_usage_purchase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promotion_usage
    ADD CONSTRAINT promotion_usage_purchase_id_fkey FOREIGN KEY (purchase_id) REFERENCES public.purchases(id) ON DELETE CASCADE;


--
-- Name: promotion_usage promotion_usage_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promotion_usage
    ADD CONSTRAINT promotion_usage_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: promotions promotions_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promotions
    ADD CONSTRAINT promotions_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.listings(id) ON DELETE CASCADE;


--
-- Name: promotions promotions_seller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promotions
    ADD CONSTRAINT promotions_seller_id_fkey FOREIGN KEY (seller_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: promotions promotions_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promotions
    ADD CONSTRAINT promotions_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id) ON DELETE CASCADE;


--
-- Name: purchases purchases_buyer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_buyer_id_fkey FOREIGN KEY (buyer_id) REFERENCES public.users(id);


--
-- Name: purchases purchases_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.listings(id);


--
-- Name: purchases purchases_seller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_seller_id_fkey FOREIGN KEY (seller_id) REFERENCES public.users(id);


--
-- Name: ratings ratings_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ratings
    ADD CONSTRAINT ratings_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.listings(id);


--
-- Name: ratings ratings_reviewee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ratings
    ADD CONSTRAINT ratings_reviewee_id_fkey FOREIGN KEY (reviewee_id) REFERENCES public.users(id);


--
-- Name: ratings ratings_reviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ratings
    ADD CONSTRAINT ratings_reviewer_id_fkey FOREIGN KEY (reviewer_id) REFERENCES public.users(id);


--
-- Name: sales_history sales_history_buyer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_history
    ADD CONSTRAINT sales_history_buyer_id_fkey FOREIGN KEY (buyer_id) REFERENCES public.users(id);


--
-- Name: sales_history sales_history_seller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_history
    ADD CONSTRAINT sales_history_seller_id_fkey FOREIGN KEY (seller_id) REFERENCES public.users(id);


--
-- Name: saved_searches saved_searches_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_searches
    ADD CONSTRAINT saved_searches_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: search_matches search_matches_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_matches
    ADD CONSTRAINT search_matches_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.listings(id) ON DELETE CASCADE;


--
-- Name: search_matches search_matches_saved_search_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_matches
    ADD CONSTRAINT search_matches_saved_search_id_fkey FOREIGN KEY (saved_search_id) REFERENCES public.saved_searches(id) ON DELETE CASCADE;


--
-- Name: seller_analytics seller_analytics_seller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seller_analytics
    ADD CONSTRAINT seller_analytics_seller_id_fkey FOREIGN KEY (seller_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: seller_ratings_summary seller_ratings_summary_seller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seller_ratings_summary
    ADD CONSTRAINT seller_ratings_summary_seller_id_fkey FOREIGN KEY (seller_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: shop_admins shop_admins_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_admins
    ADD CONSTRAINT shop_admins_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: shop_admins shop_admins_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_admins
    ADD CONSTRAINT shop_admins_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: shop_messages shop_messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_messages
    ADD CONSTRAINT shop_messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: shop_messages shop_messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_messages
    ADD CONSTRAINT shop_messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: store_stats store_stats_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store_stats
    ADD CONSTRAINT store_stats_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id) ON DELETE CASCADE;


--
-- Name: stores stores_seller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stores
    ADD CONSTRAINT stores_seller_id_fkey FOREIGN KEY (seller_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: support_tickets support_tickets_responded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_responded_by_fkey FOREIGN KEY (responded_by) REFERENCES public.users(id);


--
-- Name: support_tickets support_tickets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: suspension_logs suspension_logs_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suspension_logs
    ADD CONSTRAINT suspension_logs_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.users(id);


--
-- Name: suspension_logs suspension_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suspension_logs
    ADD CONSTRAINT suspension_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: transaction_ratings transaction_ratings_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transaction_ratings
    ADD CONSTRAINT transaction_ratings_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.listings(id) ON DELETE CASCADE;


--
-- Name: transaction_ratings transaction_ratings_purchase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transaction_ratings
    ADD CONSTRAINT transaction_ratings_purchase_id_fkey FOREIGN KEY (purchase_id) REFERENCES public.purchases(id) ON DELETE CASCADE;


--
-- Name: transaction_ratings transaction_ratings_ratee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transaction_ratings
    ADD CONSTRAINT transaction_ratings_ratee_id_fkey FOREIGN KEY (ratee_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: transaction_ratings transaction_ratings_rater_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transaction_ratings
    ADD CONSTRAINT transaction_ratings_rater_id_fkey FOREIGN KEY (rater_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: trusted_devices trusted_devices_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trusted_devices
    ADD CONSTRAINT trusted_devices_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_rating_summaries user_rating_summaries_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_rating_summaries
    ADD CONSTRAINT user_rating_summaries_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_subscriptions user_subscriptions_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_subscriptions
    ADD CONSTRAINT user_subscriptions_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.subscription_plans(id);


--
-- Name: user_subscriptions user_subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_subscriptions
    ADD CONSTRAINT user_subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_current_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_current_plan_id_fkey FOREIGN KEY (current_plan_id) REFERENCES public.subscription_plans(id);


--
-- Name: users users_referred_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_referred_by_fkey FOREIGN KEY (referred_by) REFERENCES public.users(id);


--
-- Name: wallets wallets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT wallets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: wishlists wishlists_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wishlists
    ADD CONSTRAINT wishlists_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.listings(id) ON DELETE CASCADE;


--
-- Name: wishlists wishlists_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wishlists
    ADD CONSTRAINT wishlists_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict NDfj7QjbKw5k3OkV8ePw8DqDNvIZQjcezXdO8Vk5fVotuqEbuHKHdrNrY8v242t

